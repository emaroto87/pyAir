# -*- coding: utf-8 -*-
"""
Created on Thu Nov 27 12:08:39 2025

@author: U69432
"""

import paramiko

# Configuración
hostname = '10.10.16.2'  # IP o nombre del host
port = 22  # Puerto SSH
username = 'u69432'
password = 'Temp""53457341M'

# Crear un cliente SSH
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

try:
    # Conectar al servidor
    client.connect(hostname, port, username, password)
    print("Conexión exitosa.")

    # Ejecutar un comando
    stdin, stdout, stderr = client.exec_command('ls -l')
    print(stdout.read().decode())  # Mostrar salida del comando

finally:
    client.close()  # Cerrar conexión