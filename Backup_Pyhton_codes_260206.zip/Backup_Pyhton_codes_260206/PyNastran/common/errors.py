# -*- coding: utf-8 -*-


'''
BASIC ERROR CHECKS
'''


def check_type(obj, obj_class):
    if not (isinstance(obj, obj_class)):
        error_msg = 'Object {0} is not a {1}type'.format(
            str(type(obj)),
            str(type(obj_class))
        )
        raise TypeError(error_msg)


def check_option(option: str, options: list[str]):
    check_type(option, str)
    check_type(options, list)
    if not (option in options):
        raise ValueError(
            f'{option} is not one of the valid values included in {options}'
        )


def typerror_msg(obj: object, expected_obj: object) -> str:
    msg = '{0} object is not a {1}'.format(
        type(obj),
        expected_obj
    )
    return TypeError(msg)


class error_messages:
    def __init__(self):
        self.invalid_option = '[Error] Incorret option. Please try again.'
