# Funciones de limpieza del archivo de entrada

def limpia_n (lista):

    """ (lista) ---> lista
    Elimina el saltador de linea que se genera al final de una linea cuando se lee un fichero de texto y previamente
    ha sido convertido en una lista de listas (cada linea) mediante el separador ;

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0\n'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    """

    a = lista[-1]
    if '\n' in a:
        a = a[:-1]
        lista.pop()
        lista.append(a)

    return lista



def limpia_blancos_f (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información al final de una lista. Adicionalmente eliminamos
    el espaciador final.

    >>> elimina_blancos_f(['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0', '', ''])
    ['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0']

    """
    
    while lista[-1] == '':
        lista.pop()

    return lista

# Definimos una función para la escritura de los laminados

def laminados_arpa (lista):
    """ (list of strings) ---> string

    Transforma una lista de strings la cual define una secuencia de apilado para arpa
    en un formato adecuado para el fichero de material de arpa.

    >>> laminados_arpa(['SK10', '-M045', 'M045', 'M000', 'M090', 'M000', 'S'])
    'SK10,(-M045/M045/M000/M090/M000)S'

    >>> laminados_arpa(['SK10', '-M045', 'M045'])
    'SK10,(-M045/M045)

    >>> laminados_arpa(['SK10', '-M045', 'M045', 'S'])
    'SK10,(-M045/M045)S'

    >>> laminados_arpa(['CAPTI', 'T000'])
    'CAPTI,(T000)'

    """

    linea = lista[0] + ',('
    longitud = len(lista)
    sim_symbols = ['S','$']

    if len(lista) > 2:

        if lista[-1] in sim_symbols:
    
            for i in range (1,longitud-2):
                linea = linea + lista[i] + '/'

            linea = linea + lista[-2] + ')' + lista[-1]

        else:

            for i in range (1,longitud-1):
                linea = linea + lista[i] + '/'

            linea = linea + lista[-1] + ')'
    else:

        linea = linea + lista[-1] + ')'

    return linea

# Definimos una función para la escrituria de listas formadas por strings que han de ir separadas por comas

def escribe_linea_comas (lista):
    """ (list of strings) ---> string

    Transforma una lista compuesta por strings en una única linea separada por comas
    compuesta por los strings de la lista

    >>> escribe_linea_comas(['6900', '985', '158', '573'])
    '6900,1772,1772,1772'

    >>> escribe_linea_comas([])
    ''

    >>> escribe_linea_comas(['6900','casa'])
    '6900,casa'
    
    """

    lon = len(lista)
    linea = ''

    if lon > 1:
        for i in range (lon-1):
            linea = linea + lista[i] + ','
        linea = linea + lista[-1]

    if lon == 1:
        linea = lista[0]

    return linea


# PROGRAMA

import tkinter.filedialog

print('Introduce el archivo .csv con la información de material para ARPA')

#Lectura del archivo con los datos de los materiales

ruta = tkinter.filedialog.askopenfilename()
entrada = open(ruta,'r')
contenido = []

for linea in entrada:
    contenido.append(linea)
entrada.close()

print('Guarda tu archivo de salida')

#Abrimos el archivo de salida

ruta = tkinter.filedialog.asksaveasfilename()
salida = open(ruta,'w')

#Generación de la lista de laminas
'cada miembro es una lista con los datos de cada lamina'

lista_file=[]
for line in contenido:
    file_line = line.split(';')
    lista_file.append(file_line)

for line in lista_file:
    limpia_n(line)
    limpia_blancos_f(line)

limpia_blancos_f(lista_file)

lista_file.pop(0)
lista_file.pop(0)

cont = 0
lista_laminas = []
while lista_file[cont][0] != 'LAMINATES INFO':
    lista_laminas.append(lista_file[cont])
    cont = cont + 1

#Escribimos las láminas

for lamina in lista_laminas:
    for i in range (11):
        salida.write(lamina[i] + ',')

    salida.write(lamina[-1] + '\n')

salida.write('$$$$$$$$$$$$$$$$$$\n')

#Generamos las lineas correspondientes a los laminados

lista_stacks_CAI = lista_file[cont+2:]
lista_stacks = []
lista_CAI = []

for line in lista_stacks_CAI:
    lon = len(line)
    marcador = line.index('+')
    stack = []
    CAI = []
    for i in range(marcador):
        stack.append(line[i])
    for i in range(marcador+1,lon):
        CAI.append(line[i])
    lista_stacks.append(stack)
    lista_CAI.append(CAI)

stack_writting_list = []
CAI_writting_list = []

for stack in lista_stacks:
    stack_writting_list.append(laminados_arpa(stack))
for CAI in lista_CAI:
    CAI_writting_list.append(escribe_linea_comas(CAI))
    

#Escribimos las lineas correspondientes a los laminados y sus TAIS/CAIs

lon = len(lista_stacks)

for i in range(lon):
    if len(lista_CAI[i]) > 0:
        salida.write(stack_writting_list[i])
        salida.write(',')
        salida.write(CAI_writting_list[i])
        salida.write('\n')
    else:
        salida.write(stack_writting_list[i])
        salida.write('\n')

salida.close()


