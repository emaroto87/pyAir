# -*- coding: utf-8 -*-
"""
Created on Wed Dec 10 09:14:02 2025

@author: U69432
"""
import re
# Creador de comentarios de texto plano


def create_README(
    lines: list(str),
    path: str,
    max_line_chars: int = 80,
    append: bool = True
)
