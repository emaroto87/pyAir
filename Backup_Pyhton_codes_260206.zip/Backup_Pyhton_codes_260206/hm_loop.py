# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 12:56:51 2025

@author: U69432
"""

import subprocess
import time

hm_path = r'C:\Program Files\Altair\2021\hwdesktop\hw\bin\win64\hw.exe'
n = 3
while True:
    p = subprocess.Popen([hm_path])
    time.sleep(15)
    r = p.poll()
    if r is not None:
        if r == 0:
            print('Adquirida licencia')
            break
        else:
            print('Cerrando')
            p.terminate()
            time.sleep(2)
            if r is None:
                p.kill()
    else:
        print('Comprobando en 5s...')
        