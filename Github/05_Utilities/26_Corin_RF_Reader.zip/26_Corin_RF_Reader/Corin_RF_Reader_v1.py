# Importamos librerias que nos pueden servir

import tkinter.filedialog
import math
import statistics
import os


# Funciones de limpieza de la información de entrada

def limpia_n (lista):

    """ (lista) ---> lista
    Elimina el saltador de linea que se genera al final de una linea cuando se lee un fichero de texto y previamente
    ha sido convertido en una lista de listas (cada linea) mediante el separador ;

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0\n'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    """

    a = lista[-1]
    if '\n' in a:
        a = a[:-1]
        lista.pop()
        lista.append(a)

    return lista



def limpia_blancos_f (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información al final de una lista. Adicionalmente eliminamos
    el espaciador final.

    >>> elimina_blancos_f(['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0', '', ''])
    ['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0']

    """
    
    while lista[-1] == '':
        lista.pop()

    return lista

def elimina_blancos (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información dentro de la lista
    correspondiente a cada variable de diseño.

    >>> elimina_blancos(['UPSK0', '1001000', '1001677', 'UPSK0_i', '', '', '22', '20', '18', '14'])
    ['UPSK0', '1001000', '1001677', 'UPSK0_i', '22', '20', '18', '14']

    """
    
    while '' in lista:
        i = lista.index('')
        lista.pop(i)

    return lista

# Generamos una lista con los ficheros de salida CORIN contenidos en la carpeta donde se ejecuta el programa

listado_archivos = os.listdir()

listado_archivos_resultados = []

for elemento in listado_archivos:
    if elemento[-5:] == 'RES.1':
        listado_archivos_resultados.append(elemento)

# Abrimos el archivo de salida

corin_rf_summary = open('Corin_RF_Summary.rf' , 'w')
corin_rf_summary.write('Corin analysis, Min RF strain, Section RF Strain, Min RF stress, Section RF stress, Min RF delamination, Section RF delamination\n')

##############################################################################################

# Abrirmos cada uno de los archivos de resultados y buscamos los RF

for archivo in listado_archivos_resultados:
    entrada = open(archivo,'r')

    # Generamos listas con (seccion, rf strain, rf stress (hoff), rf delamination)

    lista_archivo = []
    lista_secciones = []
    lista_rf_strain = []
    lista_rf_stress = []
    lista_rf_delamination = []

    for linea in entrada:
        if len(linea) > 2:
            linea_res = linea.split()
            lista_archivo.append(linea_res)
        
    for lista in lista_archivo:
        if lista[0] == 'SECTION':
            lista_secciones.append(lista[2])
        
        if lista[0] == 'MAX.STRAIN':
            if lista_secciones[-1][-1] == '°':
                if lista[6] == '>100':
                    lista_rf_strain.append(100.0)
                else:
                    lista_rf_strain.append(float(lista[6]))
            else:
                if lista[5] == '>100':
                    lista_rf_strain.append(100.0)
                else:
                    lista_rf_strain.append(float(lista[5]))
                
        if lista[0] == 'STRESS(HOFF.)':
            if lista_secciones[-1][-1] == '°':
                if lista[6] == '>100':
                    lista_rf_stress.append(100.0)
                else:
                    lista_rf_stress.append(float(lista[6]))
            else:
                if lista[5] == '>100':
                    lista_rf_stress.append(100.0)
                else:
                    lista_rf_stress.append(float(lista[5]))      

        if lista[0] == 'DELAMINATION':
            if lista_secciones[-1][-1] == '°':
                if lista[6] == '>100':
                    lista_rf_delamination.append(100.0)
                else:
                    lista_rf_delamination.append(float(lista[6]))
            else:
                if lista[5] == '>100':
                    lista_rf_delamination.append(100.0)
                else:
                    lista_rf_delamination.append(float(lista[5]))


    lista_secciones.pop(0)

    min_rf_strain = min(lista_rf_strain)
    min_rf_strain_pos = lista_rf_strain.index(min_rf_strain)

    min_rf_stress = min(lista_rf_stress)
    min_rf_stress_pos = lista_rf_stress.index(min_rf_stress)

    min_rf_stress = min(lista_rf_stress)
    min_rf_stress_pos = lista_rf_stress.index(min_rf_stress)

    min_rf_delamination = min(lista_rf_delamination)
    min_rf_delamination_pos = lista_rf_delamination.index(min_rf_delamination)

    corin_rf_summary.write((archivo[:-6] + ',' +
    str(min_rf_strain) + ',' + lista_secciones[min_rf_strain_pos] + ',' +
    str(min_rf_stress) + ',' + lista_secciones[min_rf_stress_pos] + ',' +
    str(min_rf_delamination) + ',' + lista_secciones[min_rf_delamination_pos] + '\n'))
        
    entrada.close()
                         
corin_rf_summary.close()    
        
        
        

    

    
    



