# -*- coding: utf-8 -*-
"""
Spyder Editor 

This is a temporary script file.
"""

from tkinter.filedialog import asksaveasfilename
from tkinter.filedialog import askopenfilename
import tkinter as tk
import os
import sys
import pandas as pd
import xlwings as xw
from pyNastran.op2.op2 import OP2

from scipy.spatial import ConvexHull
from matplotlib import pyplot as plt
from common import general as gui

# Abreviaturas
# lista = ls
# dataframe = df
# ids de nodos = nids
# id de nodo = nid
#
__version__ = '1.0.2'
__author__ = 'E.Maroto'

folder_path = r'C:\Users\U69432\Documents\PyNastran141\examples\fem'
incfn = 'fem.incl'
op2fn = 'fem.op2'
f06fn = 'fem.f06'

incfp = os.path.join(folder_path, incfn)
op2fp = os.path.join(folder_path, op2fn)
f06fp = os.path.join(folder_path, f06fn)


# Default Values

__ENTITY_TYPES = [
    'NodeID',
    'ElementID',
    'SubcaseID'
]

__CASE_CONTROL_PARAMS = [
    'TITLE',
    'LABEL'
]


# ----------------------------------------------------------------------------

if __name__ == '__main__':
    o = load_OP2_results()

    entity_type_menu = gui.ui_menu(
        options=__ENTITY_TYPES,
        options_sort=False,
        is_main=False,
        label='entity_sel'
    )

    results_menu = gui.ui_menu(
        options=list(o.result_names),
        options_sort=True,
        is_main=False,
        label='result_sel'
    )

    main_menu_opts = [
        'Identificadores de subcasos',
        'Resultados'
    ]
    main_menu = gui.ui_menu(
        options=main_menu_opts,
        options_sort=False,
        is_main=True,
        label='main'
    )

    sel = ''
    while True:
        sel = main_menu.loop()
        if sel == 'Identificadores de subcasos':
            export_subcases_names(
                pyNastran_op2=o,
                param='TITLE'
            )
        elif sel == 'Resultados':
            results_menu.loop()
            if not (results_menu.selection == 'Back'):
                export_multi(
                    split_df_by_entity(
                        dataframe=get_result_from_op2(
                            o, results_menu.selection),
                        entity_type=entity_type_menu.loop(),
                        entities=ask_entities_ids_list(),
                    )
                )
                sel = ''
            else:
                sel = ''
        elif sel == 'Exit':
            break
        else:
            print('Ok')
            break
