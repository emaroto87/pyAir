# -*- coding: utf-8 -*-
"""
Created on Mon Apr 21 09:19:52 2025

@author: U69432
"""
import os
import sys
import xlwings as xw
import numpy as np
import pandas as pd
from scipy.spatial import ConvexHull
from matplotlib import pyplot as plt
from general import openEXCEL
from general import ui_menu
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

# ----------------------------------------------------------------------------

def parsing_list(user_input : str, sep=','):
    ls_in = user_input.split(sep=sep)
    ls_out =[item.strip() for item in ls_in]
    return ls_out

def ask_entities_fields_list():
    user_input = input('Enter list of fields : ')
    return parsing_list(user_input)

def select_fields(l:list):
    print('Available fields:')
    for (k,v) in enumerate(l):
        print ('\t',str(k),':\t',v)
    selected_fields = ask_entities_fields_list()
    return selected_fields

# Exporting
def df_to_excel_sheet(dataframe,sheet_name=None):
        print('Exporting data to Excel...', end='')
       
        # Opening xlwings
        app = xw.App(visible=False)
        wb = app.books[0]
        ws = wb.sheets[0]
        ws.activate()
        
        # Exporting data to default sheet1
        ws["A1"].options(
            pd.DataFrame, 
            header=1, 
            index=True, 
            expand='table').value = dataframe
        print('Done')
        
        # Re-labeling Default Sheet1
        if not(sheet_name is None):
            ws.name = sheet_name
        
        # Saving
        wb.save(
            path = asksaveasfilename(
                    title ='Save EXCEL file...', 
                    filetypes=(("EXCEL file", '*.xlsx'),),
                    defaultextension = ['*.xlsx'],
                    initialdir = os.getcwd()
                    ),
            )
        wb.close()
        print('Done')
# ----------------------------------------------------------------------------
def get_envelope_from_df(
        dataframe,
        export_to_excel=False,
        plot=False
        ):
    
    # Asking for fields
    ls_columns = select_fields(dataframe.columns)    
    data = dataframe[ls_columns]
    data.reset_index(inplace=True,drop=True)
    # print(data)
    points = data.to_numpy()
    # print(points)
    hull = ConvexHull(points)
    print(hull.vertices)
    envelope = dataframe[dataframe.index.isin(hull.vertices)]
    if export_to_excel == True:
        dfs_dict ={
            'Data' : dataframe,
            'Envelope' : envelope
            }
        df_to_excel_sheet(dfs_dict)
    
    if plot == True:          
        plt.plot(points[:,0], points[:,1], 'o')
        for vertice in hull.vertices:
            plt.plot(points[vertice, 0], points[vertice, 1], 'k-')
        plt.show()
    
    return envelope


xls_path = openEXCEL()

cwd = os.path.dirname(xls_path)
            
# Opening xlwings
wb = xw.Book(xls_path)
ws_names = ws_names = [wb.sheets[i].name for i in range(len(list(wb.sheets)))]


# Accessing applicaiton point table
gui= ui_menu(ws_names)
gui.show_options()
gui.get_user_selection()
ws_name=gui.selection
ws = wb.sheets[ws_name]
table = ws['A1'].expand('table')
table_data = table.raw_value
df = pd.DataFrame(table_data[1:], columns=table_data[0])
df.set_index('ID')

env = get_envelope_from_df(df)

