# -*- coding: utf-8 -*-
"""
Created on Tue Feb 17 15:14:59 2026

@author: U69432
"""

'''
Script para generar remaches de manera rápida en NASTRAN

Inputs:
    - Datos de remaches (localización, tipo, vector normal, radio, direción)
    - Malla 2D con propiedades aplicadas
    -

Pasos:
    1. Coger el punto de refencia (P) y su vector de dirección (Vd) y obtener
    los puntos proyectados en las superficies.
        1.a) Hecho el calculo de la proyección de un punto sobre cualquier
        plano
        1.b) Averiguar si el nodo proyectado está dentro o no de un elemento

    2. Generar CBUSH
    3. Calcular Huth
        3.1 Obtener el apilado del elemento
        3.2 Calcular E1,E2 del apilado en la dirección que se desee
        3.3 Calular Kshear en esa dirección.
    4. Proceso recursivo

'''


from enum import Enum
from Materials.composite import Laminate
from Materials.metallic import Metallic
from general import is_type
from pyNastran.bdf.bdf import BDF
from Geom.Euclidian_geom import Point
from Geom.Euclidian_geom import Vector
from Geom.Euclidian_geom import Plane_by3points as Plane
from math import ceil
__HEAD_TYPE_PTR = 'PTR'
__HEAD_TYPE_CSK = 'CSK'


class HeadType(Enum):
    PTR = 'protruding'
    CSK = 'countersunk'


class JointType(Enum):
    SINGLE = 'single_shear'
    DOUBLE = 'double_shear'


class Fastener:
    def __init__(self, Et: float, diameter: float, head_type: HeadType, rivet=True):
        # self.material = material
        self.Et = Et
        self.diameter = diameter
        self.head_type = head_type
        if rivet:
            self.is_bolt = False
            self.is_rivet = True
        else:
            self.is_bolt = True
            self.is_rivet = False


class Plate:
    pass


class MetallicPlate:
    def __init__(self,
                 material: Metallic,
                 thickness: float,
                 linked_FEM_eid: int = None):
        self.material = material
        self.thickness = thickness


class CompositePlate:
    def __init__(self,
                 laminate: Laminate,
                 linked_FEM_eid: int = None):
        self.laminate = laminate
        self.thickness = laminate.thickness

    def get_equivalent_moduli(self, angle_deg: float):
        '''
        Returns the equivalent values of Ex, Ey, Gxy and nuxy into another
        coordinate system which is defined as a rotation from the stacking
        coordinate system
        '''
        data = self.laminate.laminate_apparent_moduli(angle_deg)
        Ex_local = data['Ex']
        Ey_local = data['Ey']
        Gxy_local = data['Gxy']
        nuxy_local = data['nuxy']

        return Ex_local, Ey_local, Gxy_local, nuxy_local


class Connector:
    def __init__(
            self,
            connector_id: int,
            ref_point: Point,
            shank_dir: Vector,
            fastener: Fastener,
            proj_points=None,
            proj_elements=None,
            shank_diam=None):

        self.ref_point = ref_point
        self.shank_dir = shank_dir
        self.shank_diam = shank_diam
        self.proj_elements = proj_elements
        self.proj_points = proj_points
        self.connector_id = connector_id


def huth(plate1: Plate, plate2: Plate, fastener: Fastener) -> float:

    # data from plate 1
    t1 = plate1.thickness
    E1 = plate1.material.Et
    plate1_type = 'METALLIC' if type(plate1) == MetallicPlate else 'COMPOSITE'

    # data from plate 2
    t2 = plate2.thickness
    E2 = plate2.material.Et
    plate2_type = 'METALLIC' if type(plate2) == MetallicPlate else 'COMPOSITE'

    # data from fastener
    Er = fastener.Et
    d = fastener.diameter

    # Selecting the parameters "a" and "b"
    if plate1_type == 'COMPOSITE' and plate2_type == 'COMPOSITE':
        a = 2/3
        b1 = 4.2
        b2 = 4.2
    elif plate1_type == 'COMPOSITE' and plate2_type == 'METALLIC':
        a = 2/3
        b1 = 4.2
        b2 = 3.0
    elif plate1_type == 'METALLIC' and plate2_type == 'COMPOSITE':
        a = 2/3
        b1 = 3.0
        b2 = 4.2
    elif plate1_type == 'METALLIC' and plate2_type == 'METALLIC':
        if fastener.is_bolt:
            a = 2/3
            b1 = 3.0
            b2 = 3.0
        if fastener.is_rivet:
            a = 2/5
            b1 = 2.2
            b2 = 2.2
    else:
        raise ValueError(
            'plate1 and/or plate2 are neither METALLIC nor COMPOSITE types.'
            'Please check'
        )
        return None

    c1 = ((t1 + t2)/(2*d))**a
    c2 = (b1/(t1*E1) + b2/(t2*E2) + b1/(2*t1*Er) + b2/(2*t2*Er))

    c = c1 * c2
    k = 1/c

    return k


# class PilotPoint:
#     def __init__(ref_Point: Point, drill_vector: Vector: diameter)


launcher_path = r'C:\Users\U69432\Desktop\PyAir\FEM\03_FEM_fastener_generator\Test\01_HF_2D_DFEM\HF_2D_DFem_v04_RBE2_SS_d70mm.bdf'
model = BDF()
model.read_bdf(
    bdf_filename=launcher_path,
    validate=False,
    xref=True,
    punch=False,
    read_includes=True,
    save_file_structure=False)

# Vectores directores
v_dir1 = Vector(Point(0, 0, 0,), Point(0, 0, 1))

# Remaches
fast_pr6115_3 = Fastener(110000, 4.8, HeadType.PTR)

# Connectores
conn1 = Connector(1, fast_pr6115_3, Point(
    14228.16, -590.611, 2804.845), v_dir1)
conn2 = Connector(2, fast_pr6115_3, Point(
    14252.60, -590.611, 2806.521), v_dir1)
connectors = {conn1.connector_id: conn1, conn2.connector_id: conn2}

#
nodes = model.nodes
elements = model.elements
#
planes = {}

# Genero la información de todos los planos que tiene el modelo. En el caso
# de elementos CQUAD4, cada uno los divido en 2 CTRIA3.
for eid, e in elements.items():
    if e.type.upper() in ['CQUAD4', 'CTRIA3']:
        e_nodes = e.nodes
        for i in range(ceil(len(e_nodes)/3)):
            n1 = e.nodes_ref[0+i]
            n2 = e.nodes_ref[1+i]
            n3 = e.nodes_ref[2+i]
            p1 = Point(*n1.xyz)
            p2 = Point(*n2.xyz)
            p3 = Point(*n3.xyz)
            s = Plane(p1, p2, p3, eid)
            planes[f'{e.type}_{eid}_S{i}'] = s
    else:
        pass


for con_id, conn in connectors.items():
    proj_elems = []
    proj_points = []
    last_plane_id = -9
    for label, plane in planes.items():
        try:
            projection = plane.proyect_point(conn.ref_point, conn.shank_dir)
            if plane.intriangle(projection):
                if plane.plane_id != last_plane_id:
                    print(last_plane_id, plane.plane_id)
                    proj_elems.append(plane.plane_id)
                    proj_points.append(projection)
                    last_plane_id = plane.plane_id

        except:
            pass

    conn.proj_elements = proj_elems
    conn.proj_points = proj_points
    print(con_id, proj_elems)
# El problema que estoy teniendo en este punto es si los puntos proyectados
# cae justo en un nodo ya existente, me da todos los elementos que connectan
# a ese nodo.

    # -------------------------------------------------------------------TESTING
Al_7075 = Metallic(name='Al_7075',
                   norm=None,
                   shape='Sheet',
                   temp_treat='T3',
                   area_range=None,
                   thick_range='0.53-1.57',
                   basis='A',
                   Et=72395,
                   Ec=73744,
                   Ftu=413.68,
                   Fty=303.37,
                   Fcy=248.21,
                   Fsu=255.10,
                   Fbru_ed_1p5=None,
                   Fbry_ed_1p5=None,
                   Fbru_ed_2p0=None,
                   Fbry_ed_2p0=None,
                   e=0.12
                   )
plate1 = MetallicPlate(Al_7075, 2.0)
plate2 = MetallicPlate(Al_7075, 3.0)
fast = Fastener(Et=100000.0, diameter=4.0, head_type='PTR')
