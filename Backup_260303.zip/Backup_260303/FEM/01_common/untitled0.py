# -*- coding: utf-8 -*-
"""
Created on Wed Dec 17 11:24:51 2025

@author: U69432
"""
# ARPA

import numpy as np
import scipy as sci
from math import sin
from math import cos


def integral_ss(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 - sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 - num2/den2
    return out


def integral_cc(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 + sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 + num2/den2
    return out


def integral_sc(A: float, B: float, x: float) -> float:
    if A == B:
        out = - ((cos(A*x))**2)/(2*A)
    else:
        num1 = cos((A-B)*x)
        den1 = 2*(A-B)
        num2 = cos((A+B)*x)
        den2 = 2*(A+B)
        out = -num1/den1 - num2/den2
    return out


def fss(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_ss(A, B, x_ini) - integral_ss(A, B, x_end)


def fcc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_cc(A, B, x_ini) - integral_cc(A, B, x_end)


def fsc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_sc(A, B, x_ini) - integral_sc(A, B, x_end)


def f1jl_m(D11m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D11m_star * fss(j, l, ym1, ym2)


def f1jl(d1y_list: list[tuple], j: float, l: float) -> float:
    f1jl = 0
    for D11m_star, ym1, ym2 in d1y_list:
        f1jl += f1jl_m(D11m_star, ym1, ym2, j, l)
    return f1jl


def f2jl_m(D22m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D22m_star * fss(j, l, ym1, ym2)


def f3jl_m(D33m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D33m_star * fcc(j, l, ym1, ym2)


def f4jl_m(D12m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D12m_star * fss(j, l, ym1, ym2)


def f5jl_m(D13m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D13m_star * fsc(j, l, ym1, ym2)


def f6jl_m(D23m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    return D23m_star * fsc(j, l, ym1, ym2)
