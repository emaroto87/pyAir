dict# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os 
import sys
import pandas as pd
import xlwings as xw

## Abreviaturas
# lista = ls
# dataframe = df
# ids de nodos = nids
# id de nodo = nid
#


folder_path = r'C:\Users\U69432\Documents\PyNastran141\examples\fem'
incfn = 'fem.incl'
op2fn = 'fem.op2'
f06fn = 'fem.f06'

incfp = os.path.join(folder_path,incfn)
op2fp = os.path.join(folder_path,op2fn)
f06fp = os.path.join(folder_path,f06fn)


############################### AUX ###############################

##### GUI

### Open File
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename
def openOP2():
    op2fp = askopenfilename(
        title ='Open OP2', 
        filetypes=(("Nastran OP2 file", '*.op2'),),
        multiple = False,
        defaultextension = ['.op2'],
        initialdir = os.getcwd()
        )
    if op2fp =='':
        print('No file has been selected.')
    return op2fp

def openBDF():
    bdffp = askopenfilename(
        title ='Open NASTRAN BDF file', 
        filetypes=(
            ("Nastran BDF file", '*.bdf'),
            ("Data file", '*.dat'),
            ("Include file", '*.incl'),
            ),
        multiple = False,
        defaultextension = ['*.bdf'],
        initialdir = os.getcwd()
        )
    print (bdffp)
    if bdffp =='':
        print('No file has been selected.')
    return bdffp
    


# Exporting

def export_single(dataframe,option='csv'):
    assert(dataframe._typ==pd.DataFrame._typ)
    assert(type(option) is str)
    
    if option.upper()=='CSV':
        dataframe.to_csv(
                asksaveasfilename(
                title ='Save CSV file...', 
                filetypes=(("CSV file", '*.csv'),),
                defaultextension = ['.csv'],
                initialdir = os.getcwd()
                ),
            header = True
            )

    elif option.upper()=='XLS':
        app = xw.App(visible=False)
        wb = app.books[0]
        ws = wb.sheets[0]
        ws.activate()
        print('Exporting data to Excel...', end='')
        ws["A1"].options(
            pd.DataFrame, 
            header=1, 
            index=True, 
            expand='table').value = dataframe
        print('Done')
        wb.save(
            path = asksaveasfilename(
                    title ='Save EXCEL file...', 
                    filetypes=(("EXCEL file", '*.xlsx'),),
                    defaultextension = ['*.xlsx'],
                    initialdir = os.getcwd()
                    ),
            )
        wb.close()
        
    else:
        return


def export_multi(dict_dataframes):
    print('Exporting data to Excel...', end='')
    app = xw.App(visible=False)
    wb = app.books[0]
    ws_labels = list(dict_dataframes.keys())  
    
    for label in ws_labels:
        wb.sheets.add(str(label))
        df = dict_dataframes[label]
        ws = wb.sheets[str(label)]
        ws.activate()
        ws["A1"].options(
            pd.DataFrame, 
            header=1, 
            index=False, 
            expand='table').value = df
    print('Done')
  
    # Deleting default Sheet
    wb.sheets[-1].delete()

        
    # Saving
    wb.save(
        path = asksaveasfilename(
                title ='Save EXCEL file...', 
                filetypes=(("EXCEL file", '*.xlsx'),),
                defaultextension = ['*.xlsx'],
                initialdir = os.getcwd()
                ),
        )
    wb.close()



# ========================
#
# PARTE DE LECTURA DE BDF
#
# ========================
#### Ejemplos para leer BDF y conseguir datos de él

from pyNastran.bdf.bdf import BDF 
from pyNastran.op2.op2 import OP2 
# # Load the model
# model = bdf()
# model.read_bdf( 
#     bdf_filename = incfp,
#     read_includes = True,
#     validate = False,
#     xref = True,
#     )

# # Imprimir datos del modelo 
# print(model.get_bdf_stats)

# # Acceder a nodos
# nodes = model.nodes # Se trata de un diccionario k=nid v=obj nodo
# nids = list(model.nodes.keys())
# n1=nodes[nids[0]]

# # Acceder a elementos
# elems = model.elements
# eids = list(elems.keys())
# e1 = elems[eids[0]]
            
# print(e1.get_stats()) # Proporciona información del elementoe1

# # cosas utiles
# e1.type # me proporciona el tipo de elemento que es
# e1.object_attributes() # proporciona los atributos
# e1.object_method()
# e1.pid_ref # accedes a la propiedad vinculada al elemento

# # Mapear
# model.get_property_id_to_element_ids_map()
# #
# #
# #
# #
# #
# #
# # Lista de funciones que podrian ser utiles.
# # 1. Dado un modelo con remaches CBUSH + RBE3, generar los PBUSH
# # 2. Dada una lista de remaches 



res = OP2()
try:
    op2fp=openOP2()
    res.read_op2(op2fp,build_dataframe=True)
except FileNotFoundError:
    quit()



def split_df_by_entity(dataframe,entities,entity_type='NodeID'):
    # check
    if not(type(dataframe) is type(pd.DataFrame())):
        error_msg = 'dataframe is not a DataFrame type'
        raise TypeError(error_msg)
        return None
    else:
        df = dataframe
    
    if not(type(entities) is list):
        error_msg = 'entities is not a list'
        raise TypeError(error_msg)
        return None
    
        
#   Nota: Habria que comprobar que el df contiene la columna correspondiente
    if entity_type in ['NodeID','ElementID','SubcaseID']: 
        dfs_per_entity_dict = {}
        print('Spliting data by : ',entity_type)
        for entity in entities:
            print (entity,'...',end='')
            df_per_entity = df[df[entity_type]==entity]
            dfs_per_entity_dict[entity]=df_per_entity
            print('Done')
        return dfs_per_entity_dict
    else:
        return None

print(res.result_names) # Para ver los tipos de resultados disponibles
subcases = res.case_control_deck.subcases # devuevle un diccionario {k:sid, v:subcase_obj}
sids = list(subcases.keys())
s = subcases[sids[1]].params
s['TITLE'] # te proporciona el titulo del subcaso
s['LABEL'] # te proporciona la etiqueta

# Resultados con la opcion DISP activada
res.displacements 
disp1 = res.displacements[1570]
disp2 = res.displacements[14]

sids

# Resultados con la opcion ELFORCE activada
res.cbar_force
res.cbeam_force
res.cquad4_force
res.ctria3_force
# Resultados con la opcion SPCFORCES activada
res.spc_forces

# Para cualquier resultado puedo hacer....
o = res.cquad4_force
o_subcases = o.keys()


# Funcion para filtrar en funcion de Entities ids y tipo d resultado.

# ejemplo desplazamientos
nid =1003014
disp= res.displacements
ls_filtered_dfs = [disp[sid].data_frame.query('NodeID == %s' % nid) for sid in sids]
df = pd.concat(ls_filtered_dfs)
df.index = sids
df.index.name = 'Subcase'

# ejemplo spcforces
spcf = res.spc_forces
sids = list(spcf.keys())
ls_filtered_dfs = [spcf[sid].data_frame.query('NodeID == %s' % nid) for sid in sids]
df = pd.concat(ls_filtered_dfs)
df.index = sids
df.index.name = 'Subcase'

# Ejemplo CBAR
eid = 1003014
cbarf = res.cbar_force
ls_filtered_dfs = [cbarf[sid].data_frame.quer('ElementID == %s' % eid) for sid in sids]
df = pd.concat(ls_filtered_dfs)
df.index = sids
df.index.name = 'Subcase'

##### 1. Creamos Dataframe de todas las SPC forces
#
# Inputs necesarios
ls_nids_filt = [1900001,1900002]
ls_sids_filt = [8355,8360]



spcf = res.spc_forces
sids = list(spcf.keys())
ls_dfs = []
for sid in sids:
    df = spcf[sid].data_frame
    df['SubcaseID']=sid
    ls_dfs.append(df)

df = pd.concat(ls_dfs)
df_filt_by_node = df[df['NodeID'].isin(ls_nids_filt)]
df_filt_by_subcase = df[df['SubcaseID'].isin(ls_sids_filt)]



    
    
    
            
            
            
            
            
    
    
    
        
    
    
    


