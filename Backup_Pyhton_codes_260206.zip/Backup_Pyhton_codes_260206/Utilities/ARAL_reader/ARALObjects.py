# -*- coding: utf-8 -*-
"""
Archivo que contiene los objetos necesarios para la macro ARALInputReader

Autor: Jorge Pérez Lozano (u70148)
"""

import pandas as pd
from tkinter.filedialog import asksaveasfilename
import os

max_num_panels = 40
max_num_str = 15

class GeometrySingle():
    def __init__(self,raw):
        self.raw = raw
        self.super_st_id = 0
        self.st_id = []
        self.p1_id = []
        self.p2_id = []
    
    def parse_str(self,raw):
        # Solo válido para larguerillos normalizados
        stringer_raw = raw[0].strip()
        stringer_fem = raw[1].strip().split(',')
        stringer = stringer_raw.split(',')
        stringer_id = stringer[:5]
        stringer_type = int(stringer_id[-1])
        geom_raw = stringer[5:]
        # STR SHEET/MACH (CDEX)	B1	T1	B2	T2	B3	T3	STR ATTACH (TUNI)
        # 0                     1   2   3   4   5   6   7                
        stringer_geom = ['','','','','','','','']
        if stringer_type == 1:
            stringer_geom[:5] = geom_raw[:-1]
            stringer_geom[-1] = geom_raw[-1]
        elif stringer_type == 2:
            stringer_geom[1:5] = geom_raw[:-1]
            stringer_geom[-1] = geom_raw[-1]
        elif stringer_type == 3:
            stringer_geom = geom_raw
        elif stringer_type == 4 or stringer_type == 5:
            stringer_geom[1:] = geom_raw
        elif stringer_type == 6:
            stringer_geom[3:5] = geom_raw
        elif stringer_type == 7 or stringer_type == 8:
            stringer_geom[3:7] = geom_raw
        else: 
            print('The stringer specified in the geometry file is not valid')
        
        stringer_id.extend(stringer_geom)
        fem = []
        for i in range(max_num_str):
            if i < len(stringer_fem):
                fem.append(stringer_fem[i])
            else:
                fem.append('')
        stringer_format = stringer_id
        stringer_format.extend(fem)
            
        return stringer_format
    
    def parse_panel(self,raw):
        p_raw = raw[0].strip().split(',')
        print(p_raw)
        p_fem = raw[1].strip().split(',')
        
        if len(p_raw) == 6:
            panel = p_raw
        elif len(p_raw) == 3:
            panel = [p_raw[0],'','','',p_raw[1],p_raw[2]]
        
        fem = []
        
        for i in range(max_num_panels):
            if i < len(p_fem):
                fem.append(p_fem[i])
            else:
                fem.append('')
        panel_format = panel
        panel_format.extend(fem)
        
        return panel_format
    
    def parse_padup(self,raw):
        padup_raw = raw.strip().split(',')
        padup = []
        for i in range(4):
            if i < len(padup_raw):
                padup.append(padup_raw[i])
            else:
                padup.append('')        
        return padup
    
    def parse_line(self):
        # raw = self.raw
        # print(raw)
        # if '+' in raw:
        #     raw = raw.replace('+\n','')
            
        str_id = self.raw[0].strip().split(',')
        stringer = self.parse_str(self.raw[1:3])
        p1 = self.parse_panel(self.raw[3:5])
        p2 = self.parse_panel(self.raw[5:7])
        padup = self.parse_padup(self.raw[7])
        element = str_id
        element.extend(stringer)
        element.extend(p1)
        element.extend(p2)
        element.extend(padup)
        return element
        
class Geometry():
    def __init__(self,geom_file):
        elements = []

        with open(geom_file,'r') as geom:
            element = ''
            for line in geom:
                if '$' in line:
                    elements.append(element)
                    element = ''
                else:
                    element += line
            geom.close()
          
        self.material = elements[0]
        self.diagram = elements[1]       
        elements = elements[2:] # --> hay que meterlo a objeto element

        self.elm_dict = {}

        for elm in elements:
            print(elm)
            if '+' in elm:
                elm = elm.replace('+\n','')
            print(elm)
            element = elm.split('\n')
            elm_id = element[0][:element[0].find(',')]
            self.elm_dict[elm_id] = element
            
    def geometry_sheet(self):
        df_list = []
        for raw_list in self.elm_dict.values():
            single = GeometrySingle(raw_list).parse_line()
            df_list.append(single)
        self.df = pd.DataFrame(df_list)
       
        header1 = ['Element ID (IDLAR)','SKIN SIDE (RVLAR)','STR POSITION (PSLAR)',
                      'TRANSVERSAL STIFFENER (CTLAR)','STR MAT (IMAT)',
                      'STR LENGTH (LONG)','CLAMPING COEF (CEMP)',
                      'RIB ATTACH (IRBF)','STR TYPE (TIPO)','STR SHEET/MACH (CDEX)',
                      'B1','T1','B2','T2','B3','T3','STR ATTACH (TUNI)']
        
        header2 = [f'STR NAS ELEMENT {i}' for i in range(1,max_num_str+1)]
        
        header3 = ['ID PANEL (IDPAN1)','PANEL MAT (IMAT1)','PANEL WIDTH (BPAN1)',
        'PANEL THICK (TPAN1)','NAS ELEMS ANG (ALFA1)','NAS Z AXIS (IZL1)']
        
        header4 = ['ID PANEL (IDPAN2)','PANEL MAT (IMAT2)','PANEL WIDTH (BPAN2)',
            'PANEL THICK (TPAN2)','NAS ELEMS ANG (ALFA2)','NAS Z AXIS (IZL2)']
        
        header5 = [f'PANEL NAS ELEMEN ELEMENT {i}' for i in range(1,max_num_panels+1)]
        
        header6 =['PAD WIDTH (BPAD)','SKIN THICK (TPAD)','RIVET PITCH (PREM)',
                              'RIVET TYPE (TREM)']
        
        header = header1 + header2 + header3 + header5 + header4 + header5 + header6
        print(header)
        self.df.columns = header
        return self.df
    
    def export_to_excel(self):
        excel_root = asksaveasfilename(
            title ='Select the excel book to save the Geometry file data. If it exists, it will be rewritten', 
            filetypes=(("xlsx",'*.xlsx'),),
            defaultextension = ['.xlsx'],
            initialdir = os.getcwd())
        self.df.to_excel(excel_root, 'Geometry', index = False,)
        
class ElementSingle():
    def __init__(self,raw):
        self.raw = raw
        self.df = ''
    
    def parse_element(self,raw):
        element = raw.strip().split(',')
        
        element = [x for x in element if x != '']
        
        return element
    
class Element():
    def __init__(self,elm_file):
        self.elements = []
        with open(elm_file,'r') as elm:
            file_raw = elm.readlines()
        for i in range(2,len(file_raw) + 1,2):
            elm_line = file_raw[i-2:i-1]
            elm_line = elm_line[0].replace('\n','')
            self.elements.append(elm_line)
            
    def element_sheet(self):
        df_list = []
        for raw_list in self.elements:
            single = ElementSingle(raw_list).parse_element(raw_list)
            df_list.append(single)
                
        self.df = pd.DataFrame(df_list)
        self.df.columns = ['Element ID (IDLAR)','STR LOADS (CODCAL)',
                           'PANEL LOADS  (CODCAR)','FEM CORRECTION FACTOR  (FCAR)',
                           'BUCK PANEL THICK (TMAX)']
    
        return self.df
    
    def export_to_excel(self):
        excel_root = asksaveasfilename(
            title ='Select the excel book to save the Elements file data. If it exists, it will be rewritten', 
            filetypes=(("xlsx",'*.xlsx'),),
            defaultextension = ['.xlsx'],
            initialdir = os.getcwd())
        self.df.to_excel(excel_root, 'Elements', index = False,)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    