# Funciones de limpieza del archivo de entrada

def limpia_n (lista):

    """ (lista) ---> lista
    Elimina el saltador de linea que se genera al final de una linea cuando se lee un fichero de texto y previamente
    ha sido convertido en una lista de listas (cada linea) mediante el separador ;

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0\n'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    """

    a = lista[-1]
    if '\n' in a:
        a = a[:-1]
        lista.pop()
        lista.append(a)

    return lista



def limpia_blancos_f (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información al final de una lista. Adicionalmente eliminamos
    el espaciador final.

    >>> elimina_blancos_f(['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0', '', ''])
    ['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0']

    """
    
    while lista[-1] == '':
        lista.pop()

    return lista


#Lectura del archivo con los datos de los laminados


import tkinter.filedialog

print('Introduce el archivo .csv con la información geometrica de los elementos ARPA')

ruta = tkinter.filedialog.askopenfilename()
entrada = open(ruta,'r')
contenido = []

for linea in entrada:
    contenido.append(linea)
entrada.close()


#Generación de la lista de elementos (lista de listas)
'cada miembro es una lista con los datos de elemento'

lista_elementos=[]
for linea in contenido:
    elemento = linea.split(';')
    lista_elementos.append(elemento)

for elemento in lista_elementos:
    limpia_n(elemento)
    limpia_blancos_f(elemento)

limpia_blancos_f(lista_elementos)

lista_elementos = lista_elementos[2:]

#Abrimos el archivo de salida

print('Guarda tu archivo de salida')

ruta = tkinter.filedialog.asksaveasfilename()
salida = open(ruta,'w')

#Escribimos

for elemento in lista_elementos:

 
    # antes de escribir nos extraemos los elementos Nastran STR, PANEL1. Esto lo hacemos para saber cuantos elementos nastran
    # hay para de estar forma lograr escribir el último de ellos sin coma

    str_elements=[]
    panel1_elements=[]
    
    for i in range (18,23):
        str_elements.append(elemento[i])
    for i in range (28,38):
        panel1_elements.append(elemento[i])

    n_str_blank = str_elements.count('')
    n_panel1_blank = panel1_elements.count('')
        

    # primera linea
    salida.write(elemento[0] + ',' + elemento[1] + ',' + elemento[2] + ',' + elemento[3] + '\n')

    # segunda linea
    if elemento[8] == 'P0':
        salida.write(elemento[4] + ',' + elemento[5] + ',' + elemento[6] + ',' + elemento[7] + ',' + elemento[8] + '\n')

    else:
        (salida.write(elemento[4] + ',' + elemento[5] + ',' + elemento[6] + ',' + elemento[7] + ',' + elemento[8] + ','
        + elemento[9] + ',' + elemento[10] + '\n'))

    # tercera linea
    if elemento[4] == 'L':
        salida.write(elemento[11] + ',' + elemento[12] + ',' + elemento[13] + ',' + elemento[14] + ',' + elemento[17] + '\n')

    elif elemento[4] == 'T':
        salida.write(elemento[11] + ',' + elemento[12] + ',' + elemento[13] + ',' + elemento[14] + ',' + elemento[17] + '\n')

    else:
        (salida.write(elemento[11] + ',' + elemento[12] + ',' + elemento[13] + ',' + elemento[14] + ',' + elemento[15] + ','
        + elemento[16] + ',' + elemento[17] + '\n'))

    # cuarta linea
    for i in range (18,22-n_str_blank):
        salida.write(elemento[i] + ',')

    salida.write(elemento[22-n_str_blank] + '\n')

    # quinta linea
    salida.write(elemento[23] + ',' + elemento[24] + ',' + elemento[25] + ',' + elemento[26] + ',' + elemento[27] + '\n')

    # sexta linea
    for i in range (28,37-n_panel1_blank):
        salida.write(elemento[i] + ',')

    salida.write(elemento[37-n_panel1_blank] + '\n')

    # septima linea
    salida.write(elemento[38] + ',' + elemento[39] + ',' + elemento[40] + ',' + elemento[41] + ',' + elemento[42] + '\n')

    # octava linea

    a = len(elemento)
    
    for i in range (43,(a-1)):
        salida.write(elemento[i] + ',')

    salida.write(elemento[-1] + '\n')

    salida.write('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n')

salida.close()
