# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 15:08:03 2026

@author: U69432
"""

import paramiko

# Define server credentials
hostname = 'mln52'
username = 'u69432'
password = 'Temp""53457341M'
command = 'ls -l'

# Create an SSH client
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

try:
    # Connect to the server
    client.connect(hostname, username=username, password=password)

    # Execute the command
    stdin, stdout, stderr = client.exec_command(command)

    # Print the command output
    print(stdout.read().decode())

finally:
    # Close the connection
    client.close()
