ECHO *Id("HyperWorks v8.0")>preferences.mvw
ECHO *BeginDefaults()>>preferences.mvw
ECHO 	*BeginFePreDefaults()>>preferences.mvw
ECHO 		*BeginMenu(FastSizing_menu,"**Fast Sizing**")>>preferences.mvw
ECHO 			*MenuItem(FastSizing_item,"Open Fast Sizing", TCL,"%CD:\=/%/FastSizing_GUI_Main.tcl")>>preferences.mvw
ECHO 		*EndMenu()>>preferences.mvw
ECHO 	*EndFePreDefaults()>>preferences.mvw
ECHO *EndDefaults()>>preferences.mvw
SETX HW_CONFIG_PATH %CD%
MSG %USERNAME% "Fast Sizing pull-down menu is now available in HyperMesh Desktop!"
