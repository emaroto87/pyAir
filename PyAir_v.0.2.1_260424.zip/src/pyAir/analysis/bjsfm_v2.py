# -*- coding: utf-8 -*-
from typing import Optional, List, Union, Tuple
from structural.ply import Ply
from materials.composite import Orthotropic
import numpy as np
import cmath
import math

from structural.laminate import Laminate

PI = math.pi
RAD = PI / 180.0


def select_roots_from_coef(A_inv: np.ndarray) -> Tuple[float]:
    """
    Selección de R1, R2 en UNLODED / LOADED
    """
    COEF = np.zeros(5)
    COEF[0] = A_inv[1, 1] * 1e6
    COEF[1] = -2.0 * A_inv[1, 2] * 1e6
    COEF[2] = (2.0 * A_inv[0, 1] + A_inv[2, 2]) * 1e6
    COEF[3] = -2.0 * A_inv[0, 2] * 1e6
    COEF[4] = A_inv[0, 0] * 1e6

    roots = np.roots(COEF)

    # Ogonowski: escoger las 2 raíces con Im>0
    pos = [r for r in roots if r.imag > 0.0]
    if len(pos) != 2:
        raise RuntimeError("Las raíces complejas no son válidas")

    # ordenar por magnitud
    pos = sorted(pos, key=lambda r: abs(r))
    return pos[1], pos[0]  # R1, R2


def build_amatrix(R1, R2):
    S1, T1 = R1.real, R1.imag
    S2, T2 = R2.real, R2.imag
    return np.array([
        [T1 + 1.0, -S1, T2 + 1.0, -S2],
        [-S1, -(T1 + 1), S2, -(T2 + 1)],
        [-1.0, -T1, -1.0, -T2],
        [S1, -(1.0 + T1), S2, -(1.0 + T2)],
    ], dtype=np.complex128)


def build_akmatrix(R1, R2):
    S1, T1 = R1.real, R1.imag
    S2, T2 = R2.real, R2.imag
    return np.array([
        [T1, S1, T2, S2],
        [0.0, 1.0, 0.0, -1.0],
        [2*S1*T1, S1*S1 - T1*T1, 2*S2*T2, S2*S2-T2*T2],
        [-T1/(S1*S1+T1*T1), S1/(S1*S1+T1*T1), -
         T2/(S2*S2+T2*T2), S2/(S2*S2+T2*T2)]
    ], dtype=np.complex128)


def build_bvector(
        m: int,
        diameter: float,
        CZERO: complex,
        CPOS: np.ndarray,
        CNEG: np.ndarray
) -> np.ndarray:
    mn = m - 1
    B = np.zeros(4, dtype=np.complex128)
    if mn == 0:
        # Caso especial m=1
        B[0] = -CZERO*diameter / 2.0
        B[1] = 0.0
        B[2] = -CZERO*diameter / 2.0
        B[3] = 0.0
    else:
        factor = diameter / (2.0*(mn+1))
        B[0] = -CPOS[mn]*factor
        B[1] = -1j * CPOS[mn].imag * factor
        B[2] = -CNEG[mn] * factor
        B[3] = -1j * CNEG[mn].imag * factor
    return B


def build_cpos_cneg(P, Mmax=45):
    PI = math.pi
    PI2 = PI/2
    Pnorm = 4.0*P / PI

    # ---- m = 0 (CZERO) ---------
    CZERO = Pnorm * PI2

    # ---- m >=1 (Armonicos) ---------
    CPOS = np.zeros(Mmax + 1, dtype=np.complex128)
    CNEG = np.zeros(Mmax + 1, dtype=np.complex128)
    for m in range(1, Mmax+1):
        if m == 1:
            CPOS[m] = Pnorm*PI2
            CNEG[m] = Pnorm*PI2
        else:
            CPOS[m] = Pnorm * math.sin((m-1)*PI2) / (2.0 * (m-1))
            CNEG[m] = CPOS[m]

    return CZERO, CPOS, CNEG


def unloaded_hole_exact(
    laminate: Laminate,
    px: float,
    diameter: float,
    beta_deg: float,
    dist_points: np.ndarray,
    angles_deg: np.ndarray
):

    AI = laminate.A_inv
    R1, R2 = select_roots_from_coef(AI)

    beta = beta_deg * RAD
    a = diameter / 2.0

    nd = len(dist_points)
    na = len(angles_deg)

    stress = np.zeros((3, nd, na))
    u = np.zeros((nd, na))
    v = np.zeros((nd, na))

    for i, d in enumerate(dist_points):
        r = a + d
        for j, ang in enumerate(angles_deg):
            theta = ang * RAD

            x = r * math.cos(theta)
            y = r * math.sin(theta)

            z1 = x + R1 * y
            z2 = x + R2 * y

            XI1 = cmath.sqrt(z1*z1 - a*a * (1 + R1*R1))
            XI2 = cmath.sqrt(z2*z2 - a*a * (1 + R2*R2))

            # selección de rama (IGUAL que Fortran)
            if (z1 / XI1).real < 0:
                XI1 = -XI1
            if (z2 / XI2).real < 0:
                XI2 = -XI2

            COMPLX = 1j

            COM1 = (
                R2*math.sin(2*beta)
                + 2*math.cos(beta)**2
                + COMPLX*(2 - R2*math.sin(beta)**2)
            )
            COM2 = (
                R1*math.sin(2*beta)
                + 2*math.cos(beta)**2
                + COMPLX*(2*R1 - math.sin(beta)**2)
            )

            DEN1 = 2*a*(R1 - R2)*(1 + COMPLX*R1)
            DEN2 = 2*a*(R1 - R2)*(1 + COMPLX*R2)

            PHI1 = COMPLX*px*diameter*COM1*XI1/(2*DEN1)
            PHI2 = COMPLX*px*diameter*COM2*XI2/(2*DEN2)

            sx = 2*((R1*R1*PHI1).real + (R2*R2*PHI2).real)
            sy = -(PHI1 + PHI2).real
            sxy = -2*((R1*PHI1).real + (R2*PHI2).real)

            stress[0, i, j] = sx
            stress[1, i, j] = sy
            stress[2, i, j] = sxy

            u[i, j] = 2*(PHI1.real + PHI2.real)
            v[i, j] = 2*((AI[0, 1]*PHI1.real) + (AI[0, 1]*PHI2.real))

    return stress, u, v


def loaded_hole_exact(
    laminate,
    P,
    diameter,
    alpha_deg,
    dist_points,
    angles_deg,
    Mmax=45
):
    """
    Traducción directa de SUBROUTINE LOADED del BJSFM (cap. 7)
    """
    import numpy as np
    import cmath
    import math

    PI = math.pi
    PI2 = PI / 2.0
    RAD = PI / 180.0
    COMPLX = 1j
    Pnorm = 4.0 * P / PI
    a = diameter / 2.0
    alpha = alpha_deg * RAD

    a_mat = laminate.Abar

    # -------------------------------
    # Raíces complejas
    # -------------------------------
    R1, R2 = select_roots_from_coef(a_mat)

    # -------------------------------
    # Coeficientes de carga
    # -------------------------------
    CZERO, CPOS, CNEG = build_cpos_cneg(P, Mmax)

    # -------------------------------
    # Resolver A1/A2 ármonico a ármonico
    # -------------------------------
    A1 = np.zeros(Mmax + 1, dtype=np.complex128)
    A2 = np.zeros(Mmax + 1, dtype=np.complex128)

    A = build_amatrix(R1, R2)

    for m in range(1, Mmax+1):
        B = build_bvector(m, diameter, CZERO, CPOS, CNEG)
        # Resolver sistema
        sol = np.linalg.solve(A, B)

        A1[m] = sol[0] + 1j * sol[1]
        A2[m] = sol[2] + 1j * sol[3]

    # -------------------------------
    # Resolver AK1/AK2 ármonico a ármonico
    # -------------------------------
    AKM = build_akmatrix(R1, R2)
    PX = P
    PY = 0.0
    S = laminate.stacking[0].material.Q
    BM = np.array([
        PX / (4.0 * PI),
        -PY / (4.0 * PI),
        -(S[0, 1]*PY + S[0, 2]*PX)/(4.0*PI*S[0, 0]),
        -(S[0, 1]*PX + S[1, 2]*PY)/(4.0*PI*S[1, 1])
    ], dtype=np.complex128)

    AK_sol = np.linalg.solve(AKM, BM)
    AK1 = AK_sol[0] + 1j * AK_sol[1]
    AK2 = AK_sol[2] + 1j * AK_sol[3]

    # -------------------------------
    # Evaluación del campo de tensiones
    # -------------------------------
    nd = len(dist_points)
    na = len(angles_deg)

    stress = np.zeros((3, nd, na))
    u = np.zeros((nd, na))
    v = np.zeros((nd, na))

    for i, d in enumerate(dist_points):
        r = a + d
        for j, ang in enumerate(angles_deg):
            theta = ang * RAD

            x = r * math.cos(theta + alpha)
            y = r * math.sin(theta + alpha)

            z1 = x + R1 * y
            z2 = x + R2 * y

            XI1 = cmath.sqrt(z1*z1 - a*a * (1 + R1*R1))
            XI2 = cmath.sqrt(z2*z2 - a*a * (1 + R2*R2))
            # Selección de rama
            if (z1 / XI1).real < 0:
                XI1 = -XI1
            if (z2 / XI2).real < 0:
                XI2 = -XI2
            # Normalización
            ZZ1 = z1 + XI1
            XI1 = 2.0 * ZZ1 / (diameter * (1.0 - 1j * R1))
            ZZ2 = z2 + XI2
            XI2 = 2.0 * ZZ2 / (diameter * (1.0 - 1j * R2))

            # --- Potencial ---
            LOG_XI1 = cmath.log(XI1)
            LOG_XI2 = cmath.log(XI2)
            PHI1 = AK1 * LOG_XI1
            PHI2 = AK2 * LOG_XI2
            for m in range(1, Mmax+1):
                PHI1 += A1[m] * (XI1**(-m))
                PHI2 += A2[m] * (XI2**(-m))

            # --- Derivada Potencial
            P1 = AK1/XI1
            P2 = AK2/XI2
            for m in range(1, Mmax+1):
                P1 -= m * A1[m] * XI1**(-(m+1))
                P2 -= m * A2[m] * XI2**(-(m+1))

            if abs(d - 1e-6) < 1e-9 and abs(ang) < 1e-9:
                print("n=== DEBUG BJSFM (LOADED) ===")
                print(f"R1 = {R1}")
                print(f"R2 = {R2}")
                print(f"XI1 = {XI1}")
                print(f"XI2 = {XI2}")
                print(f"A11 = {A1[1]}")
                print(f"A21 = {A2[1]}")
                print(f"AK1 = {AK1}")
                print(f"AK2 = {AK2}")
                print(f"P1 before jacb = {P1}")
                print(f"P2 before jacb = {P2}")

            # --- Jacobiano dXI/dz ---
            dXI1_dz = 2.0 / (diameter*(1.0 - 1j*R1)) * \
                (1.0 + z1 / cmath.sqrt(z1*z1 - a*a*(1+R1*R1)))
            dXI2_dz = 2.0 / (diameter*(1.0 - 1j*R2)) * \
                (1.0 + z2 / cmath.sqrt(z2*z2 - a*a*(1+R2*R2)))
            P1 *= dXI1_dz
            P2 *= dXI2_dz

            sx = 2.0 * (R1*R1*P1 + R2*R2*P2).real
            sy = -(P1 + P2).real
            sxy = -2.0 * (R1*P1 + R2*P2).real
            stress[:, i, j] = [sx, sy, sxy]

            u[i, j] = 2.0 * PHI1.real
            v[i, j] = 2.0 * PHI2.real

            if abs(d - 1e-6) < 1e-9 and abs(ang) < 1e-9:
                print(f"dXI1_dz = {dXI1_dz}")
                print(f"dXI2_dz = {dXI2_dz}")
                print(f"P1 after jacb = {P1}")
                print(f"P2 after jacb = {P2}")
                print("n=== END DEBUG ===")

            # if False:
            #     print(f'At radius {i} at distance {d}')
            #     print(f'At angle {j} of {ang}')
            #     print(f'\U0001D70Ex: {sx}')
            #     print(f'\U0001D70Ey: {sy}')
            #     print(f'\U0001D70Exy: {sxy}')

    return stress, u, v


# BJSFM Example 1 - Loaded Hole Case
# ----------------------------------
# Ejemplo extraido directamente de la referencia

mat = Orthotropic(
    name='bjsfm_ex1',
    thickness=0.125,
    E1=18.85e+6,
    E2=1.9e+6,
    G12=0.85e+6,
    nu12=0.30,
)
ply_0 = Ply(
    material=mat,
    theta_deg=0.0
)
ply_90 = Ply(
    material=mat,
    theta_deg=90.0
)
ply_45p = Ply(
    material=mat,
    theta_deg=45.0
)
ply_45n = Ply(
    material=mat,
    theta_deg=-45.0
)

plies = [ply_0, ply_45p, ply_45n, ply_90]
stacking = np.repeat(plies, (42, 25, 25, 8)).tolist()

laminate = Laminate(
    stacking=stacking,
    name='eh_ex1_laminate')

angles_deg = [0, 30, 60, 90]
dist_points = [1e-6, 0.02, 0.04]
alpha_deg = 10.0
P = 50000
width = 1.5
PW = P * 0.25 / (2*width)
sL, uL, vL = loaded_hole_exact(
    laminate=laminate,
    P=P,
    diameter=0.25,
    alpha_deg=alpha_deg,
    angles_deg=angles_deg,
    dist_points=dist_points)
sUn, uUn, vUN = unloaded_hole_exact(
    laminate,
    px=PW,
    diameter=0.25,
    beta_deg=alpha_deg,
    dist_points=dist_points,
    angles_deg=angles_deg)

s_total = sL

for i, d in enumerate(dist_points):
    print(f"\nDist = {d}")
    for j, ang in enumerate(angles_deg):
        sx, sy, txy = s_total[:, i, j]
        print(
            f"theta = {ang:>3} | sigmax = {sx:10.1f} | sigmay ={sy:10.1f} | tau = {txy:10.1f}")
