# -*- coding: utf-8 -*-
import xlwings as xw
import numpy as np
import pandas as pd
import os
import sys
import typing
from IPython import get_ipython
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename



__version__ = '1.0.0'
__author__ = 'E.Maroto'

### Open File
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

def openEXCEL():
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    print('Opening EXCEL file...')
    fp = askopenfilename(
        title ='Open Excel', 
        filetypes=(("Excel file", '*.xlsx'),),
        multiple = False,
        defaultextension = ['.xlsx'],
        initialdir = os.getcwd(),
        parent = root
        )
    if fp =='':
        print('No file has been selected.')
    return fp
### Error functions

def typerror_msg(obj : object, expected_obj: object)->str:
    msg = '{0} object is not a {1}'.format(
        type(obj),
        expected_obj
            )
    return TypeError(msg)

class error_messages:
    def __init__(self):
        self.invalid_option = '[Error] Incorret option. Please try again.'

# Exporting
def df_to_excel_sheet(dataframe,sheet_name=None):
        print('Exporting data to Excel...', end='')
       
        # Opening xlwings
        app = xw.App(visible=False)
        wb = app.books[0]
        ws = wb.sheets[0]
        ws.activate()
        
        # Exporting data to default sheet1
        ws["A1"].options(
            pd.DataFrame, 
            header=1, 
            index=True, 
            expand='table').value = dataframe
        print('Done')
        
        # Re-labeling Default Sheet1
        if not(sheet_name is None):
            ws.name = sheet_name
        
        # Saving
        wb.save(
            path = asksaveasfilename(
                    title ='Save EXCEL file...', 
                    filetypes=(("EXCEL file", '*.xlsx'),),
                    defaultextension = ['*.xlsx'],
                    initialdir = os.getcwd()
                    ),
            )
        wb.close()
        print('Done')


# PANDAS DATAFRAME FROM EXCEL SHEET




#CONSOLE USER INTERFACE

class ui_menu:
    
    def __init__(self, options:list, label = None, options_sort=False, is_main=False):
  
          
        self.__selection_key = None
        self.__selection_val = None
        self.selection = None
        self.__text = 'Select an option: '
        self.__error_msgs = error_messages()
        self.label = label
        self.prev = None
        self.go_to = None
        
        if not(type(is_main) is bool):
            raise typerror_msg(is_main,bool)
        else:
            self.is_main = is_main
            self.__return_option_text = 'Back' if is_main is False else 'Exit' 
        
        if not(type(options) is list):
            raise typerror_msg(options,list)
        else:
            if options_sort : options.sort()
            options += [self.__return_option_text]
            self.options = dict(enumerate(options))
     

    
    
    def show_options(self):
   
        print(self.__text)
        for (i,option) in self.options.items():
            print ('\t',str(i),':\t',option)
    
    
    
    def get_user_selection(self):
        
        user_inp = input('Enter an option : ')
        try:
            user_inp = int(user_inp)
            if not(int(user_inp) in self.options.keys()):
                print(self.__error_msgs.invalid_option)
            else:
                self.__selection_key = int(user_inp)
                self.__selection_value = self.options[user_inp]
                self.selection = self.options[user_inp]
                
        except:
            print(self.__error_msgs.invalid_option)
            self.selection = None
 
    def loop(self):
        while True:
            self.show_options()
            self.get_user_selection()
            if self.selection in list(self.options.values()):
                break
            else:
                self.clear_console()
        return self.selection
                
            
    def clear_console(self,include_spyder=True):
        cmd = 'cls' if os.name == 'nt' else 'clear' 
        os.system(cmd)
        get_ipython().magic('clear')
        


