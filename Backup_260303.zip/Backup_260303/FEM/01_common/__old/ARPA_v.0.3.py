# -*- coding: utf-8 -*-
"""
Created on Wed Dec 17 11:24:51 2025

@author: U69432
"""
# ARPA

import numpy as np
from scipy.linalg import eig
from math import sin
from math import cos
from math import pi

'''
Notas:
    
    
    Y
    
    ^
    |
    |
    ++++++++++++++++++++++++++++++++++
    +                                +
    +                                +
    +                                + B
    +                                +
    +                                +
    ++++++++++++++++++++++++++++++++++  ---> X
                    L
    
    a) Dimensiones: Longitud L y anchura B
    
    b) Apoyado en sus cuatro bordes, con rigideces GJx en los bordes longitu-
    dinales y GJy en los transversales.
    
    c) Con cambios transversales (dir. y) de espesor y/o material, es decir, 
    compuestos por M tramos de anchura bm de rigidez constante (las anchuras
    y las rigideces pueden cambiar de un tramo a otro). La matriz geenralizada
    de rigidez de cada tramo vale [D*]m. El tramo "m" está situado entre
    las distancias ym1 e ym2 con respecto al borde izquierdo del panel
    
    d) Cada tramo longitudinal puede estar compuesto por capas de materiales
    diferentes, cada una de las cuales tiene un espesor tij (capa j del tramo i)
                                                
    e) El material de cada una de las capas anteriores ha de ser ortotropico 
    y elastico
    
    f) Reforda por medio de "Nr" elementos longitudinales de rigidez axial
    constante (que puede variar de un rigidizador a otro), los cuales están
    situados a distancias yrn del borde longitudilan del panel. Estos rigidi-
    zadores tienen unos modulos elasticos Ern,Grn. Sus propiedades geometricas
    son Arn, Irn, y constantes de torsion y warping Jrn y Cwrn.

    g) Sometido a cargas en el plano 
         - Longitudinal : Px
         - Carga transversal de cada tramo: Pym
         - Flujo de cortadura en cada tramo: Pxym
'''

# Inputs
nx = 2
ny = 2

L = 3.14
B = 3.14

i = 1  # tramo longitudinal 1
j = 1  # capa 1
m = 1  # tramo tranversal 1

d1y_list = []
d2y_list = []
d3y_list = []
d4y_list = []
d5y_list = []
d6y_list = []

fxm_list = []
fym_list = []
fxym_list = []


def alpha(n: int) -> float:
    return n * pi / L


def alpha2(n: int) -> float:
    x = alpha(n)
    return x**2


def beta(n: int,) -> float:
    return n * pi / B


def beta2(n: int,) -> float:
    x = beta(n)
    return x**2


def integral_ss(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 - sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 - num2/den2
    return out


def integral_cc(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 + sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 + num2/den2
    return out


def integral_sc(A: float, B: float, x: float) -> float:
    if A == B:
        out = - ((cos(A*x))**2)/(2*A)
    else:
        num1 = cos((A-B)*x)
        den1 = 2*(A-B)
        num2 = cos((A+B)*x)
        den2 = 2*(A+B)
        out = -num1/den1 - num2/den2
    return out


def fss(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_ss(A, B, x_end) - integral_ss(A, B, x_ini)


def fcc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_cc(A, B, x_end) - integral_cc(A, B, x_ini)


def fsc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_sc(A, B, x_end) - integral_sc(A, B, x_ini)


def fss_ik(i: int, k: int) -> float:
    a = i * pi / L
    b = k * pi / L
    return fss(a, b, 0, L)


def fcc_ik(i: int, k: int) -> float:
    a = i * pi / L
    b = k * pi / L
    return fcc(a, b, 0, L)


def fsc_ik(i: int, k: int) -> float:
    a = i * pi / L
    b = k * pi / L
    return fsc(a, b, 0, L)


def fss_jl(j: int, l: int) -> float:
    a = j * pi / B
    b = l * pi / B
    return fss(a, b, 0, B)


def fcc_jl(j: int, l: int) -> float:
    a = j * pi / B
    b = l * pi / B
    return fcc(a, b, 0, B)


def fsc_jl(j: int, l: int) -> float:
    a = j * pi / B
    b = l * pi / B
    return fsc(a, b, 0, B)


# PARTE I : ENERGIA INTERNA U
# =============================================================================


def f1jl_m(D11m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D11m_star * fss(a, b, ym1, ym2)


def f1jl(d1y_list: list[tuple], j: float, l: float) -> float:
    f1jl = 0
    for D11m_star, ym1, ym2 in d1y_list:
        f1jl += f1jl_m(D11m_star, ym1, ym2, j, l)
    return f1jl


def f2jl_m(D22m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D22m_star * fss(a, b, ym1, ym2)


def f2jl(d2y_list: list[tuple], j: float, l: float) -> float:
    f2jl = 0
    for D22m_star, ym1, ym2 in d2y_list:
        f2jl += f2jl_m(D22m_star, ym1, ym2, j, l)
    return f2jl


def f3jl_m(D33m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D33m_star * fcc(a, b, ym1, ym2)


def f3jl(d3y_list: list[tuple], j: float, l: float) -> float:
    f3jl = 0
    for D33m_star, ym1, ym2 in d3y_list:
        f3jl += f3jl_m(D33m_star, ym1, ym2, j, l)
    return f3jl


def f4jl_m(D12m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D12m_star * fss(a, b, ym1, ym2)


def f4jl(d4y_list: list[tuple], j: float, l: float) -> float:
    f4jl = 0
    for D12m_star, ym1, ym2 in d4y_list:
        f4jl += f4jl_m(D12m_star, ym1, ym2, j, l)
    return f4jl


def f5jl_m(D13m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D13m_star * fsc(a, b, ym1, ym2)


def f5jl(d5y_list: list[tuple], j: float, l: float) -> float:
    f5jl = 0
    for D13m_star, ym1, ym2 in d5y_list:
        f5jl += f5jl_m(D13m_star, ym1, ym2, j, l)
    return f5jl


def f6jl_m(D23m_star: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D23m_star * fsc(a, b, ym1, ym2)


def f6jl(d6y_list: list[tuple], j: float, l: float) -> float:
    f6jl = 0
    for D23m_star, ym1, ym2 in d6y_list:
        f6jl += f6jl_m(D23m_star, ym1, ym2, j, l)
    return f6jl


def du1dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return alpha2(i) * alpha2(k) * fss_ik(i, k) * f1jl(d1y_list, j, l)


def du2dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return beta2(j) * beta2(l) * fss_ik(i, k) * f2jl(d2y_list, j, l)


def du3dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return 4 * alpha(i) * alpha(k) * beta(j) * beta(l) * fcc_ik(i, k) * f3jl(d3y_list, j, l)


def du4dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return (alpha2(i) * beta2(l) + alpha2(k) * beta2(j)) * fss_ik(i, k) * f4jl(d4y_list, j, l)


def du5dwij_kl(i: int, j: int, k: int, l: int) -> float:
    first = alpha2(i) * alpha(k) * beta(l) * \
        fsc_ik(i, k) * f5jl(d5y_list, j, l)
    # Nota: en la doc, aparece fsc_ik(k,i), puede que sea una errata
    secnd = alpha(i) * alpha2(k) * beta(j) * \
        fsc_ik(k, i) * f5jl(d5y_list, l, j)
    return -2 * (first + secnd)


def du6dwij_kl(i: int, j: int, k: int, l: int) -> float:
    first = alpha(k) * beta2(j) * beta(l) * fsc_ik(i, k) * f6jl(d6y_list, j, l)
    secnd = alpha(i) * beta(j) * beta2(l) * fsc_ik(k, i) * f6jl(d6y_list, l, j)
    return -2 * (first + secnd)


def du_dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return du1dwij_kl(i, j, k, l) + du2dwij_kl(i, j, k, l) + \
        du3dwij_kl(i, j, k, l) + du4dwij_kl(i, j, k, l) + \
        du5dwij_kl(i, j, k, l) + du6dwij_kl(i, j, k, l)

# PARTE II : ENERGIA POTENCIAL V
# =============================================================================


def g1jl_m(fxm: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fxm * fss(a, b, ym1, ym2)


def g1jl(fxm_list: list[tuple], j: float, l: float) -> float:
    g1jl = 0
    for fxm, ym1, ym2 in fxm_list:
        g1jl += g1jl_m(fxm, ym1, ym2, j, l)
    return g1jl


def g2jl_m(fym: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fym * fcc(a, b, ym1, ym2)


def g2jl(fym_list: list[tuple], j: float, l: float) -> float:
    g2jl = 0
    for fym, ym1, ym2 in fym_list:
        g2jl += g2jl_m(fym, ym1, ym2, j, l)
    return g2jl


def g3jl_m(fxym: float, ym1: float, ym2: float, j: float, l: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fxym * fcc(a, b, ym1, ym2)


def g3jl(fxym_list: list[tuple], j: float, l: float) -> float:
    g3jl = 0
    for fxym, ym1, ym2 in fxym_list:
        g3jl += g3jl_m(fxym, ym1, ym2, j, l)
    return g3jl


def dv1dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return alpha(i) * alpha(k) * fss_ik(i, k) * g1jl(fxm_list, j, l)


def dv2dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return beta(j) * beta(l) * fss_ik(i, k) * g2jl(fym_list, j, l)


def dv3dwij_kl(i: int, j: int, k: int, l: int) -> float:
    first = alpha(i) * beta(l) * fsc_ik(k, i) * g3jl(fxym_list, j, l)
    secnd = alpha(k) * beta(j) * fsc_ik(i, k) * g3jl(fxym_list, l, j)
    return first + secnd


def dv_dwij_kl(i: int, j: int, k: int, l: int) -> float:
    return dv1dwij_kl(i, j, k, l) + dv2dwij_kl(i, j, k, l) + \
        dv3dwij_kl(i, j, k, l)


# PARTE III : RESOLUCION DEL PROBLEMA DE AUTOVALORES
# =============================================================================
def solve_eig():
    q = np.zeros((nx*ny, nx*ny))
    t = np.zeros((nx*ny, nx*ny))

    for i in range(1, nx+1):
        for j in range(1, ny+1):
            qij_kl = 0
            tij_kl = 0
            for k in range(1, nx+1):
                for l in range(1, ny+1):
                    qij_kl += du_dwij_kl(i, j, k, l)
                    tij_kl += dv_dwij_kl(i, j, k, l)
            q[k-1, l-1] = qij_kl
            t[k-1, l-1] = tij_kl

    print(q)
    print(t)

    eigvalues, eigvectors = eig(q, t, homogeneous_eigvals=True)
    return eigvalues, eigvectors

# PARTE IV : EJEMPLOS Y VALIDACION
# =============================================================================


def check_dus_dwij():
    for i in range(1, nx+1):
        for j in range(1, ny+1):
            wkl_du1 = 0
            wkl_du2 = 0
            wkl_du3 = 0
            wkl_du4 = 0
            wkl_du5 = 0
            wkl_du6 = 0
            for k in range(1, nx+1):
                for l in range(1, ny+1):
                    wkl_du1 += du1dwij_kl(i, j, k, l)
                    wkl_du2 += du2dwij_kl(i, j, k, l)
                    wkl_du3 += du3dwij_kl(i, j, k, l)
                    wkl_du4 += du4dwij_kl(i, j, k, l)
                    wkl_du5 += du5dwij_kl(i, j, k, l)
                    wkl_du6 += du6dwij_kl(i, j, k, l)
            wkl_coef = wkl_du1 + wkl_du2 + wkl_du3 + wkl_du4 + wkl_du5 + wkl_du6
            print(f'Coef for term W_{k}{l} = {wkl_coef}')
            print(f'\t dU1 term : {wkl_du1}')
            print(f'\t dU2 term : {wkl_du2}')
            print(f'\t dU3 term : {wkl_du3}')
            print(f'\t dU4 term : {wkl_du4}')
            print(f'\t dU5 term : {wkl_du5}')
            print(f'\t dU6 term : {wkl_du6}')
            _ = input('Press Enter to contine...')


L = 3.14
B = 3.14
nx = 2
ny = 2

d1y_list = [(143154.44, 0, B)]
d2y_list = [(125020.68, 0, B)]
d3y_list = [(59793.6, 0, B)]
d4y_list = [(56899.24, 0, B)]
d5y_list = [(6346.81, 0, B)]
d6y_list = [(6346.81, 0, B)]

fxm_list = [(0, 0, B)]
fym_list = [(0, 0, B)]
fxym_list = [(100.0, 0, B)]
