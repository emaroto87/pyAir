# -*- coding: utf-8 -*-
"""
Created on Tue May 20 14:49:29 2025

@author: U69432
"""


def nastran_format_str(string, align: str = 'right', field_chars=8):
    inp = string
    nc = len(inp)
    spaces = (field_chars-nc)*' '
    if len(spaces) > 0:
        if align == 'left':
            out = inp + spaces
        else:
            out = spaces + inp
    elif len(spaces) == 0:
        out = inp
    else:
        raise ValueError(
            'The length of {string} is greater than {field_chars} characters')

    return out


def nastran_format_int(integer, align='right', field_chars=8):
    inp = str(integer)
    nc = len(inp)
    spaces = (field_chars-nc)*' '
    if len(spaces) > 0:
        if align == 'left':
            out = inp + spaces
        else:
            out = spaces + inp
    elif len(spaces) == 0:
        out = inp
    else:
        raise ValueError(
            'The length of {string} is greater than {field_chars} characters')
    return out


def nastran_format_float(number, format_str='8.2E', align='right', field_chars=8):
    inp = format(number, format_str)
    nc = len(inp)
    spaces = (field_chars-nc)*' '
    if len(spaces) > 0:
        if align == 'left':
            out = inp + spaces
        else:
            out = spaces + inp
    elif len(spaces) == 0:
        out = inp
    else:
        raise ValueError(
            'The length of {string} is greater than {field_chars} characters')
    return out


def create_card(card_fields: list, field_chars: int = 8) -> str:
    card = ''
    field_counter = 1

    for item in card_fields:
        if type(item) is str:
            field = nastran_format_str(item, field_chars=field_chars)
        elif type(item) is int:
            field = nastran_format_int(item, field_chars=field_chars)
        elif type(item) is float:
            field = nastran_format_float(item, field_chars=field_chars)
        elif item is None:
            field = ' ' * field_chars
        else:
            raise ValueError
        card += field
        print(card)

        if field_counter % 10 == 0:
            print('enter')
            card += '\n'
        field_counter += 1

    return card
