# Funciones de limpieza del archivo de entrada

def limpia_n (lista):

    """ (lista) ---> lista
    Elimina el saltador de linea que se genera al final de una linea cuando se lee un fichero de texto y previamente
    ha sido convertido en una lista de listas (cada linea) mediante el separador ;

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0\n'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    """

    a = lista[-1]
    if '\n' in a:
        a = a[:-1]
        lista.pop()
        lista.append(a)

    return lista



def limpia_blancos_f (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información al final de una lista. Adicionalmente eliminamos
    el espaciador final.

    >>> elimina_blancos_f(['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0', '', ''])
    ['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0']

    """
    
    while lista[-1] == '':
        lista.pop()

    return lista

#Lectura del archivo con los datos de los laminados

import tkinter.filedialog

print('Introduce el archivo .csv con la información de los elementos ARPA')

ruta = tkinter.filedialog.askopenfilename()
entrada = open(ruta,'r')
contenido = []

for linea in entrada:
    contenido.append(linea)
entrada.close()


#Generación de la lista de elementos (lista de listas)
'cada miembro es una lista con los datos de elemento'

lista_elementos=[]
for linea in contenido:
    elemento = linea.split(';')
    lista_elementos.append(elemento)

for elemento in lista_elementos:
    limpia_n(elemento)
    limpia_blancos_f(elemento)

limpia_blancos_f(lista_elementos)

lista_elementos = lista_elementos[2:]

#Abrimos el archivo de salida

print('Guarda tu archivo de salida')

ruta = tkinter.filedialog.asksaveasfilename()
salida = open(ruta,'w')

#Escribimos

for elemento in lista_elementos:
    for i in range (8):
        salida.write(elemento[i] + ',')

    salida.write(elemento[-1] + '\n')

    salida.write('*\n')

salida.close()


