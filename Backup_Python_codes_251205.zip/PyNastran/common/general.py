# -*- coding: utf-8 -*-
"""
Created on Fri May 23 09:26:07 2025

@author: U69432
"""

from tkinter.filedialog import asksaveasfilename
from tkinter.filedialog import askopenfilename
import tkinter as tk
import os

from typing import Dict


import pandas as pd
import xlwings as xw
import numpy as np

from pyNastran.op2.op2 import OP2
from tqdm import tqdm

from errors import *

from collections import namedtuple

from pathlib import Path

__version__ = '1.0.0'
__author__ = 'E.Maroto'

# Default Values
entities_types = namedtuple('entities_type', ['node', 'element'])

__ENTITY_TYPES = [
    'NodeID',
    'ElementID',
    'SubcaseID'
]

__CASE_CONTROL_PARAMS = [
    'TITLE',
    'LABEL'
]


def load_op2_file(path: str, build_dataframe: bool = True, debug: bool = False) -> OP2:
    '''
    Given a NASTRAN OP2 file, returns the pyNASTRAN OP2 object.

    Parameters
    ----------
    path : str path-like
        Path of the NASTRAN OP2 file.
    build_dataframe : bool, optional
        If True, enables the option to store all the information as Pandas 
        dataframes.
    debug : bool, optional
       If True, prints additional output that can aid in diagnosing issues 
       during the reading of the OP2 file.

    Returns
    -------
    PyNastran OP2 object.
        DESCRIPTION.

    '''
    o = OP2(debug=False)
    o.read_op2(path,
               build_dataframe=build_dataframe,
               # skip_undefined_matrices = True
               )
    return o


def concat(*args, **kargs):
    s = ''
    for i in args:
        s += i
    return s


def vector_mod(p1, p2):
    v = p2-p1
    return np.sqrt(np.dot(v, v))


# WRITING CARDS
def split_list(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i: i + n]


def merge_dfs(*args, **kwargs):

    df_list = [arg for arg in args]
    merged_df = pd.concat(df_list)

    return merged_df

# READING Progress bar (WIP)


def progress_OP2_bar(path):
    op2 = OP2()
    file_size = os.path.getsize(path)
    with open(path, 'rb') as file:
        with tqdm(file_size, unit='B', unit_scale=True, desc='Reading file') as bar:
            def read_progress(n):
                data = file.read(n)
                bar.update(len(data))
                return data
            op2.read_op2(path, read_binary=read_progress)


__version__ = '1.0.0'
__author__ = 'E.Maroto'

# Open File


def openEXCEL():
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    print('Opening EXCEL file...')
    fp = askopenfilename(
        title='Open Excel',
        filetypes=(("Excel file", '*.xlsx'),),
        multiple=False,
        defaultextension=['.xlsx'],
        initialdir=os.getcwd(),
        parent=root
    )
    if fp == '':
        print('No file has been selected.')
    return fp


# Exporting
def df_to_excel_sheet(dataframe, sheet_name=None):
    print('Exporting data to Excel...', end='')

    # Opening xlwings
    app = xw.App(visible=False)
    wb = app.books[0]
    ws = wb.sheets[0]
    ws.activate()

    # Exporting data to default sheet1
    ws["A1"].options(
        pd.DataFrame,
        header=1,
        index=True,
        expand='table').value = dataframe
    print('Done')

    # Re-labeling Default Sheet1
    if not (sheet_name is None):
        ws.name = sheet_name

    # Saving
    wb.save(
        path=asksaveasfilename(
            title='Save EXCEL file...',
            filetypes=(("EXCEL file", '*.xlsx'),),
            defaultextension=['*.xlsx'],
            initialdir=os.getcwd()
        ),
    )
    wb.close()
    print('Done')


# PANDAS DATAFRAME FROM EXCEL SHEET
def to_excel(tables: Dict[str, pd.DataFrame], output_filename: Path, remove_prefix=False, index=False):
    '''
    Export into an Excel file multiple pandas DataFrames stored within a 
    dictionary

    Parameters
    ----------
    tables : Dict [str, pd.DataFrame ]
        Dictionary containing the pandas DataFrames. Each key of the dictionary
        is used to label the sheet of the Excel book file.
    filename : str path-like
        Path of the output Excel file.

    Returns
    -------
    None.

    '''
    # Checking
    check_type(tables, dict)
    check_type(output_filename, str)

    # Remove common prefix
    if remove_prefix is True:
        labels = list(tables.keys())
        c = os.path.commonprefix(labels)

    print('Exporting to Excel File ...', sep='')
    with pd.ExcelWriter(output_filename) as writer:
        for sheet_name, table in tables.items():
            if remove_prefix is True:
                sheet_name = sheet_name.replace(c, '')
            else:
                pass
            table.to_excel(writer, sheet_name=sheet_name, index=index)

    print('[Done]')


# ----------------------------------------------------------------------------
# Exporting
def df_to_excel_sheet(dataframe, sheet_name=None):
    print('Exporting data to Excel...', end='')

    # Opening xlwings
    app = xw.App(visible=False)
    wb = app.books[0]
    ws = wb.sheets[0]
    ws.activate()

    # Exporting data to default sheet1
    ws["A1"].options(
        pd.DataFrame,
        header=1,
        index=True,
        expand='table').value = dataframe
    print('Done')

    # Re-labeling Default Sheet1
    if not (sheet_name is None):
        ws.name = sheet_name

    # Saving
    wb.save(
        path=asksaveasfilename(
            title='Save EXCEL file...',
            filetypes=(("EXCEL file", '*.xlsx'),),
            defaultextension=['*.xlsx'],
            initialdir=os.getcwd()
        ),
    )
    wb.close()
    print('Done')


def dfs_to_excel_sheets(dict_dataframes):
    print('Exporting data to Excel...', end='')

    # Opening xlwings
    app = xw.App(visible=False)
    wb = app.books[0]
    ws_labels = list(dict_dataframes.keys())

    # Exporting data to default the differen
    for label in ws_labels:
        wb.sheets.add(str(label))
        df = dict_dataframes[label]
        ws = wb.sheets[str(label)]
        ws.activate()
        ws["A1"].options(
            pd.DataFrame,
            header=1,
            index=True,
            expand='table').value = df

    # Deleting default Sheet
    wb.sheets[-1].delete()

    # Saving
    wb.save(
        path=asksaveasfilename(
            title='Save EXCEL file...',
            filetypes=(("EXCEL file", '*.xlsx'),),
            defaultextension=['*.xlsx'],
            initialdir=os.getcwd()
        ),
    )
    wb.close()
    print('Done')


def export_single(dataframe, option='csv'):
    assert (dataframe._typ == pd.DataFrame._typ)
    assert (type(option) is str)

    if option.upper() == 'CSV':
        dataframe.to_csv(
            asksaveasfilename(
                title='Save CSV file...',
                filetypes=(("CSV file", '*.csv'),),
                defaultextension=['.csv'],
                initialdir=os.getcwd()
            ),
            header=True
        )

    elif option.upper() == 'XLS':
        app = xw.App(visible=False)
        wb = app.books[0]
        ws = wb.sheets[0]
        ws.activate()
        print('Exporting data to Excel...', end='')
        ws["A1"].options(
            pd.DataFrame,
            header=1,
            index=True,
            expand='table').value = dataframe
        print('Done')
        wb.save(
            path=asksaveasfilename(
                title='Save EXCEL file...',
                filetypes=(("EXCEL file", '*.xlsx'),),
                defaultextension=['*.xlsx'],
                initialdir=os.getcwd()
            ),
        )
        wb.close()

    else:
        return


def export_multi(dict_dataframes):
    print('Exporting data to Excel...', end='')
    app = xw.App(visible=False)
    wb = app.books[0]
    ws_labels = list(dict_dataframes.keys())

    for label in ws_labels:
        wb.sheets.add(str(label))
        df = dict_dataframes[label]
        ws = wb.sheets[str(label)]
        ws.activate()
        ws["A1"].options(
            pd.DataFrame,
            header=1,
            index=False,
            expand='table').value = df
    print('Done')

    # Deleting default Sheet
    wb.sheets[-1].delete()
    # Saving
    wb.save(
        path=asksaveasfilename(
            title='Save EXCEL file...',
            filetypes=(("EXCEL file", '*.xlsx'),),
            defaultextension=['*.xlsx'],
            initialdir=os.getcwd()
        ),
    )
    wb.close()

############################### END AUX ###############################

# ----------------------------------------------------------------------------


def filter_df_by_entity(dataframe, entities, entity_type='NodeID', verbose=False):
    # check
    if not (type(dataframe) is type(pd.DataFrame())):
        error_msg = 'dataframe is not a DataFrame type'
        raise TypeError(error_msg)
        return None
    else:
        df = dataframe

    if not (type(entities) is list):
        error_msg = 'entities is not a list'
        raise TypeError(error_msg)
        return None

#   Nota: Habria que comprobar que el df contiene la columna correspondiente
    if entity_type in ['NodeID', 'ElementID', 'SubcaseID']:
        if verbose:
            print('Filtering data by : ', entity_type)
        if entity_type in df.columns:
            df_filtered = df[df[entity_type].isin(entities)]
        else:
            df_filtered = df[df.index.isin(entities)]
        return df_filtered
    else:
        raise ('{0} is not valid option'.format(entity_type))
        return None

# ----------------------------------------------------------------------------


def parsing_ids_list(user_input: str, sep=','):
    ls_ids = user_input.split(sep=sep)
    for i in range(len(ls_ids)):
        item = ls_ids[i].strip()
        try:
            ls_ids[i] = int(item)
        except:
            print('Item ', item, ' is not an valid integer id value')
            return None
    return ls_ids


def parsing_list(user_input: str, sep=','):
    ls_in = user_input.split(sep=sep)
    ls_out = [item.strip() for item in ls_in]
    return ls_out

# ----------------------------------------------------------------------------


def ask_entities_ids_list():
    user_input = input('Enter list of entities IDs : ')
    return parsing_ids_list(user_input)

# ----------------------------------------------------------------------------


def ask_entities_fields_list():
    user_input = input('Enter list of fields : ')
    return parsing_list(user_input)
# ----------------------------------------------------------------------------


def select_option(l: list):
    for (k, v) in enumerate(l):
        print('\t', str(k), ':\t', v)
    option = input('Select an option : ')
    while True:
        try:
            selection = l[int(option)]
            break
        except:
            print(option, ' is not a valid selection.')
    return selection


def select_fields(l: list):
    print('Available fields:')
    for (k, v) in enumerate(l):
        print('\t', str(k), ':\t', v)
    selected_fields = ask_entities_fields_list()
    return selected_fields

# ----------------------------------------------------------------------------


def select_entity_type(func=select_option, entities_type=__ENTITY_TYPES):
    return func(entities_type)

# ----------------------------------------------------------------------------
# SPLITITNG DATAFRAMES


def is_type(obj, obj_class):
    if not (type(obj) is type(obj_class)):
        error_msg = 'Object {0} is not a {1}type'.format(
            str(type(obj)),
            str(type(obj_class))
        )
        raise TypeError(error_msg)
        return False
    else:
        return True


def split_df_by_entity(dataframe,
                       entities,
                       entity_type='NodeID',
                       filter_list=False,
                       ):
    # check
    if not (type(dataframe) is type(pd.DataFrame())):
        error_msg = 'dataframe is not a DataFrame type'
        raise TypeError(error_msg)
        return None
    else:
        df = dataframe

    if not (type(entities) is list):
        error_msg = 'entities is not a list'
        raise TypeError(error_msg)
        return None

    df = None if not (is_type(dataframe, pd.DataFrame())) else dataframe
    entities = None if not (is_type(entities, list())) else entities

    if ((df is None) or (entities is None)):
        return

    # Nota: Habria que comprobar que el df contiene la columna correspondiente

    if entity_type in df.columns:
        dfs_per_entity_dict = {}
        print('Spliting data by : ', entity_type)
        for entity in entities:
            print(entity, '...', end='')
            df_per_entity = df[df[entity_type] == entity]
            dfs_per_entity_dict[entity] = df_per_entity
            print('Done')
        return dfs_per_entity_dict
    elif entity_type == df.index.name:
        dfs_per_entity_dict = {}
        print('Spliting data by : ', entity_type)
        for entity in entities:
            print(entity, '...', end='')
            df_per_entity = df[df.index == entity]
            dfs_per_entity_dict[entity] = df_per_entity
            print('Done')
        return dfs_per_entity_dict
    else:
        return None


def split_df_by_subcases(dataframe, sids):
    df = None if not (is_type(dataframe, pd.DataFrame())) else dataframe
    dfs_per_subcases = {}
    for sid in sids:
        print('Splitting DataFrame by SID : {0}'.format(sid))
        df_per_subcase = df[df['SubcaseID'] == sid]
        dfs_per_subcases[sid] = df_per_subcase
    return dfs_per_subcases
# ----------------------------------------------------------------------------


def get_subcases_names(pyNastran_op2, param):
    op2 = pyNastran_op2
    subcases_dict = op2.case_control_deck.subcases
    # Deleting default subcase 0 created by pyNastran
    try:
        subcases_dict.pop(0)
    except:
        None

    names_dict = {}
    for k, v in subcases_dict.items():
        try:
            name = v.params[param][0]
        except:
            name = ''
        sid = k
        names_dict[sid] = name
    return names_dict

# ----------------------------------------------------------------------------


def export_subcases_names(pyNastran_op2, param):
    names_dict = get_subcases_names(pyNastran_op2, param)
    x = names_dict.keys()
    y = names_dict.values()
    df = pd.DataFrame(y, x, columns=[param])
    df.index.name = 'Subcase ID'
    dict_dfs = {param: df}
    dfs_to_excel_sheets(dict_dfs)
