# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 14:48:19 2025

@author: U69432
"""

import sys
import os
from collections import Counter
from collections import namedtuple
from collections import defaultdict
from nastran_cards import create_card
from nastran_cards import nastran_format_float
from nastran_cards import nastran_format_int
from nastran_cards import nastran_format_str
from tkinter.filedialog import asksaveasfilename
from tkinter.filedialog import askopenfilename
import tkinter as tk
from pathlib import Path
from enum import Enum
import abc
from typing import Optional
from dataclasses import dataclass, asdict
from pyNastran.bdf.bdf import BDF as bdf
__version = '1.0.4'
__author = 'E.Maroto'

# ========================
#
# PARTE DE LECTURA DE BDF
#
# ========================
# Ejemplos para leer BDF y conseguir datos de él


# # Load the model
# model = bdf()
# model.read_bdf(
#     bdf_filename = incfp,
#     read_includes = True,
#     validate = False,
#     xref = True,
#     )

# # Imprimir datos del modelo
# print(model.get_bdf_stats)

# # Acceder a nodos
# nodes = model.nodes # Se trata de un diccionario k=nid v=obj nodo
# nids = list(model.nodes.keys())
# n1=nodes[nids[0]]

# # Acceder a elementos
# elems = model.elements
# eids = list(elems.keys())
# e1 = elems[eids[0]]

# print(e1.get_stats()) # Proporciona información del elementoe1

# # cosas utiles
# e1.type # me proporciona el tipo de elemento que es
# e1.object_attributes() # proporciona los atributos
# e1.object_method()
# e1.pid_ref # accedes a la propiedad vinculada al elemento

# # Mapear
# model.get_property_id_to_element_ids_map()
# #
# #
# #
# #
# #
# #
# # Lista de funciones que podrian ser utiles.
# # 1. Dado un modelo con remaches CBUSH + RBE3, generar los PBUSH
# # 2. Dada una lista de remaches


"""
Nota el siguiente codigo asume que el elemento 'eid' es una lista que contiene
los nodos que lo definen.


"""


def get_edges_from_element(pyNastran_elem) -> list:
    elem = pyNastran_elem
    edges = []
    nodes = elem.node_ids
    n = len(nodes)
    for i in range(n):
        print
        edge = tuple(sorted((nodes[i], nodes[(i+1) % n])))
        edges.append(edge)
    return edges


def get_edges(pyNastran_elems, sort=False, verbose=False):
    elems = pyNastran_elems
    edge_counter = defaultdict(int)
    # Step 1 : count how many times an edge appears

    for eid, elem in elems.items():
        edges = get_edges_from_element(elem)
        for edge in edges:
            edge_counter[edge] += 1
    if verbose:
        for edge, count in edge_counter.items():
            print('Edge defined by nodes : ', edge,
                  'counted ', count, ' times')

    # Step 2 : edges that appears only one time
    frontier_edges = [edge for edge,
                      count in edge_counter.items() if count == 1]

    # Step 3 : get the unique nodes of the frontier edges
    frontier_nodes = set()
    for edge in frontier_edges:
        frontier_nodes.update(edge)
    if sort is True:
        frontier_nodes = sorted(frontier_nodes)

    return frontier_nodes


def testing_get_edges():
    # # Load the model
    path = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\examples_and_tests\BDF_tools\edges'
    fname = 'test.bdf'
    os.chdir(path)
    model = bdf()
    model.read_bdf(
        bdf_filename=os.path.join(path, fname),
        read_includes=True,
        validate=False,
        xref=True,
    )
    edges = get_edges(model.elements)
    return edges


def read_bdf(str):
    with open(str, 'r') as f:
        lines = f.readlines()
    return lines

# @dataclass
# class PSHELL:
#     PID : int
#     T : float


@dataclass
class CQUAD4:
    EID: int
    PID: int
    G1: int
    G2: int
    G3: int
    G4: int
    THETA: float = 0.0
    MCID: int | None = 0
    ZOFFS: float | None = None
    TFLAG: int | None = None
    T1: float = 0.0
    T2: float = 0.0
    T3: float = 0.0
    T4: float = 0.0
    bdf_file: str | None = None
    bdf_nline: int | None = None

    def __post_init__(self):
        self.entity = 'CQUAD4'

        card_field_line1 = [
            self.entity,
            self.EID,
            self.PID,
            self.G1,
            self.G2,
            self.G3,
            self.G4,
            self.MCID,
            self.ZOFFS,
            None,
            None
        ]

        card_field_line2 = [
            None,
            None,
            self.TFLAG,
            self.T1,
            self.T2,
            self.T3
        ]

        self.card_fields = card_field_line1 + card_field_line2

        __fields_order = [
            self.entity,
            self.EID,
            self.PID,
            self.G1,
            self.G2,
            self.G3,
            self.G4,
            self.MCID
        ]


@dataclass
class CTRIA3:
    EID: int
    PID: int
    G1: int
    G2: int
    G3: int
    THETA: float = 0.0
    MCID: int | None = None
    ZOFFS: float | None = None
    TFLAG: int | None = None
    T1: float = 0.0
    T2: float = 0.0
    T3: float = 0.0
    T4: float = 0.0
    bdf_file: str | None = None
    bdf_nline: int | None = None

    def __post_init__(self):
        self.entity = 'CQUAD4'
        pass

        card_field_line1 = [
            self.entity,
            self.EID,
            self.PID,
            self.G1,
            self.G2,
            self.G3,
            self.MCID,
            self.ZOFFS,
            None,
            None
        ]

        card_field_line2 = [
            None,
            None,
            self.TFLAG,
            self.T1,
            self.T2,
            self.T3
        ]

        self.card = card_field_line1 + card_field_line2


def parse_bdf_line(bdf_line: str, field_chars: int = 8):
    # Skip if comment line (Starts with $)
    if bdf_line.startswith('$'):
        return bdf_line

    # Parsing line

    else:
        fields = []
        # Couting number of fields
        n = len(bdf_line)
        mod, res = divmod(n, field_chars)

        for i in range(mod):
            start = field_chars*i
            end = field_chars*(i+1)
            fields.append(bdf_line[start:end])

        if res != 0:
            start = field_chars*(mod)
            fields.append(bdf_line[start:])
        return fields


def read_bdf(str):
    with open(str, 'r') as f:
        lines = f.readlines()

    # Estrategia linea por linea

    return lines


def change_2D_prop(lines, elems: list, PID: int, field_nchars=8):
    # with open(bdf_file) as f:
    #     lines = f.readlines()
    inp_lines = lines
    out_lines = []
    for line in inp_lines:
        if line.startswith(('CQUAD4', 'CTRIA3')):
            EID = extract_field(line, 2)
            if int(EID) in elems:
                new_PID = nastran_format_int(PID)
                old_PID = extract_field(line, 3)
                out_line = line.replace(old_PID, new_PID)
                out_lines.append(out_line)
            else:
                out_lines.append(line)
        else:
            out_lines.append(line)
    return out_lines


def extract_field(line, field_number, fields_chars=8):
    start = (field_number-1) * fields_chars
    end = (field_number) * fields_chars
    field = line[start:end]
    return field


def openBDF():
    bdf_fp = askopenfilename(
        title='Open NASTRAN BDF file',
        filetypes=(
            ("Nastran BDF file", '*.bdf'),
            ("Data file", '*.dat'),
            ("Include file", '*.incl'),
        ),
        multiple=False,
        defaultextension=['*.bdf'],
        initialdir=os.getcwd()
    )
    if bdf_fp == '':
        print('No file has been selected.')
    return bdf_fp


def mod_2Delems_PID(inp_bdf, elems_list: list, PID: int, field_nchars=8):
    out_bdf = inp_bdf.split('.')[0] + '_mod.' + inp_bdf.split('.')[1]

    with open(inp_bdf, 'r') as f:
        lines = f.readlines()

    with open(out_bdf, 'w') as f:
        out_lines = change_2D_prop(lines, elems_list, PID)
        f.writelines(out_lines)

    return out_bdf


def align_nodes(lines: list, nodes_list: list, node_ref: int, comp: int):
    out_lines = []
    for line in lines:
        if line.startswith('GRID'):
            nid = extract_field(line, 2)
            if int(nid) == node_ref:
                new_coord = extract_field(line, 3 + comp)

    for line in lines:
        if line.startswith('GRID'):
            nid = extract_field(line, 2)
            if int(nid) in nodes_list:
                old_coord = extract_field(line, 3 + comp)
                out_line = line.replace(old_coord, new_coord)
                out_lines.append(out_line)
            else:
                out_lines.append(line)
        else:
            out_lines.append(line)

    return out_lines


def mod_node_coord(inp_bdf, nodes_list: list, node_ref: int, comp: int):
    out_bdf = inp_bdf.split('.')[0] + '_mod.' + inp_bdf.split('.')[1]

    with open(inp_bdf, 'r') as f:
        lines = f.readlines()

    with open(out_bdf, 'w') as f:
        out_lines = align_nodes(lines, nodes_list, node_ref, comp)
        f.writelines(out_lines)

    return out_bdf


def default_output_file(
        input_file: str,
        suffix: str | None = None,
        preffix: str | None = None
) -> str:
    '''
    *** PASS THIS FUNCTION TO GENERAL  

    Gets the path of a input file that is going to be modified and generates
    the path of the output file according to a Preffix and Suffix strings.
    If both Preffix and Suffix are None, the function adds "_mod" as suffix
    by default

    Parameters
    ----------
    file : file path

    suffix : str | None, optional
        String of the suffix. The default is None.
    preffix : str | None, optional
        String of the preffix. The default is None.

    Returns
    -------
    output_filepath : path
    '''

    folder = os.path.dirname(input_file)
    file = os.path.basename(input_file)
    filename, filextension = os.path.splitext(file)
    if (preffix is None) and (suffix is None):
        suffix = '_mod'
    if suffix is None:
        suffix = ''
    if preffix is None:
        preffix = ''
    else:
        print('Error')

    output_filename = preffix + filename + suffix
    output_filepath = os.path.join(folder, output_filename + filextension)

    return output_filepath


def check_duplicated_ids(lists: list[list]):
    '''
    Given a list of list, returns the into a tuple of two list the unique
    elements and the duplicates

    Parameters
    ----------
    lists : list[list]
        List containing other lists 

    Returns
    -------
    unique,duplicates : tuple


    '''
    # Combinamos las listas
    combined = sum(lists, [])

    # La función counter te devuelve un diccionario donde cada key es cada
    # uno de los miembros de las lista, y el valor corresponde con el numero
    # de veces presente en la lista
    counter = Counter(combined)

    duplicates = [item_id for item_id, freq in counter.items() if freq > 1]

    # Lista sin duplicados
    unique = set(combined)

    return unique, duplicates


def comment_cards_by_field_pos(
        bdf_file: str,
        element_type_and_ids: dict,
        field_number: int = 1,
        check_duplicates: bool = False):

    # Nastran fields number is between [1,10]
    if field_number < 1 or field_number > 10:
        raise ValueError(
            'The value of field number must be greater than 1 and do not'
            'exceed 10.'
        )

    # Duplicates in the lists
    element_types = element_type_and_ids.keys()
    unique_ids, duplicate_ids = check_duplicated_ids(
        element_type_and_ids.values())

    if check_duplicates:
        if len(duplicate_ids) > 0:
            print('[WARNING] : The following ids are duplicated:')
            for item in duplicate_ids:
                print(item)
            yesno = input('Do you want to continue?')

            while True:
                if yesno.upper().startswith('Y'):
                    break
                elif yesno.upper().startswith('N'):
                    return None
                else:
                    pass

    # Reading BDF Files and
    lines = read_bdf(bdf_file)
    nlines = len(lines)

    # Comment the lines according to input
    print('---> BEGIN : Commenting elements')
    i = 0
    out_lines = []
    while i < nlines:
        line = lines[i]
        if line.startswith(tuple(element_types)):

            # Card Label
            card_str_field = extract_field(line, 1)

            # Card ID
            id_str_field = extract_field(line, field_number)
            id_int_field = int(id_str_field.strip())

            if id_int_field in unique_ids:
                print(f'\tCommented element {card_str_field } {id_int_field}')
                line = '$ Commented -> ' + line
                out_lines += [line]
                i += 1
                while True:
                    line = lines[i]
                    if line.startswith(('+')):
                        line = '$ Commented -> ' + line
                        out_lines += [line]
                        i += 1
                    else:
                        break
            else:
                out_lines += [line]
                i += 1

        else:
            out_lines += [line]
            i += 1

    # Writing the file with the commented lines
    out_fp = default_output_file(bdf_file)
    o = open(out_fp, 'w')
    o.writelines(out_lines)
    print('<--- END : Commenting elements')
    print(f'Created file at : {out_fp}')
    o.close()

###############################################################################
#                                                                             #
#                                 EXAMPLES                                    #
#                                                                             #
###############################################################################


def ejemplo1_commentar_fuerzas():
    bdf_file = r'X:\NASTRAN\Jacking\03_LOADS\HANDLING\DLL_JACK+HOIST_FORCE_MOMENT.bdf'
    groups = {
        'FORCE': [34006, 34007, 34008, 35006, 35007, 35008],
        'MOMENT':  [34006, 34007, 34008, 35006, 35007, 35008]
    }
    comment_cards_by_field_pos(
        bdf_file=bdf_file,
        element_type_and_ids=groups,
        field_number=3,
        check_duplicates=True
    )


def ejemplo_comentar_SPCDs():
    path = r'Y:\03.SIZINGS\02-FUSELAGE\FRONT-FUSELAGE\05_SHEAR WALLS\WSC\LOWER_SHEAR_WALL\03_Nxx_Nxy_SS\02_LOCAL_DFEM\DFEM_aislado_Fr08-Fr09\03_LOADS\FUS\FWD-FUS-DLL_SPCDs_LSW_Fr08-Fr09.bdf'
    groups = {'SPCD': [2, 4, 5, 6]}

    comment_cards_by_field_pos(
        bdf_file=path,
        element_type_and_ids=groups,
        field_number=4,
        check_duplicates=True
    )
