# -*- coding: utf-8 -*-
"""
Created on Tue Feb 17 15:14:59 2026

@author: U69432
"""

'''
Script para generar remaches de manera rápida en NASTRAN

Inputs:
    - Datos de remaches (localización, tipo, vector normal, radio, direción)
    - Malla 2D con propiedades aplicadas
    -

Pasos:
    1. Coger el punto de refencia (P) y su vector de dirección (Vd) y obtener
    los puntos proyectados en las superficies.
    2. Generar CBUSH
    3. Calcular Huth
        3.1 Obtener el apilado del elemento
        3.2 Calcular E1,E2 del apilado en la dirección que se desee
        3.3 Calular Kshear en esa dirección.
    4. Proceso recursivo

'''


from enum import Enum
from Materials.composite import Laminate
from Materials.metallic import Metallic
from general import is_type
from pyNastran.bdf.bdf import BDF
__HEAD_TYPE_PTR = 'PTR'
__HEAD_TYPE_CSK = 'CSK'


class HeadType(Enum):
    PTR = 'protruding'
    CSK = 'countersunk'


class JointType(Enum):
    SINGLE = 'single_shear'
    DOUBLE = 'double_shear'


class Fastener:
    def __init__(self, Et: float, diameter: float, head_type: HeadType, rivet=True):
        # self.material = material
        self.Et = Et
        self.diameter = diameter
        self.head_type = head_type
        if rivet:
            self.is_bolt = False
            self.is_rivet = True
        else:
            self.is_bolt = True
            self.is_rivet = False


class Plate:
    pass


class MetallicPlate:
    def __init__(self, material: Metallic, thickness: float):
        self.material = material
        self.thickness = thickness


class CompositePlate:
    def __init__(self, laminate: Laminate):
        self.laminate = laminate
        self.thickness = laminate.thickness

    def get_equivalent_moduli(self, angle_deg: float):
        '''
        Returns the equivalent values of Ex, Ey, Gxy and nuxy into another 
        coordinate system which is defined as a rotation from the stacking
        coordinate system
        '''
        data = self.laminate.laminate_apparent_moduli(angle_deg)
        Ex_local = data['Ex']
        Ey_local = data['Ey']
        Gxy_local = data['Gxy']
        nuxy_local = data['nuxy']

        return Ex_local, Ey_local, Gxy_local, nuxy_local


def huth(plate1: Plate, plate2: Plate, fastener: Fastener) -> float:

    # data from plate 1
    t1 = plate1.thickness
    E1 = plate1.material.Et
    plate1_type = 'METALLIC' if type(plate1) == MetallicPlate else 'COMPOSITE'

    # data from plate 2
    t2 = plate2.thickness
    E2 = plate2.material.Et
    plate2_type = 'METALLIC' if type(plate2) == MetallicPlate else 'COMPOSITE'

    # data from fastener
    Er = fastener.Et
    d = fastener.diameter

    # Selecting the parameters "a" and "b"
    if plate1_type == 'COMPOSITE' and plate2_type == 'COMPOSITE':
        a = 2/3
        b1 = 4.2
        b2 = 4.2
    elif plate1_type == 'COMPOSITE' and plate2_type == 'METALLIC':
        a = 2/3
        b1 = 4.2
        b2 = 3.0
    elif plate1_type == 'METALLIC' and plate2_type == 'COMPOSITE':
        a = 2/3
        b1 = 3.0
        b2 = 4.2
    elif plate1_type == 'METALLIC' and plate2_type == 'METALLIC':
        if fastener.is_bolt:
            a = 2/3
            b1 = 3.0
            b2 = 3.0
        if fastener.is_rivet:
            a = 2/5
            b1 = 2.2
            b2 = 2.2
    else:
        raise ValueError(
            'plate1 and/or plate2 are neither METALLIC nor COMPOSITE types.'
            'Please check'
        )
        return None

    c1 = ((t1 + t2)/(2*d))**a
    c2 = (b1/(t1*E1) + b2/(t2*E2) + b1/(2*t1*Er) + b2/(2*t2*Er))

    c = c1 * c2
    k = 1/c

    return k


class PilotPoint:
    def __init__(ref_Point: Point, drill_vector: Vector: diameter)


launcher_path = r'C:\Users\U69432\Desktop\PyAir\FEM\03_FEM_fastener_generator\Test\01_HF_2D_DFEM\HF_2D_DFem_v04_RBE2_SS_d70mm.bdf'
model = BDF()
model.read_bdf(
    bdf_filename=launcher_path,
    validate=False,
    xref=True,
    punch=False,
    read_includes=True,
    save_file_structure=False)

#
nodes = model.nodes
elements = model.elements


# -------------------------------------------------------------------TESTING
Al_7075 = Metallic(name='Al_7075',
                   norm=None,
                   shape='Sheet',
                   temp_treat='T3',
                   area_range=None,
                   thick_range='0.53-1.57',
                   basis='A',
                   Et=72395,
                   Ec=73744,
                   Ftu=413.68,
                   Fty=303.37,
                   Fcy=248.21,
                   Fsu=255.10,
                   Fbru_ed_1p5=None,
                   Fbry_ed_1p5=None,
                   Fbru_ed_2p0=None,
                   Fbry_ed_2p0=None,
                   e=0.12
                   )
plate1 = MetallicPlate(Al_7075, 2.0)
plate2 = MetallicPlate(Al_7075, 3.0)
fast = Fastener(Et=100000.0, diameter=4.0, head_type='PTR')
