# -*- coding: utf-8 -*-

import os
import sys
import xlwings as xw
import numpy as np



### Open File
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

def openEXCEL():
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    print('Opening EXCEL file...')
    op2fp = askopenfilename(
        title ='Open Excel', 
        filetypes=(("Nastran Excel file", '*.xlsx'),),
        multiple = False,
        defaultextension = ['.xlsx'],
        initialdir = os.getcwd(),
        parent = root
        )
    if op2fp =='':
        print('No file has been selected.')
    return op2fp

def gui(wb):
    user_inp =''
    while not(user_inp.upper().startswith('Q')):
    
        # Printing available options
        print('Select the Sheet with the FITAN analysis:')
        results = [item.name for item in list(wb.sheets)]
        results.sort()
        dict_results = dict(enumerate(results))
        print(dict_results)
        for (i,result) in dict_results.items():
            print ('\t',str(i),':\t',result )
        
        # Asking user to select and option or exit
        user_inp = input('Enter an option or Q to exit: ')
        
        # Selects 'Q' to exit
        if user_inp.upper().startswith('Q'):
            break
        
        # Selects a value out of the available options
        elif not(int(user_inp) in dict_results.keys()):
            print('Incorret option. Please try again.')
        
        else:
            return dict_results[int(user_inp)]


xls_path = openEXCEL()

cwd = os.path.dirname(xls_path)
            
# Opening xlwings
wb = xw.Book(xls_path)


# Accessing applicaiton point table
ws_name = gui(wb)
ws = wb.sheets[ws_name]

# Retrieving data 
# Title section
title1 = ws.range('Fitan_title1').value
title2 = ws.range('Fitan_title2').value
title3 = ws.range('Fitan_title3').value
title4 = ws.range('Fitan_title4').value

titles = [
    title2,
    title3,
    title4
    ]


# Material Data
Ftu = ws.range('Fitan_Ftu').value
Fty = ws.range('Fitan_Fty').value
Fsu = ws.range('Fitan_Fsu').value
Fitan_mat_name  = ws.range('Fitan_Mat').value
Fitan_mat_prod  = ws.range('Fitan_Prod').value
Fitan_mat_th    = ws.range('Fitan_thick').value
Fitan_mat_treat = ws.range('Fitan_Mat_treat').value
Fitan_mat_dir   = ws.range('Fitan_Mat_Dir').value
Fitan_mat_basis = ws.range('Fitan_Mat_Basis').value

mat_data=[
    Ftu,
    Fty,
    Fsu,
    Fitan_mat_name,
    Fitan_mat_prod,
    Fitan_mat_th,
    Fitan_mat_treat,
    Fitan_mat_dir,
    Fitan_mat_basis    
    ]

# Type of Analysis
Fitan_analysis_opt = ws.range('Fitan_Option').value
Fitan_field1 = ws.range('Fitan_field1').value
Fitan_field2 = ws.range('Fitan_field2').value
Fitan_field3 = ws.range('Fitan_field3').value
Fitan_field4 = ws.range('Fitan_field4').value
Fitan_field5 = ws.range('Fitan_field5').value
Fitan_field6 = ws.range('Fitan_field6').value
Fitan_field7 = ws.range('Fitan_field7').value
Fitan_field8 = ws.range('Fitan_field8').value
Fitan_field9 = ws.range('Fitan_field9').value
Fitan_field10 = ws.range('Fitan_field10').value
Fitan_field11 = ws.range('Fitan_field11').value
Fitan_field12 = ws.range('Fitan_field12').value
Fitan_field13 = ws.range('Fitan_field13').value
Fitan_field14 = ws.range('Fitan_field14').value
Fitan_field15 = ws.range('Fitan_field15').value
Fitan_field16 = ws.range('Fitan_field16').value

analysis_data = [
    Fitan_analysis_opt ,
    Fitan_field1,
    Fitan_field2,
    Fitan_field3,
    Fitan_field4,
    Fitan_field5,
    Fitan_field6,
    Fitan_field7,
    Fitan_field8,
    Fitan_field9,
    Fitan_field10,
    Fitan_field11,
    Fitan_field12,
    Fitan_field13,
    Fitan_field14,
    Fitan_field15,
    Fitan_field16    
    ]

# Loads
Pu = ws.range('Pu').value


# Writing File
fo_path = os.path.join(cwd,title2+'.dat')
fo_path = os.path.normpath(fo_path)

fo = open(fo_path,'w')
section1 = '1 TITLE\n'
section2 = '2 MATERIAL DATA\n'
section3 = '3 TYPE OF ANALYSIS\n'
section4 = '4 LOADS\n'

section1_lines=[]
for field in titles:
    if not(field is None):
        section1_lines.append('  ' + str(field) + '\n')

section2_line1= '\t' + str(Ftu) + '\t' + str(Fty) + '\t' + str(Fsu) + '\n'
section2_line2 = '\t' + str(Fitan_mat_name) + '\n'
section2_line3 = '\t' + str(Fitan_mat_prod) + '\n'
section2_line4 = '\t' + str(Fitan_mat_th) + '\n'
section2_line5 = '\t' + str(Fitan_mat_treat) + '\n'
section2_line6 = '\t' + str(Fitan_mat_dir) + '\n'
section2_line7 = '\t' + str(Fitan_mat_basis) + '\n'
section2_lines = [
    section2_line1,
    section2_line2,
    section2_line3,
    section2_line4,
    section2_line5,
    section2_line6,
    section2_line7    
    ]  

section3_line=''
for i in range(len(analysis_data)):
    if not(analysis_data[i] is None):
        if i==0:
            section3_line+= str(int(analysis_data[i]))
        else:
            section3_line+=('  ' + str(analysis_data[i]))
section3_line += '\n'

section4_line = '\t1\t' +str(Pu) +'\n'    

l2w =  [section1]
l2w += section1_lines
l2w += [section2]
l2w += section2_lines
l2w += [section3]
l2w += [section3_line]
l2w += [section4]
l2w += [section4_line]

for line in l2w:
    fo.writelines(line)
    
fo.close()    