# -*- coding: utf-8 -*-

from errors import *

'''
TEXT-BASED USER INTERFACE MODULE
'''


class TUI:

    def __init__(self,
                 options: list,
                 sel_msg=None,
                 label=None,
                 options_sort=False,
                 is_main=False,
                 return_opt=False):

        self.__selection_key = None
        self.__selection_val = None
        self.selection = None
        self.__text = 'Select an option: '
        self.__error_msgs = error_messages()
        self.label = label
        self.prev = None
        self.go_to = None
        self.__return_opt = return_opt

        if not (type(is_main) is bool):
            raise typerror_msg(is_main, bool)
        else:
            self.is_main = is_main
            self.__return_option_text = 'Back' if is_main is False else 'Exit'
            if self.is_main is True:
                self.__return_opt = True

        if (not (sel_msg is None) and (not (type(sel_msg) is str))):
            raise typerror_msg(sel_msg, str)
        else:
            self.sel_msg = sel_msg

        if not (type(options) is list):
            raise typerror_msg(options, list)
        else:
            if options_sort:
                options.sort()
            if self.__return_opt:
                options += [self.__return_option_text]
            self.options = dict(enumerate(options))

    def show_options(self):
        if not (self.sel_msg is None):
            print(self.sel_msg)
        print(self.__text)
        for (i, option) in self.options.items():
            print('\t', str(i), ':\t', option)

    def get_user_selection(self):

        user_inp = input('Enter an option : ')
        try:
            user_inp = int(user_inp)
            if not (int(user_inp) in self.options.keys()):
                print(self.__error_msgs.invalid_option)
            else:
                self.__selection_key = int(user_inp)
                self.__selection_value = self.options[user_inp]
                self.selection = self.options[user_inp]

        except:
            print(self.__error_msgs.invalid_option)
            self.selection = None

    def loop(self):
        while True:

            self.show_options()
            self.get_user_selection()
            if self.selection in list(self.options.values()):
                break
            else:
                self.clear_console()
        return self.selection

    def clear_console(self, include_spyder=True):
        cmd = 'cls' if os.name == 'nt' else 'clear'
        os.system(cmd)
        get_ipython().magic('clear')
