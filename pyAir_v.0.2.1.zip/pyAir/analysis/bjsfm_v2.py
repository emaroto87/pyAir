# -*- coding: utf-8 -*-
from typing import Optional, List, Union, Tuple
from structural.ply import Ply
from materials.composite import Orthotropic
import numpy as np
import cmath
import math

from structural.laminate import Laminate

PI = math.pi
RAD = PI / 180.0


def select_roots_from_coef(A_inv: np.ndarray) -> Tuple[float]:
    """
    Selección de R1, R2 en UNLODED / LOADED
    """
    COEF = np.zeros(5)
    COEF[0] = A_inv[1, 1] * 1e6
    COEF[1] = -2.0 * A_inv[1, 2] * 1e6
    COEF[2] = (2.0 * A_inv[0, 1] + A_inv[2, 2]) * 1e6
    COEF[3] = -2.0 * A_inv[0, 2] * 1e6
    COEF[4] = A_inv[0, 0] * 1e6

    roots = np.roots(COEF)

    # Ogonowski: escoger las 2 raíces con Im>0
    pos = [r for r in roots if r.imag > 0.0]
    if len(pos) != 2:
        raise RuntimeError("Las raíces complejas no son válidas")

    # ordenar por magnitud
    pos = sorted(pos, key=lambda r: abs(r))
    return pos[1], pos[0]  # R1, R2


def unloaded_hole_exact(
    laminate: Laminate,
    px: float,
    diameter: float,
    beta_deg: float,
    dist_points: np.ndarray,
    angles_deg: np.ndarray
):

    AI = laminate.A_inv
    R1, R2 = select_roots_from_coef(AI)

    beta = beta_deg * RAD
    a = diameter / 2.0

    nd = len(dist_points)
    na = len(angles_deg)

    stress = np.zeros((3, nd, na))
    u = np.zeros((nd, na))
    v = np.zeros((nd, na))

    for i, d in enumerate(dist_points):
        r = a + d
        for j, ang in enumerate(angles_deg):
            theta = ang * RAD

            x = r * math.cos(theta)
            y = r * math.sin(theta)

            z1 = x + R1 * y
            z2 = x + R2 * y

            XI1 = cmath.sqrt(z1*z1 - a*a * (1 + R1*R1))
            XI2 = cmath.sqrt(z2*z2 - a*a * (1 + R2*R2))

            # selección de rama (IGUAL que Fortran)
            if (z1 / XI1).real < 0:
                XI1 = -XI1
            if (z2 / XI2).real < 0:
                XI2 = -XI2

            COMPLX = 1j

            COM1 = (
                R2*math.sin(2*beta)
                + 2*math.cos(beta)**2
                + COMPLX*(2 - R2*math.sin(beta)**2)
            )
            COM2 = (
                R1*math.sin(2*beta)
                + 2*math.cos(beta)**2
                + COMPLX*(2*R1 - math.sin(beta)**2)
            )

            DEN1 = 2*a*(R1 - R2)*(1 + COMPLX*R1)
            DEN2 = 2*a*(R1 - R2)*(1 + COMPLX*R2)

            PHI1 = COMPLX*px*diameter*COM1*XI1/(2*DEN1)
            PHI2 = COMPLX*px*diameter*COM2*XI2/(2*DEN2)

            sx = 2*((R1*R1*PHI1).real + (R2*R2*PHI2).real)
            sy = -(PHI1 + PHI2).real
            sxy = -2*((R1*PHI1).real + (R2*PHI2).real)

            stress[0, i, j] = sx
            stress[1, i, j] = sy
            stress[2, i, j] = sxy

            u[i, j] = 2*(PHI1.real + PHI2.real)
            v[i, j] = 2*((AI[0, 1]*PHI1.real) + (AI[0, 1]*PHI2.real))

    return stress, u, v


def loaded_hole_exact(
    laminate,
    P,
    diameter,
    alpha_deg,
    dist_points,
    angles_deg,
    Mmax=45
):
    """
    Traducción directa de SUBROUTINE LOADED del BJSFM (cap. 7)
    """
    import numpy as np
    import cmath
    import math

    PI = math.pi
    RAD = PI / 180.0
    COMPLX = 1j

    AI = laminate.A_inv
    S = AI  # en LOADED el Fortran usa S como compliance

    # -------------------------------
    # Raíces complejas
    # -------------------------------
    R1, R2 = select_roots_from_coef(S)

    a = diameter / 2.0
    alpha = alpha_deg * RAD

    # -------------------------------
    # Coeficientes de la distribución coseno
    # -------------------------------
    CPOS = np.zeros(Mmax + 1, dtype=np.complex128)
    CNEG = np.zeros(Mmax + 1, dtype=np.complex128)
    CZERO = 0.0 + 0j

    PI2 = PI / 2.0
    Pnorm = 4.0 * P / PI

    # Traducción literal del bloque Fortran
    for m in range(0, Mmax + 1):
        if m == 0:
            CZERO = Pnorm * PI2
        else:
            CPOS[m] = (
                Pnorm * math.sin((m - 1) * PI2) / (2.0 * (m - 1))
                if m != 1 else Pnorm * PI2
            )

    # -------------------------------
    # Preparar coeficientes A1, A2
    # -------------------------------
    A1 = np.zeros(Mmax + 1, dtype=np.complex128)
    A2 = np.zeros(Mmax + 1, dtype=np.complex128)

    S1 = R1.real
    T1 = R1.imag
    S2 = R2.real
    T2 = R2.imag

    # -------------------------------
    # Resolver sistema 4x4 por armónico
    # -------------------------------
    for m in range(1, Mmax + 1):
        MN = m - 1

        if MN == 0:
            B = np.array([
                -CZERO * diameter / 2.0,
                0.0,
                0.0,
                0.0
            ], dtype=np.complex128)
        else:
            B = np.array([
                -CPOS[MN] * diameter / (2.0 * (MN + 1)),
                0.0,
                0.0,
                0.0
            ], dtype=np.complex128)

        # Matriz AMATRX del Fortran
        A = np.array([
            [T1 + 1.0, -S1,        T2 + 1.0, -S2],
            [S1,        -(T1 + 1), -S2,        T2 + 1],
            [-1.0 - T1, -S1,       -1.0 - T2, -S2],
            [S1,        1.0 - T1,  S2,         1.0 - T2],
        ], dtype=np.complex128)

        # Resolver sistema
        sol = np.linalg.solve(A, B)

        A1[m] = sol[0] + COMPLX * sol[1]
        A2[m] = sol[2] + COMPLX * sol[3]

    # -------------------------------
    # Evaluación del campo de tensiones
    # -------------------------------
    nd = len(dist_points)
    na = len(angles_deg)

    stress = np.zeros((3, nd, na))
    u = np.zeros((nd, na))
    v = np.zeros((nd, na))

    for i, d in enumerate(dist_points):
        r = a + d
        for j, ang in enumerate(angles_deg):
            theta = ang * RAD

            x = r * math.cos(theta + alpha)
            y = r * math.sin(theta + alpha)

            z1 = x + R1 * y
            z2 = x + R2 * y

            XI1 = cmath.sqrt(z1*z1 - a*a * (1 + R1*R1))
            XI2 = cmath.sqrt(z2*z2 - a*a * (1 + R2*R2))

            if (z1 / XI1).real < 0:
                XI1 = -XI1
            if (z2 / XI2).real < 0:
                XI2 = -XI2

            P1 = 0.0 + 0j
            P2 = 0.0 + 0j
            for m in range(1, Mmax + 1):
                P1 += m * A1[m] * XI1**(-m)
                P2 += m * A2[m] * XI2**(-m)

            sx = 2.0 * (R1*R1*P1 + R2*R2*P2).real
            sy = -(P1 + P2).real
            sxy = -2.0 * (R1*P1 + R2*P2).real

            stress[0, i, j] = sx
            stress[1, i, j] = sy
            stress[2, i, j] = sxy
            u[i, j] = 2.0 * P1.real
            v[i, j] = 2.0 * P2.real

            if True:
                print(f'At radius {i} at distance {d}')
                print(f'At angle {j} of {ang}')
                print(f'\U0001D70Ex: {sx}')
                print(f'\U0001D70Ey: {sy}')
                print(f'\U0001D70Exy: {sxy}')

    return stress, u, v


# BJSFM Example 1 - Loaded Hole Case
# ----------------------------------
# Ejemplo extraido directamente de la referencia

mat = Orthotropic(
    name='bjsfm_ex1',
    thickness=0.125,
    E1=19.85e+6,
    E2=1.9e+6,
    G12=0.85e+6,
    nu12=0.30,
)
ply_0 = Ply(
    material=mat,
    theta_deg=0.0
)
ply_90 = Ply(
    material=mat,
    theta_deg=90.0
)
ply_45p = Ply(
    material=mat,
    theta_deg=45.0
)
ply_45n = Ply(
    material=mat,
    theta_deg=-45.0
)

plies = [ply_0, ply_45p, ply_45n, ply_90]
stacking = np.repeat(plies, (42, 25, 25, 8)).tolist()

laminate = Laminate(
    stacking=stacking,
    name='eh_ex1_laminate')

laminate.A_inv

angles_deg = np.arange(0.0, 91.0, 30.0)
dist_points = [0.0, 0.02, 0.04]
alpha_deg = 20.0
P = 50.000
width = 1.5

s, u, v = loaded_hole_exact(
    laminate=laminate,
    P=P,
    diameter=0.25,
    alpha_deg=alpha_deg,
    angles_deg=angles_deg,
    dist_points=dist_points)
