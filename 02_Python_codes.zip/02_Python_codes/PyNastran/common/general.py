# -*- coding: utf-8 -*-
"""
Created on Fri May 23 09:26:07 2025

@author: U69432
"""

import os 
import sys

from typing import Optional 
from typing import Dict
from typing import List
from typing import Literal

import pandas as pd
import xlwings as xw
import numpy as np

from pyNastran.op2.op2 import OP2 
from tqdm import tqdm

import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

from collections import namedtuple
from IPython import get_ipython

from pathlib import Path

__version__ = '1.0.0'
__author__ = 'E.Maroto'

# Default Values
entities_types = namedtuple('entities_type',['node','element'])

__ENTITY_TYPES = [
    'NodeID',
    'ElementID',
    'SubcaseID'
    ]

__CASE_CONTROL_PARAMS =[
    'TITLE',
    'LABEL'
    ]

def askopenNastran(verbose=False ,multiple = False)->str:
    '''
    Opens a UI dialog window to open a NASTRAN bulk data file (bdf). If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string
        

    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    
    if verbose : print('Opening NASTRAN BDF file...',end='')
    
    path = askopenfilename(
        title ='Open Sets File', 
        filetypes=(("BDF file", '*.bdf'),("DAT file", '*.dat'),("INCLUDE file", '*.incl')),
        multiple = multiple,
        defaultextension = ['.bdf'],
        initialdir = os.getcwd(),
        parent = root
        )
    if path =='':
        print('No file has been selected.')
        path = None
    else: 
        print ('Done')
    return path


def ask_set_filepath(verbose=False ,multiple = False)->str:
    '''
    Opens a UI dialog window to open a Sets file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string
        

    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    
    if verbose : print('Opening Sets file...',end='')
    
    path = askopenfilename(
        title ='Open Sets File', 
        filetypes=(("Sets file", '*.set'),),
        multiple = multiple,
        defaultextension = ['.op2'],
        initialdir = os.getcwd(),
        parent = root
        )
    if path =='':
        print('No file has been selected.')
        path = None
    else: 
        print ('Done')
    return path


def ask_op2_filepath(verbose=False ,multiple = False)->str:
    '''
    Opens a UI dialog window to open a OP2 file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string
        

    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    
    if verbose : print('Opening OP2 file...',end='')
    
    path = askopenfilename(
        title ='Open OP2', 
        filetypes=(("Nastran OP2 file", '*.op2'),),
        multiple = multiple,
        defaultextension = ['.op2'],
        initialdir = os.getcwd(),
        parent = root
        )
    if path =='':
        print('No file has been selected.')
        path = None
    else: 
        print ('Done')
    return path

def asksaveasexcelfile(verbose=False ,multiple = False)->str:
    '''
    Opens a UI dialog window to save a Excel file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string
        

    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    
    if verbose : print('Saving Excel file...',end='')
       
    path = asksaveasfilename(
            title ='Save EXCEL file...', 
            filetypes=(("EXCEL file", '*.xlsx'),),
            defaultextension = ['*.xlsx'],
            initialdir = os.getcwd(),
            parent = root
            ),
    
    if path =='':
        print('No file has been selected.')
        path = None
    else: 
        print ('Done')
    return path

def load_op2_file(path : str, build_dataframe: bool =True)->OP2:
    
    
    
    o = OP2()
    
    
    
    o.read_op2(path,
               build_dataframe = build_dataframe,
               # skip_undefined_matrices = True
               )
    return o



def check_type(obj,obj_class):
    if not(isinstance(obj,obj_class)):
        error_msg = 'Object {0} is not a {1}type'.format(
            str(type(obj)),
            str(type(obj_class))
            )
        raise TypeError(error_msg)
def check_option(option :str, options:list[str]):
    check_type(option,str)
    check_type(options,list)
    if not(option in options):
        raise ValueError(
            f'{option} is not one of the valid values included in {options}'
            )

def concat(*args,**kargs):
    s =''
    for i in args:
        s+=i
    return s

def vector_mod(p1,p2):
    v=p2-p1
    return np.sqrt(np.dot(v,v))


##### WRITING CARDS
def split_list(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i : i + n]

def merge_dfs(*args,**kwargs):

    df_list = [ arg for arg in args]
    merged_df = pd.concat(df_list)
    
    return merged_df

##### READING Progress bar (WIP)
def progress_OP2_bar(path):
    op2=OP2()
    file_size = os.path.getsize(path)
    with open(path, 'rb') as file:
        with tqdm(file_size, unit='B',unit_scale=True, desc='Reading file') as bar:
            def read_progress(n):
                data = file.read(n)
                bar.update(len(data))
                return data
            op2.read_op2(path, read_binary=read_progress)



__version__ = '1.0.0'
__author__ = 'E.Maroto'

### Open File
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

def openEXCEL():
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    print('Opening EXCEL file...')
    fp = askopenfilename(
        title ='Open Excel', 
        filetypes=(("Excel file", '*.xlsx'),),
        multiple = False,
        defaultextension = ['.xlsx'],
        initialdir = os.getcwd(),
        parent = root
        )
    if fp =='':
        print('No file has been selected.')
    return fp
### Error functions

def typerror_msg(obj : object, expected_obj: object)->str:
    msg = '{0} object is not a {1}'.format(
        type(obj),
        expected_obj
            )
    return TypeError(msg)

class error_messages:
    def __init__(self):
        self.invalid_option = '[Error] Incorret option. Please try again.'

# Exporting
def df_to_excel_sheet(dataframe,sheet_name=None):
        print('Exporting data to Excel...', end='')
       
        # Opening xlwings
        app = xw.App(visible=False)
        wb = app.books[0]
        ws = wb.sheets[0]
        ws.activate()
        
        # Exporting data to default sheet1
        ws["A1"].options(
            pd.DataFrame, 
            header=1, 
            index=True, 
            expand='table').value = dataframe
        print('Done')
        
        # Re-labeling Default Sheet1
        if not(sheet_name is None):
            ws.name = sheet_name
        
        # Saving
        wb.save(
            path = asksaveasfilename(
                    title ='Save EXCEL file...', 
                    filetypes=(("EXCEL file", '*.xlsx'),),
                    defaultextension = ['*.xlsx'],
                    initialdir = os.getcwd()
                    ),
            )
        wb.close()
        print('Done')


# PANDAS DATAFRAME FROM EXCEL SHEET
def to_excel(tables : Dict[str,pd.DataFrame], output_filename : Path) :
    '''
    Export into an Excel file multiple pandas DataFrames stored within a 
    dictionary

    Parameters
    ----------
    tables : Dict [str, pd.DataFrame ]
        Dictionary containing the pandas DataFrames. Each key of the dictionary
        is used to label the sheet of the Excel book file.
    filename : str path-like
        Path of the output Excel file.

    Returns
    -------
    None.

    '''
    # Checking
    check_type(tables,dict)
    check_type(output_filename,str)
        
    print('Exporting to Excel File ...', sep='')
    with pd.ExcelWriter(output_filename) as writer:
        for sheet_name, table in tables.items():
            table.to_excel(writer, sheet_name=sheet_name, index=False)  
    print('[Done]') 



#CONSOLE USER INTERFACE

class ui_menu:
    
    def __init__(self, 
                 options:list, 
                 sel_msg = None, 
                 label = None, 
                 options_sort=False, 
                 is_main=False,
                 return_opt =False):
  
          
        self.__selection_key = None
        self.__selection_val = None
        self.selection = None
        self.__text = 'Select an option: '
        self.__error_msgs = error_messages()
        self.label = label
        self.prev = None
        self.go_to = None
        self.__return_opt = return_opt 
        
        if not(type(is_main) is bool):
            raise typerror_msg(is_main,bool)
        else:
            self.is_main = is_main
            self.__return_option_text = 'Back' if is_main is False else 'Exit' 
            if self.is_main is True: self.__return_opt = True
        
        if (not(sel_msg is None) and (not(type(sel_msg) is str))):
            raise typerror_msg(sel_msg,str)
        else:
            self.sel_msg = sel_msg
        
        if not(type(options) is list):
            raise typerror_msg(options,list)
        else:
            if options_sort : options.sort()
            if self.__return_opt : options += [self.__return_option_text]
            self.options = dict(enumerate(options))
     

    
    
    def show_options(self):
        if not(self.sel_msg is None) : print(self.sel_msg)
        print(self.__text)
        for (i,option) in self.options.items():
            print ('\t',str(i),':\t',option)
    
    
    def get_user_selection(self):
        
        user_inp = input('Enter an option : ')
        try:
            user_inp = int(user_inp)
            if not(int(user_inp) in self.options.keys()):
                print(self.__error_msgs.invalid_option)
            else:
                self.__selection_key = int(user_inp)
                self.__selection_value = self.options[user_inp]
                self.selection = self.options[user_inp]
                
        except:
            print(self.__error_msgs.invalid_option)
            self.selection = None
 
    def loop(self):
        while True:
            
            self.show_options()
            self.get_user_selection()
            if self.selection in list(self.options.values()):
                break
            else:
                self.clear_console()
        return self.selection
                
            
    def clear_console(self,include_spyder=True):
        cmd = 'cls' if os.name == 'nt' else 'clear' 
        os.system(cmd)
        get_ipython().magic('clear')
        