# -*- coding: utf-8 -*-
"""

"""
# ARPA
# Importing external dependencies
import numpy as np
from typing import List, Tuple, Dict, Iterable
from scipy.linalg import eig
from math import sin
from math import cos
from math import pi
import matplotlib.pyplot as plt
import matplotlib.colors as colors
from matplotlib import cm
import warnings

# Importing pyAir dependencies
from structural.laminate import Laminate

'''
Notas:


    Y

    ^
    |
    |
    ++++++++++++++++++++++++++++++++++
    +                                +
    +                                +
    +                                + B
    +                                +
    +                                +
    ++++++++++++++++++++++++++++++++++  ---> X
                    L

    a) Dimensiones: Longitud L y anchura B

    b) Apoyado en sus cuatro bordes, con rigideces GJx en los bordes longitu-
    dinales y GJy en los transversales.

    c) Con cambios transversales (dir. y) de espesor y/o material, es decir,
    compuestos por M tramos de anchura bm de rigidez constante (las anchuras
    y las rigideces pueden cambiar de un tramo a otro). La matriz geenralizada
    de rigidez de cada tramo vale [D*]m. El tramo "m" está situado entre
    las distancias ym1 e ym2 con respecto al borde izquierdo del panel

    d) Cada tramo longitudinal puede estar compuesto por capas de materiales
    diferentes, cada una de las cuales tiene un espesor tij (capa j del tramo i)

    e) El material de cada una de las capas anteriores ha de ser ortotropico
    y elastico

    f) Reforda por medio de "Nr" elementos longitudinales de rigidez axial
    constante (que puede variar de un rigidizador a otro), los cuales están
    situados a distancias yrn del borde longitudilan del panel. Estos rigidi-
    zadores tienen unos modulos elasticos Ern,Grn. Sus propiedades geometricas
    son Arn, Irn, y constantes de torsion y warping Jrn y Cwrn.

    g) Sometido a cargas en el plano
         - Longitudinal : Px
         - Carga transversal de cada tramo: Pym
         - Flujo de cortadura en cada tramo: Pxym
'''

'''
CONTROL DE VERSIONES
=====================
v.0.6:
-----
    - Añadimos parte de visualización en 3D con matplotlib
    - Añadidos ejemplos Ex1 al Ex4. El Ex4 que es cortadura pura no soy capaz
    de correlar los resultados.
v.0.7:
-----
    - He generado las funciones para poder ver la deformada de pandeo y estoy
    viendo que las ondas de pandeo no están coincidiendo ni por asomo.
v.0.8:
------
    - Sigo sin poder hacer que correlen las ondas de pandeo. Además he corrobo
    rado con un FEM que lo que saca PANPA y NASTRAN es lo mismo. Por tanto el
    problema debe estar en algo que está mal en código. Problablemente sea en
    la interpretación de la posición de los indices "i" e "j" a la hora de
    ensamblar la matrix Q y T y por tanto la posición de los miembros del
    vector Wij.

    - También he podido comprobar que el script obtiene bien los 5 primeros
    autovalores pero a partir de ahí los resultados que proporciona empieza
    diferenciarese con respecto a los obtenidos en Nastran.

    - Arreglado el problema que obligaba a introducir el signo negativo
v.0.9:
------
    - Arreglado el tema de las ondas en pandeo al menos en los casos de Nxx
    e Nyy pura. Pero tengo problemas con la cortadura. Aunque los autovalores
    los saca iguales quen el PANPA.
v.0.10:
------
    - Se añade la opción meter restrcciones en los bordes con GJx y GJy
        - Se incluye la función is_even para saber si un número es par
    - Se crea la función "analysis_buckling_composite_laminates" que será
    la función principal de análisis. Se modifican todas las función para que
    llamen de manera local a las variables:
        * L, B
        * nx, ny
        * d1y_list,......d6y_list,
        * fxm_list, fym_list, fxym_list
    - Mejorado la función draw
    - Se ha simplificado la función de los ejemplos.
    
    * Para el futuro:
        - meter en analysis_buckling_composite_laminates:
            + Comprobaciones de los inputs.
        - Meter el efecto de los larguerillos longitudinales (X)

    

'''

__version__ = '0.10'
__release_date__ = '15/04/2026'


def is_even(number: float):
    return True if number % 2 == 0 else False


def alpha(n: int, L: float) -> float:
    return n * pi / L


def alpha2(n: int, L: float) -> float:
    x = alpha(n, L)
    return x**2


def beta(n: int, B: float) -> float:
    return n * pi / B


def beta2(n: int, B: float) -> float:
    x = beta(n, B)
    return x**2


def integral_ss(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 - sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 - num2/den2
    return out


def integral_cc(A: float, B: float, x: float) -> float:
    if A == B:
        out = x/2 + sin(2*A*x) / (4*A)
    else:
        num1 = sin((A-B)*x)
        den1 = 2*(A-B)
        num2 = sin((A+B)*x)
        den2 = 2*(A+B)
        out = num1/den1 + num2/den2
    return out


def integral_sc(A: float, B: float, x: float) -> float:
    if A == B:
        out = - ((cos(A*x))**2)/(2*A)
    else:
        num1 = cos((A-B)*x)
        den1 = 2*(A-B)
        num2 = cos((A+B)*x)
        den2 = 2*(A+B)
        out = -num1/den1 - num2/den2
    return out


def fss(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_ss(A, B, x_end) - integral_ss(A, B, x_ini)


def fcc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_cc(A, B, x_end) - integral_cc(A, B, x_ini)


def fsc(A: float, B: float, x_ini: float, x_end: float) -> float:
    return integral_sc(A, B, x_end) - integral_sc(A, B, x_ini)


def fss_ik(i: int, k: int, L: float) -> float:
    a = i * pi / L
    b = k * pi / L
    return fss(a, b, 0, L)


def fcc_ik(i: int, k: int, L: float) -> float:
    a = i * pi / L
    b = k * pi / L
    return fcc(a, b, 0, L)


def fsc_ik(i: int, k: int, L: float) -> float:
    a = i * pi / L
    b = k * pi / L
    return fsc(a, b, 0, L)


def fss_jl(j: int, l: int, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fss(a, b, 0, B)


def fcc_jl(j: int, l: int, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fcc(a, b, 0, B)


def fsc_jl(j: int, l: int, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fsc(a, b, 0, B)


# PARTE I : ENERGIA INTERNA U
# =============================================================================


def f1jl_m(D11m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D11m_star * fss(a, b, ym1, ym2)


def f1jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f1jl = 0
    d1y_list = Dm_star_list[0]
    for D11m_star, ym1, ym2 in d1y_list:
        f1jl += f1jl_m(D11m_star, ym1, ym2, j, l, B)
    return f1jl


def f2jl_m(D22m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D22m_star * fss(a, b, ym1, ym2)


def f2jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f2jl = 0
    d2y_list = Dm_star_list[1]
    for D22m_star, ym1, ym2 in d2y_list:
        f2jl += f2jl_m(D22m_star, ym1, ym2, j, l, B)
    return f2jl


def f3jl_m(D33m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D33m_star * fcc(a, b, ym1, ym2)


def f3jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f3jl = 0
    d3y_list = Dm_star_list[2]
    for D33m_star, ym1, ym2 in d3y_list:
        f3jl += f3jl_m(D33m_star, ym1, ym2, j, l, B)
    return f3jl


def f4jl_m(D12m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D12m_star * fss(a, b, ym1, ym2)


def f4jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f4jl = 0
    d4y_list = Dm_star_list[3]
    for D12m_star, ym1, ym2 in d4y_list:
        f4jl += f4jl_m(D12m_star, ym1, ym2, j, l, B)
    return f4jl


def f5jl_m(D13m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D13m_star * fsc(a, b, ym1, ym2)


def f5jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f5jl = 0
    d5y_list = Dm_star_list[4]
    for D13m_star, ym1, ym2 in d5y_list:
        f5jl += f5jl_m(D13m_star, ym1, ym2, j, l, B)
    return f5jl


def f6jl_m(D23m_star: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return D23m_star * fsc(a, b, ym1, ym2)


def f6jl(Dm_star_list: list[tuple], j: float, l: float, B: float) -> float:
    f6jl = 0
    d6y_list = Dm_star_list[5]
    for D23m_star, ym1, ym2 in d6y_list:
        f6jl += f6jl_m(D23m_star, ym1, ym2, j, l, B)
    return f6jl


def du1dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return alpha2(i, L) * alpha2(k, L) * fss_ik(i, k, L) * f1jl(Dm_star_list, j, l, B)


def du2dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return beta2(j, B) * beta2(l, B) * fss_ik(i, k, L) * f2jl(Dm_star_list, j, l, B)


def du3dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return 4 * alpha(i, L) * alpha(k, L) * beta(j, B) * beta(l, B) * fcc_ik(i, k, L) * f3jl(Dm_star_list, j, l, B)


def du4dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return (alpha2(i, L) * beta2(l, B) + alpha2(k, L) * beta2(j, B)) * fss_ik(i, k, L) * f4jl(Dm_star_list, j, l, B)


def du5dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    first = alpha2(i, L) * alpha(k, L) * beta(l, B) * \
        fsc_ik(i, k, L) * f5jl(Dm_star_list, j, l, B)
    # Nota: en la doc, aparece fsc_ik(k,i), puede que sea una errata
    secnd = alpha(i, L) * alpha2(k, L) * beta(j, B) * \
        fsc_ik(k, i, L) * f5jl(Dm_star_list, l, j, B)
    return -2 * (first + secnd)


def du6dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    first = alpha(k, L) * beta2(j, B) * beta(l, B) * \
        fsc_ik(i, k, L) * f6jl(Dm_star_list, j, l, B)
    secnd = alpha(i, L) * beta(j, B) * beta2(l, B) * \
        fsc_ik(k, i, L) * f6jl(Dm_star_list, l, j, B)
    return -2 * (first + secnd)


def du7dwij_kl(i: int, j: int, k: int, l: int, L: float, B: float, GJx: float, GJy: float) -> float:
    # Termino asociado a las condiciones de contorno en rotación en los
    # bordes GJx y GJy.
    if is_even(j+l):
        first = 2 * GJx * alpha(i, L) * alpha(k, L) * \
            beta(j, B) * beta(l, B) * fcc_ik(i, k, L)
    else:
        first = 0
    if is_even(i+k):
        secnd = 2 * GJy * alpha(i, L) * alpha(k, L) * \
            beta(j, B) * beta(l, B) * fcc_ik(j, l, L)
    else:
        secnd = 0
    return first + secnd

# Total Internal Energy


def du_dwij_kl(Dm_star_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float, GJx: float, GJy: float) -> float:
    return du1dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du2dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du3dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du4dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du5dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du6dwij_kl(Dm_star_list, i, j, k, l, L, B) + \
        du7dwij_kl(i, j, k, l, L, B, GJx, GJy)

# PARTE II : ENERGIA POTENCIAL V
# =============================================================================


def g1jl_m(fxm: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fxm * fss(a, b, ym1, ym2)


def g1jl(fluxes_list: list[tuple], j: float, l: float, B: float) -> float:
    g1jl = 0
    fxm_list = fluxes_list[0]
    for fxm, ym1, ym2 in fxm_list:
        g1jl += g1jl_m(fxm, ym1, ym2, j, l, B)
    return g1jl


def g2jl_m(fym: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fym * fcc(a, b, ym1, ym2)


def g2jl(fluxes_list: list[tuple], j: float, l: float, B: float) -> float:
    g2jl = 0
    fym_list = fluxes_list[1]
    for fym, ym1, ym2 in fym_list:
        g2jl += g2jl_m(fym, ym1, ym2, j, l, B)
    return g2jl


def g3jl_m(fxym: float, ym1: float, ym2: float, j: float, l: float, B: float) -> float:
    a = j * pi / B
    b = l * pi / B
    return fxym * fsc(a, b, ym1, ym2)


def g3jl(fluxes_list: list[tuple], j: float, l: float, B: float) -> float:
    g3jl = 0
    fxym_list = fluxes_list[2]
    for fxym, ym1, ym2 in fxym_list:
        g3jl += g3jl_m(fxym, ym1, ym2, j, l, B)
    return g3jl


def dv1dwij_kl(fluxes_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return alpha(i, L) * alpha(k, L) * fss_ik(i, k, L) * g1jl(fluxes_list, j, l, B)


def dv2dwij_kl(fluxes_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return beta(j, B) * beta(l, B) * fss_ik(i, k, L) * g2jl(fluxes_list, j, l, B)


def dv3dwij_kl(fluxes_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    first = alpha(i, L) * beta(l, B) * fsc_ik(k, i, L) * \
        g3jl(fluxes_list, j, l, B)
    secnd = alpha(k, L) * beta(j, B) * fsc_ik(i, k, L) * \
        g3jl(fluxes_list, l, j, B)
    return (first + secnd)


# Total Potential Energy
def dv_dwij_kl(fluxes_list: list[tuple], i: int, j: int, k: int, l: int, L: float, B: float) -> float:
    return dv1dwij_kl(fluxes_list, i, j, k, l, L, B) + \
        dv2dwij_kl(fluxes_list, i, j, k, l, L, B) + \
        dv3dwij_kl(fluxes_list, i, j, k, l, L, B)


# PARTE III : RESOLUCION DEL PROBLEMA DE AUTOVALORES
# =============================================================================
def idx(i, j, ny):
    return (i-1)*ny + (j-1)


def QT_matrices(
        Dm_star_list: list[tuple],
        fluxes_list: list[tuple],
        L: float,
        B: float,
        GJx: float,
        GJy: float,
        nx=10,
        ny=10,
        tol=1e-6):

    # initialasing matrixes
    q = np.zeros((nx*ny, nx*ny), dtype=np.float64)
    t = np.zeros((nx*ny, nx*ny), dtype=np.float64)

    for i in range(1, nx+1):
        for j in range(1, ny+1):
            row = idx(i, j, ny)
            for k in range(1, nx+1):
                for l in range(1, ny+1):
                    col = idx(k, l, ny)
                    # Terms of Q and T matrices
                    qij_kl = du_dwij_kl(Dm_star_list, i, j,
                                        k, l, L, B, GJx, GJy)
                    tij_kl = dv_dwij_kl(fluxes_list, i, j, k, l, L, B)

                    if abs(qij_kl) < tol:
                        qij_kl = 0.0
                    if abs(tij_kl) < tol:
                        tij_kl = 0.0

                    q[row, col] = qij_kl
                    t[row, col] = tij_kl
                    # print(
                    #     f" {i} {j} {k} {l} Q{row}{col}={qij_kl}")
    return q, t


def solve_eig(Q_matrix: np.ndarray, T_matrix: np.ndarray):
    """
    Solves the ([Q] + lambda[T]) · X = 0 eigenvalue problem.
    """
    # Resolvemos el problema de autovalores.
    eigvalues, eigvectors = eig(Q_matrix, -T_matrix)
    # Filtrado
    mask = (np.imag(eigvalues) == 0) & (np.real(eigvalues) >= 0)
    valid_eigvalues = eigvalues[mask].real
    valid_eigvectors = eigvectors[:, mask]
    sorted_indices = np.argsort(valid_eigvalues)
    sorted_eigvalues = valid_eigvalues[sorted_indices]
    sorted_eigvectors = valid_eigvectors[:, sorted_indices]

    return sorted_eigvalues, sorted_eigvectors


def solve_eig_tikhonov(
        Q_matrix: np.ndarray,
        T_matrix: np.ndarray,
        lambda_reg: float = 1e-8):
    """
    Solve a eigen problem using the Tikhonov stabilization for ill-conditioned
    problems. Being the equation as follows:
        ([Q] + lambda[T]) · X = 0

    Recommended values of lambda_reg:
        - 1e-6 -> High stability but introduces greater smoothinf
        - 1e-8 -> Balanced stability (recommended)
        - 1e-10 -> Low stability improvement but less numeric alteration.

    Returns (eigenvalues, eigenvectors)
    """
    q = Q_matrix
    t = T_matrix
    # Creamos las matrices Q y T regularizadas
    n = q.shape[0]
    q_reg = q + lambda_reg * np.eye(n)
    t_reg = t + lambda_reg * np.eye(n)
    eigvalues, eigvectors = eig(q_reg, -t_reg)
    # Filtrado
    mask = (np.imag(eigvalues) == 0) & (np.real(eigvalues) >= 0)
    valid_eigvalues = eigvalues[mask].real
    valid_eigvectors = eigvectors[:, mask]
    sorted_indices = np.argsort(valid_eigvalues)
    sorted_eigvalues = valid_eigvalues[sorted_indices]
    sorted_eigvectors = valid_eigvectors[:, sorted_indices]

    return sorted_eigvalues, sorted_eigvectors


# PARTE IV : VISUALIZACION DE RESULTADOS
# =============================================================================


def eigmode(nx: int, ny: int, wij_coeff_array: np.array, tol=1e-3):
    wij_coeff_array_real = wij_coeff_array.real
    abs_w = np.abs(wij_coeff_array_real)
    idx = np.argmax(abs_w)
    mode_i = idx // ny + 1
    mode_j = idx % ny + 1
    main_w = wij_coeff_array_real[idx]
    return main_w, mode_i, mode_j


# def XYZ(i: int, j: int, wij: float, L: float, B: float, points_wave_x=50, points_wave_y=50):

#     x = np.linspace(0, L, points_wave_x)
#     y = np.linspace(0, B, points_wave_y)
#     x, y = np.meshgrid(x, y)
#     z = wij * np.sin(alpha(i, L)*x) * np.sin(beta(j, B)*y)
#     return x, y, z


def XYZ_all(wij_vector: np.array, nx: int, ny: int, L: float, B: float, points_wave_x=50, points_wave_y=50):
    wij_vector = wij_vector / np.max(np.abs(wij_vector))
    x = np.linspace(0, L, points_wave_x)
    y = np.linspace(0, B, points_wave_y)
    x, y = np.meshgrid(x, y)
    z = np.zeros_like(x)
    for i in range(1, nx+1):
        for j in range(1, ny+1):
            index = idx(i, j, ny)
            coeff = wij_vector[index]
            z += coeff * np.sin(alpha(i, L)*x) * np.sin(beta(j, B)*y)
    return x, y, z


def draw(x: np.array, y: np. array, z: np.array, L: float, B: float, scale_factor=1.0):

    # Plot the surface
    x = scale_factor * x
    y = scale_factor * y
    z = scale_factor * z
    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    ax.set_box_aspect((L, B, min(L, B)))
    norm = colors.Normalize(vmin=-1, vmax=1)
    surf = ax.plot_surface(x, y, z,
                           vmin=z.min() * 2,
                           cmap=cm.rainbow,
                           edgecolor='black',
                           linewidth=0.1,
                           norm=norm)
    ax.set_xlabel('Length (L)', labelpad=25)
    ax.set_ylabel('Width (B)', labelpad=10)
    ax.set_zlabel('Shape (W)', labelpad=10)
    plt.colorbar(surf, shrink=0.5, aspect=10)

    # Alter fig size
    # fig.set_figwidth(3)
    # fig.set_figheight(1)

    # ax.set(xticklabels=[],
    #        yticklabels=[],
    #        zticklabels=[])

    plt.show()


def eigendata(nx: int, ny: int, eigenvalues: np.array, eigenvectors: np.array):

    eigenvalues_list = eigenvalues.tolist()

    for k in range(len(eigenvalues)):
        eigenvalue = eigenvalues[k]
        eigenvector = eigenvectors[k]
        main_w, mode_i, mode_j = eigmode(nx, ny, eigenvector)

# PARTE V : PROGRAMA PRINCIPAL
# =============================================================================


def print_data():
    pass


class NoPositiveEigenvalue(UserWarning):
    pass


def analysis_buckling_composite_laminates(
    # Geometry data
    plate_length: float,
    plate_width: float,
    laminates: Iterable[Laminate],
    y_loc: List[float],
    # Loading
    Nx_fluxes: list,
    Ny_fluxes: list,
    Nxy_fluxes: list,
    # Boundary conditions
    GJx: float,
    GJy: float,
    # Solution Control Parameters
    sol_nx_terms: int = 10,
    sol_ny_terms: int = 10,
    solve_by_tikhonov=True,
    plot=False,
    plot_eigenvalue_modes: List[int] = 0,
    analysis_name: str | None = 'Default',
    analysis_id: int | None = 1,


) -> (np.ndarray, np.ndarray):

    # -------------------------------------------------------------------------
    #                         PRELIMINAR CHECKINGS
    # -------------------------------------------------------------------------

    # TYPES
    # =====

    # Argument : plate_length
    if not (isinstance(plate_length, (float, int))):
        raise TypeError(
            f"Plate length value is neither an integer nor float number."
        )

    # Argument : plate_width
    if not (isinstance(plate_width, (float, int))):
        raise TypeError(
            f"Plate width value is neither an integer nor float number."
        )

    # Argument : GJx
    if not (isinstance(GJx, (float, int))):
        raise TypeError(
            f"Torsional Stiffness in X-dir (GJx) is neither an integer nor float number."
        )
    # Argument : GJy
    if not (isinstance(GJy, (float, int))):
        raise TypeError(
            f"Torsional Stiffness in Y-dir (GJy) is neither an integer nor float number."
        )

    # Argument : plate_width
    if not (isinstance(plate_width, (float, int))):
        raise TypeError(
            f"Plate width value is neither an integer nor float number."
        )

    # Argument : laminates
    if isinstance(laminates, (tuple, list, dict)):
        # Transform laminates into a tuple
        if isinstance(laminates, (list)):
            laminates = tuple(laminates)
        if isinstance(laminates, dict):
            laminates = tuple(laminates.values())
        for i, laminate in enumerate(laminates):
            if not (isinstance(laminate, Laminate)):
                raise TypeError(
                    f"Laminate at index {i} is not Laminate object."
                )
    else:
        raise TypeError(
            f"laminates is neither a list, tuple or dict object type"
        )
    # -------------------------------------------------------------------------
    #                         PARSING INPUTS
    # -------------------------------------------------------------------------
    # Plate Geometry
    L = plate_length
    B = plate_width
    GJx = GJx
    GJy = GJy

    # Plate Laminate Dstar and applied fluxes per step
    ym_loc = [0.0] + y_loc
    m = len(ym_loc)
    y_sets = [(ym_loc[i], ym_loc[i+1]) for i in range(m-1)]
    # print(y_sets)

    d1y_list = []
    d2y_list = []
    d3y_list = []
    d4y_list = []
    d5y_list = []
    d6y_list = []
    fxm_list = []
    fym_list = []
    fxym_list = []

    for i, y_set in enumerate(y_sets):
        y_ini = y_set[0]
        y_end = y_set[-1]

        laminate = laminates[i]
        _, _, d = laminate.A_B_D
        d1 = d[0, 0]
        d2 = d[1, 1]
        d3 = d[2, 2]
        d4 = d[0, 1]
        d5 = d[0, 2]
        d6 = d[1, 2]

        nx_flux = Nx_fluxes[i]
        ny_flux = Ny_fluxes[i]
        nxy_flux = Nxy_fluxes[i]

        d1y_list.append((d1, y_ini, y_end))
        d2y_list.append((d2, y_ini, y_end))
        d3y_list.append((d3, y_ini, y_end))
        d4y_list.append((d4, y_ini, y_end))
        d5y_list.append((d5, y_ini, y_end))
        d6y_list.append((d6, y_ini, y_end))

        fxm_list.append((nx_flux, y_ini, y_end))
        fym_list.append((ny_flux, y_ini, y_end))
        fxym_list.append((nxy_flux, y_ini, y_end))

    Dm_star_list = (d1y_list, d2y_list, d3y_list, d4y_list, d5y_list, d6y_list)
    fluxes_list = (fxm_list, fym_list, fxym_list)

    # # -------------------------------------------------------------------------
    # #                     ASSEMBLING Q AND T MATRICES
    # # -------------------------------------------------------------------------
    Q_matrix, T_matrix = QT_matrices(
        Dm_star_list=Dm_star_list,
        fluxes_list=fluxes_list,
        L=L,
        B=B,
        GJx=GJx,
        GJy=GJy,
        nx=sol_nx_terms,
        ny=sol_ny_terms
    )

    # # -------------------------------------------------------------------------
    # #                     SOLVING EIGENVALUE PROBLEM
    # # -------------------------------------------------------------------------
    if solve_by_tikhonov:
        eigenvalues, eigenvectors = solve_eig_tikhonov(Q_matrix, T_matrix)
    else:
        eigenvalues, eigenvectors = solve_eig(Q_matrix, T_matrix)

    if len(eigenvalues) == 0 or len(eigenvectors) == 0:
        print(
            'No positive eigenvalues detected. Please check loads'
        )
        return None

    # # -------------------------------------------------------------------------
    # #                       NORMALISING RESULTS
    # # -------------------------------------------------------------------------
    norm_eigenvectors = eigenvectors / np.max(np.abs(eigenvectors))

    print('')
    print('First Five minimum Eigencalues:')
    print('-------------------------------')
    print(eigenvalues[0:5])

    if plot:
        for mode in plot_eigenvalue_modes:
            wij_array_mode = norm_eigenvectors[:, mode]
            main_w_mode, mode_i, mode_j = eigmode(
                sol_nx_terms, sol_ny_terms, wij_array_mode)
            x, y, z = XYZ_all(
                wij_array_mode,
                sol_nx_terms,
                sol_ny_terms,
                L,
                B
            )
            draw(x, y, z, L, B)

    return eigenvalues, eigenvectors


# PARTE VI : EJEMPLOS Y VALIDACION
# =============================================================================

def fem_check_v10_no_GJ(fx, fy, fxy):
    L = 300.0
    B = 100.0
    nx = 9
    ny = 7

    print('EXAMPLE #2:')
    print('================================================================')
    print('')
    print('Material Data :')
    print('---------------')
    print('Type : Orthotropic')
    print('Mechanical Properties:')
    print('    t = 0.125')
    print('    E11 = 160000')
    print('    E12 = 5760')
    print('    G12 = 3020')
    print('    nu12 = 0.33')
    print('')
    print('Laminate data :')
    print('---------------')
    print('Type : Monolotic')
    print('Lay-up : 45/-45/0/90/45/-45/0/90/45/-45/0/90/90/0/-45/45/90/0/-45/45/90/0/-45/45')
    print('Matrix_D = |  143154.44  56899.24  6346.81  |')
    print('           |   56899.24 125020.68  6346.81  |')
    print('           |    6346.81   6346.81  59793.6  |')
    print('')
    print('Plate Data :')
    print('---------------')
    print('thickness (t) = 3.0')
    print(f'Length (L) = {L}')
    print(f'Width (B) = {B}')
    print('')
    print('Loads:')
    print('---------------')
    print('Nxx = -100.0')
    print('Nyy = 0.0')
    print('Nxy = 0.0')
    print('')
    print('Solution terms:')
    print('---------------')
    print(f'nx = {nx}')
    print(f'ny = {ny}')
    print('')

    from materials.composite import Orthotropic
    from structural.laminate import Laminate
    from structural.ply import Ply

    mat = Orthotropic('mat', 0.125, 160000, 5760, 3020, 0.33)
    ply_0 = Ply(mat, 0)
    ply_45p = Ply(mat, 45)
    ply_45n = Ply(mat, -45)
    ply_90 = Ply(mat, 90)
    # 45/-45/0/90/45/-45/0/90/45/-45/0/90/90/0/-45/45/90/0/-45/45/90/0/-45/45
    stacking = [
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        # Sim
        ply_90,
        ply_0,
        ply_45n,
        ply_45p,
        ply_90,
        ply_0,
        ply_45n,
        ply_45p,
        ply_90,
        ply_0,
        ply_45n,
        ply_45p
    ]
    laminate = Laminate(stacking)
    _, _, D = laminate.A_B_D
    laminates = [laminate]
    L = 300.0
    B = 100.0
    steps = [100.0]
    fx = [0.0]
    fy = [0.0]
    fxy = [100.0]

    return analysis_buckling_composite_laminates(
        plate_length=L,
        plate_width=B,
        laminates=laminates,
        y_loc=steps,
        Nx_fluxes=fx,
        Ny_fluxes=fy,
        Nxy_fluxes=fxy,
        GJx=0.0,
        GJy=0.0,
        plot=True,
        plot_eigenvalue_modes=list(range(0, 5)),
        sol_nx_terms=nx,
        sol_ny_terms=ny,
        solve_by_tikhonov=True
    )


def fem_check_v10_GJ(nx, ny, fx, fy, fxy):
    L = 300.0
    B = 100.0

    print('EXAMPLE #2:')
    print('================================================================')
    print('')
    print('Material Data :')
    print('---------------')
    print('Type : Orthotropic')
    print('Mechanical Properties:')
    print('    t = 0.125')
    print('    E11 = 160000')
    print('    E12 = 5760')
    print('    G12 = 3020')
    print('    nu12 = 0.33')
    print('')
    print('Laminate data :')
    print('---------------')
    print('Type : Monolotic')
    print('Lay-up : 45/-45/0/90/45/-45/0/90/45/-45/0/90/90/0/-45/45/90/0/-45/45/90/0/-45/45')
    print('Matrix_D = |  143154.44  56899.24  6346.81  |')
    print('           |   56899.24 125020.68  6346.81  |')
    print('           |    6346.81   6346.81  59793.6  |')
    print('')
    print('Plate Data :')
    print('---------------')
    print('thickness (t) = 3.0')
    print(f'Length (L) = {L}')
    print(f'Width (B) = {B}')
    print('')
    print('Loads:')
    print('---------------')
    print('Nxx = -100.0')
    print('Nyy = 0.0')
    print('Nxy = 0.0')
    print('')
    print('Solution terms:')
    print('---------------')
    print(f'nx = {nx}')
    print(f'ny = {ny}')
    print('')

    from materials.composite import Orthotropic
    from structural.laminate import Laminate
    from structural.ply import Ply

    mat = Orthotropic('mat', 0.125, 160000, 5760, 3020, 0.33)
    ply_0 = Ply(mat, 0)
    ply_45p = Ply(mat, 45)
    ply_45n = Ply(mat, -45)
    ply_90 = Ply(mat, 90)
    # 45/-45/0/90/45/-45/0/90/45/-45/0/90/90/0/-45/45/90/0/-45/45/90/0/-45/45
    stacking = [
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        ply_45p,
        ply_45n,
        ply_0,
        ply_90,
        # Sim
        ply_90,
        ply_0,
        ply_45n,
        ply_45p,
        ply_90,
        ply_0,
        ply_45n,
        ply_45p,
        ply_90,
        ply_0,
        ply_45n,
        ply_45p
    ]
    laminate = Laminate(stacking)
    _, _, D = laminate.A_B_D
    laminates = [laminate]
    L = 300.0
    B = 100.0
    steps = [100.0]
    fx = [fx]
    fy = [fy]
    fxy = [fxy]

    return analysis_buckling_composite_laminates(
        plate_length=L,
        plate_width=B,
        laminates=laminates,
        y_loc=steps,
        Nx_fluxes=fx,
        Ny_fluxes=fy,
        Nxy_fluxes=fxy,
        GJx=1e8,
        GJy=1e8,
        plot=True,
        plot_eigenvalue_modes=list(range(0, 5)),
        sol_nx_terms=nx,
        sol_ny_terms=ny,
        solve_by_tikhonov=True
    )
