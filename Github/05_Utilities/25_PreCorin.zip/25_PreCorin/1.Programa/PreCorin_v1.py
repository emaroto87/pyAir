# Funciones de limpieza del archivo de entrada

def limpia_n (lista):

    """ (lista) ---> lista
    Elimina el saltador de linea que se genera al final de una linea cuando se lee un fichero de texto y previamente
    ha sido convertido en una lista de listas (cada linea) mediante el separador ;

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0\n'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    >>> limpia_n(['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0'])
    ['S1LD12', 'MED-A', 'MED-A', '1.0', '5500', '3600', '13700', '9600', '1.0']

    """

    a = lista[-1]
    if '\n' in a:
        a = a[:-1]
        lista.pop()
        lista.append(a)

    return lista



def limpia_blancos_f (lista):
    """ (lista) ---> lista
    Elimina los campos que no contienen información al final de una lista. Adicionalmente eliminamos
    el espaciador final.

    >>> elimina_blancos_f(['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0', '', ''])
    ['M000', '157000', '8400', '4200', '156000', '8300', '4100', '0.3', '13700', '9600', '0.184', '0']

    """
    
    while lista[-1] == '':
        lista.pop()

    return lista



#Lectura del archivo con los datos geometricos y de material de los paneles a analizar

import tkinter.filedialog

print('Introduce el archivo .csv con la información geometrica y de material')

ruta = tkinter.filedialog.askopenfilename()
entrada = open(ruta,'r')
contenido = []

for linea in entrada:
    contenido.append(linea)
entrada.close()


#Generación de la lista de corines (lista de listas)
'cada miembro es una lista con los datos del panel'

lista_corines=[]
for linea in contenido:
    corin = linea.split(';')
    lista_corines.append(corin)

for corin in lista_corines:
    limpia_n(corin)
    limpia_blancos_f(corin)

limpia_blancos_f(lista_corines)

lista_corines = lista_corines[2:]

#Generacion de los archivos de salida (entradas CORIN)

for corin in lista_corines:
    archivo_corin = open(corin[178] + '.dat','w')
    
    # linea 1 (tipo de viga)

    archivo_corin.write(corin[0] + '\n')

    # linea 2 (material data group-numero de orientaciones)

    archivo_corin.write(corin[1] + '\n')

    # linea 3 (material data group-orientacion 1)

    for i in range (2,17):
        archivo_corin.write(corin[i] + ',')

    archivo_corin.write(corin[17] + '\n') 

    # linea 4 (material data group-orientacion 2)

    for i in range (18,33):
        archivo_corin.write(corin[i] + ',')

    archivo_corin.write(corin[33] + '\n')
    
    # linea 5 (material data group-orientacion 3)

    for i in range (34,49):
        archivo_corin.write(corin[i] + ',')

    archivo_corin.write(corin[49] + '\n')

    # linea 6 (material data group-orientacion 4)

    for i in range (50,65):
        archivo_corin.write(corin[i] + ',')

    archivo_corin.write(corin[65] + '\n')

    # linea 7 (lay-up data group-numero de telas)

    archivo_corin.write(corin[66] + '\n')

    # linea 8 (lay-up data group-secuencia de apilado)

    i = 67

    while corin[i+1] != '':
        archivo_corin.write(corin[i] + ',')
        i = i + 1

    archivo_corin.write(corin[i] + '\n')

    # linea 9-11 (Datos y cargas de la viga)

    if corin[0] == 'A':
        for i in range (167,170):
            archivo_corin.write(corin[i] + ',')

        archivo_corin.write(corin[170] + '\n')
        archivo_corin.write(corin[171] + ',' + corin[172]+ '\n') 
        if corin[173] != '2':
            archivo_corin.write(corin[173] + ',' + corin[174] + '\n')
        else:
            archivo_corin.write(corin[173] + '\n')
    else:
        for i in range (175,177):
            archivo_corin.write(corin[i] + ',')

        archivo_corin.write(corin[177] + '\n')  

    archivo_corin.close()

# Generamos el lanzador de Corines

archivo_lanzador = open('auto_corin.bat','w')

for corin in lista_corines:
    archivo_lanzador.write('corin ' + corin[178] + '.dat ' + corin[178] + ' 1\n')

archivo_lanzador.close()
    
        
    
