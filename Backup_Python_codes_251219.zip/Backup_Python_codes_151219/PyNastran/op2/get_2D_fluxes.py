# -*- coding: utf-8 -*-
"""
Created on Fri Jun 13 11:48:48 2025

@author: U69432
"""
from typing import Optional 
from typing import Dict
from typing import List
from typing import Literal
import re
import os
import numpy as np
import pandas as pd
import tempfile as tmpf


from common.general import ask_op2_filepath
from common.general import load_op2_file
from common.general import asksaveasexcelfile
from common.general import check_type
from common.general import check_option
from common.general import __ENTITY_TYPES

from PyNastran_OP2_tools import get_result_from_op2
from PyNastran_OP2_tools import split_df_by_subcases
from PyNastran_OP2_tools import filter_df_by_entity
from PyNastran_OP2_tools import get_envelope_from_df
from pyNastran.bdf.bdf import BDF 
from pyNastran.op2.op2_geom import OP2Geom

from scipy.spatial import ConvexHull

from tqdm import tqdm

from collections import defaultdict
from collections import namedtuple

from pathlib import Path


# Lectura por grupo de elementos
'''
La idea aqui es meter grupos de elementos como metodo de filtrado por queremos
analizar los flujos de varios componentes del tiron.

La manera de proporcionar estos groupos puede ser:
    1. Interctiva
    2. A través de un fichero - HECHO
    3. A través de una hoja excel

De momento vamos nos centramos en una versión más rudimentaria que es dando 
la información a través de un diccionario tipo (label, lista)


Posibles mejoras:
    - Que valga para extraer más información. Por ejemplo Von Misis, Max/Min Ppal
    - Que pueda leer la info directamente de un set del OP2 o del BDF
'''

'''
Notas
-----

tipo de resultados disponibles en ELFORCES elementos 2D (QUAD4 y TRIA3)

'''


# Creating and definition of Links
link = namedtuple('link', ['entity_type','op2_results_labels','op2_results'])

__RealPlateForce = link(
    __ENTITY_TYPES[1], 
    ['force.cquad4_force','force.ctria3_force'], 
    ('mx','my','mxy','bmx','bmy','bmxy','tx','ty')
    )
__RealPlateStress = link(
    __ENTITY_TYPES[1], 
    ['stress.cquad4_stress','stress.ctria3_stress'], 
    ('fiber_distance', 'oxx', 'oyy', 'txy', 'angle', 'omax', 'omin', 'von_mises')
    )
__RealPlateStrain = link(
    __ENTITY_TYPES[1],
    ['strain.cquad4_strain','strain.ctria3_strain'],
    ('fiber_curvature', 'exx', 'eyy', 'exy', 'angle', 'emax', 'emin', 'von_mises')
    )
__RealMPCForces = link(
    __ENTITY_TYPES[0],
    ['mpc_forces'],
    ('t1', 't2', 't3', 'r1', 'r2', 'r3')
    )
__RealDisplacement = link(
    __ENTITY_TYPES[0],
    ['displacements'],
    ('t1', 't2', 't3', 'r1', 'r2', 'r3')
    )
__RealGriPointForces= link(
    __ENTITY_TYPES[0],
    ['grid_point_forces'],
    ('f1','f2','f3','m1','m2','m3')
    )

__Result_Labels_Links = {
    'RealPlateForce'      : __RealPlateForce,
    'RealPlateStress'     : __RealPlateStress,
    'RealPlateStrain'     : __RealPlateStrain,
    'RealMPCForces'       : __RealMPCForces,
    'RealDisplacement'    : __RealDisplacement,
    'RealGriPointForces'  : __RealGriPointForces
    }

class ResultLink:
    def __init__(self,links_dict: Optional[Dict[str, str]] = None):
        if links_dict:
            for label, link in links_dict.items():
                self.add_link(label, link)
    
    def add_link(self,link_label:str,link):
        setattr(self,link_label,link)

def qhull(df : pd.DataFrame, 
          columns : List[str], 
          debug : Optional[bool] = False) -> pd.DataFrame:
    '''
    
    Parameters
    ----------
    df : pandas DataFrame
        Table of data.
        
    columns : List[str]
        List containing the labels of the columns from which extract and
        generate the envelope

    debug : Optional[bool], optional
        If True, it prints more information for debugging purposes. 
        The default is False.

    Returns
    -------
    envelope : pd.Dataframe
        pandas DataFrame with the Qhull algorythm applied.

    ''' 
    
    
    # Checkings
    check_type(df, pd.DataFrame)
    check_type(columns,list)
    check_type(debug,bool)
  
    
    # Filtering the data by the selected columns
    data = df[columns].to_numpy()
    if debug : print(f'Points :\n{data}')
    
    hull = ConvexHull(data)
    if debug : 
        print('QHull envelope:')
        print(hull.vertices)
    
    envelope = df[df.index.isin(list(hull.vertices))]
    if debug : print(f'Output Table:\n{envelope}')
    
    return envelope

def envelope(df : pd.DataFrame, 
             envelope_option : str, 
             envelope_columns: List[str]
             )->pd.DataFrame:
    '''
    

    Parameters
    ----------
    df : pandas DataFrame
        Table of data.
    envelope_option : str
        .
    envelope_columns : List[str]
        List containing the labels of the columns from which extract and
        generate the envelope

    Raises
    ------
    ValueError
        If the any of the columns are not included in the table
    AssertionError
        For the En

    Returns
    -------
    pandas Dataframe
        Table with the points that generate the envelope

    '''
    
    # Checking arguments
    check_type(df, pd.DataFrame)
    check_type(envelope_option, str)
    check_type(envelope_columns,list)
    
    for envelope_column in envelope_columns:
        if not(envelope_column in df.columns):
            raise ValueError(
                f'Column "{envelope_column}" is not present in Pandas DataFrame' \
                f'.Please review envelope_columns list'
                )
    
    if envelope_option in ENVELOPE_OPTIONS:
        # EXTREME OPTION
        if envelope_option.upper() == ENVELOPE_OPTIONS[0]:
            if len(envelope_columns) == 1 :
                df_env_rows=[]
                column = envelope_columns[0]
                max_val = df[column].max()
                min_val = df[column].min()
                max_row = df[df[column] == max_val]
                min_row = df[df[column] == min_val]
                df_env_rows += [max_row]
                df_env_rows += [min_row]
                return pd.concat(df_env_rows)
            else:
                raise AssertionError(
                    f'When using envelope option {ENVELOPE_OPTIONS[0]} or '    \
                    f'{ENVELOPE_OPTIONS[1]} the number of elements within '    \
                    f'envelope_columns list must be only one. Please check'    \
                    )
        # MAX_ABS OPTION
        if envelope_option.upper() == ENVELOPE_OPTIONS[1]:
            if len(envelope_columns) == 1 :
                column = envelope_columns[0]
                max_val = df[column].max()
                min_val = df[column].min()
                max_abs = max_val if abs(max_val) >= abs(min_val) else min_val
                max_abs_row = df[df[column] == max_abs]
                # print(max_abs_row)
                return max_abs_row
            else:
                raise AssertionError(
                    f'When using envelope option {ENVELOPE_OPTIONS[0]} or '    \
                    f'{ENVELOPE_OPTIONS[0]} the number of elements within '    \
                    f'envelope_columns list must be only one. Please check'    \
                    )
        
        # QHULL OPTION
        if envelope_option.upper() == ENVELOPE_OPTIONS[2]:
            if len(envelope_columns) >=2 :
                return qhull(df,envelope_columns)
    
    
    else:
        raise ValueError(f'{envelope_option} is not a valid option. Please sel'\
                         'ect one of the valid options {ENVELOPE_OPTIONS}')
            
        
def get_all_ids(op2_filename: Path):
    op2 = OP2Geom(make_geom = True)
    geom = op2.read_op2(op2_filename)
    ids = {
        __ENTITY_TYPES[0] : geom.nodes,
        __ENTITY_TYPES[1] : geom.elements,
           }
    return ids

def gen_all_group(
        op2_filename : Path,
        entity_type : str, 
        debug_geom : Optional[bool] = False
        ) -> Dict[str,list] :
    '''
    Given a NASTRAN OP2 file, it generates a group with the label "ALL" 
    containing either all the ids of the nodes or elements present in the file.

    Parameters
    ----------
    op2_filename : Path
        Path of the NASTRAN OP2 file.
    entity_type : str
        Either one of the following options : NodeID or ElementID
    debug_geom : Optional[bool], optional
        Parameter inherited from OP2Geom class. If False, it skips some errors
        while reading the OP2 file. The default is False.

    Raises
    ------
    ValueError
        When the entity option is not one of the allowable ones NodeID or 
        Element ID.

    Returns
    -------
    Dict[str,list]
        Returns a dictionary with one unique key "ALL" whose value is a list
        containg all the ids.

    '''
    
    
    # Opening the OP2 to read geometry
    op2 = OP2Geom(make_geom=True , debug = debug_geom)
    op2.read_op2(path)
    
    
    # Extracting all the ids
    groups ={}
    
    if entity_type == __ENTITY_TYPES[0]:
        groups['ALL'] = list(op2.node_ids)
    elif entity_type == __ENTITY_TYPES[1]:
        groups['ALL'] = list(op2.element_ids)
    else:
        raise ValueError(f'{entity_type} is not a valid ENTITY_TYPE')
    
    return groups


def group_envelope(dataframe, 
                   groups: dict, 
                   result_link,
                   envelope_type : str,
                   envelope_columns : list,
                   groups_summary : bool = False,
                   output_path : str = None,
                   debug : bool = False
                   )  : 
        
    entity_type = result_link.entity_type
    for group in groups:
        tables = {}
        for label, items in groups.items():
            group_table = filter_df_by_entity(
                dataframe,
                items,
                entity_type = entity_type
                )
            eids_env_table = []
            for item in tqdm(items,desc=f'Filtering Group {group}...'):

                if debug : print(f'{entity_type} : {item}')
                
                if entity_type in group_table.columns:
                    table = group_table[
                        group_table[entity_type].isin([item])
                        ]
                
                else:
                    table = group_table[
                        group_table.index.isin([item])
                        ]
                

                if not(envelope_type.upper() == 'NONE'):
                    df_eid_env = envelope(
                        table,
                        envelope_type,
                        envelope_columns
                        )
                    eids_env_table += [df_eid_env]
                else:
                    eids_env_table += [table]
                 
            # Concatenating all the envelopes per ID of the group
            group_table = pd.concat(eids_env_table)                                 
            
            # Adding to the table the column 'Group'
            group_table['Group'] = label                                             
            if debug : print(group_table)
            
            # Storing the result into a dict
            tables[label] = group_table.drop_duplicates()
            
        if groups_summary and (envelope_type.upper() == 'NONE') :
            raise AssertionError(
                'Is not possible to combine groups_summary = True and' \
                ' envelope_type = None.'
                )
        else:    
            if groups_summary:
                summary = []
                for label,table in tables.items():
                    # Generating the envelope of the group
                    group_env_table = envelope(
                        group_table,
                        envelope_type,
                        envelope_columns
                        )
                    # Adding the result to the summary table
                    summary += [group_env_table]
                    
                # print(summary)
                summary_table = pd.concat(summary)
                summary_table.set_index('Group', inplace = True)
                summary_table.sort_index()
    
                # Include the Summary table
                tables['Summary'] = summary_table.drop_duplicates()
     
    # Exporting the result into an excel   
    if not(output_path is None):
        to_excel(tables,output_path)
    return tables
    




def raw_table(op2_filename: Path, result_link : str)-> pd.DataFrame:
    '''
    Reads a NASTRAN OP2 file and returns a pandas DataFrame with all the
    selected results through the link.

    Parameters
    ----------
    op2_filename : Path
        Path of the NASTRAN OP2 file.
    result_link : str
        

    Returns
    -------
    raw_table : pandas DataFrame
        Dataframe containing all the data from the OP2 file. The table has an
        single index. If the data from the OP2 is stored within a Multi-Index
        table, it is converted into single-Index one.

    '''
    path = op2_filename
    
    check_type(op2_filename,str)
    # check_type(result_link,str)
    # check_option(result_link,list(Result_Labels_Links.keys()))
    
    try:
        op2 = load_op2_file(op2_filename)
    except IOError:
        pass
    
    dfs = [ ]
    op2_result_labels = result_link.op2_results_labels
    
    for op2_result_label in op2_result_labels :
        
        if hasattr(op2, op2_result_label) :
            
            print(f'Reading {op2_result_label}...', end ='')
            df = get_result_from_op2(op2, op2_result_label)
            dfs += [df]
            print('Done')
        
        else:
            print(f'[WARN] {op2_result_label} not found in OP2 file')
    
    raw_table = pd.concat(dfs)        
    
    return raw_table



def read_sets_from_file(filename : Path, 
                        comment_symbol : Optional[ str ]  = '$',
                        members_separator : Optional[ str ] = ',',
                        set_keyword : Optional[ str ] = 'SET',
                        verbose : bool = False) -> Dict[ str, list ]:
    '''
    It reads the sets defined within a text file.
    
    The format of the set files is as follows:
        
        {Set_keyword} {label} = id_1 {sep} id_2 {sep} id_3 {sep} ....
    
    Example:
        
        SET Panel2-4 = 1001, 1002, 1101, 1002
    
    In this example, the label of the set is "Panel2-4" and the seperator of 
    the id of the members of the group is in this case ",". Additionally, the 
    set_keyword is in this case "SET".
        
    Parameters
    ----------
    filename : Path
        Path of the text file containing the definition of the sets.
    comment_symbol : Optional[str], optional
        String that if placed at the beginning of each line, is interpreted as
        a commented line and its content is not read. The default is '$'.
    members_separator : Optional[str], optional
        String that is used to separate the members of the set. The default is ','.
    set_keyword : Optional[str], optional
        String used by the function to identify the beginning of the defintion
        of a new set. The default is 'SET'.
    verbose : bool, optional
        Option to print further information. The default is False.

    Raises
    ------
    ValueError
        DESCRIPTION.

    Returns
    -------
    dict
        DESCRIPTION.

    '''
    
    # Preliminary checks
    if not(check_type(filename,str)):
        pass
    
    if not(check_type(comment_symbol,str)):
        pass
    
    if not(check_type(members_separator,str)):
        pass
    
    if not(check_type(set_keyword,str)):
        pass
    
    if not(os.path.isfile(filename)):
        raise ValueError('The path does not corrspond to a file')
        
    sets = {}
    pattern = r'{0}([A-Za-z0-9_]+)=([\d,]+)'.format(set_keyword)

    # Read file content and close    
    with open(filename,'r') as f:
        lines = f.readlines()
    
    # cleaning commented lines
    clean_lines = [line[:-1] for line in lines 
                   if not(line.startswith(comment_symbol))]

    clean_lines = ''.join(clean_lines)
    clean_lines = clean_lines.replace(' ','')
    clean_lines = clean_lines.strip()
    
    # Spliting the content by sets using the pattern
    findings = re.findall(pattern,clean_lines)
    
    if len(findings)==0:
        raise ValueError(
            'Unable to locate any set'
            )
    
    # Read the members of each set and store them into a list
    for set_label, set_content in findings:
        members_list = [int(x) for x in set_content.split(',')]
        if set_label.isnumeric() : set_label = int(set_label)
        sets[set_label] = members_list
    
    return sets
              
            
def to_excel(tables : Dict[str,pd.DataFrame], output_filename : Path) :
    '''
    Export into an Excel file multiple pandas DataFrames stored within a 
    dictionary

    Parameters
    ----------
    tables : Dict [str, pd.DataFrame ]
        Dictionary containing the pandas DataFrames. Each key of the dictionary
        is used to label the sheet of the Excel book file.
    filename : str path-like
        Path of the output Excel file.

    Returns
    -------
    None.

    '''
    # Checking
    check_type(tables,dict)
    check_type(output_filename,str)
        
    print('Exporting to Excel File ...', sep='')
    with pd.ExcelWriter(output_filename) as writer:
        for sheet_name, table in tables.items():
            table.to_excel(writer, sheet_name=sheet_name, index=False)  
    print('[Done]')                   
            

#
ENVELOPE_OPTIONS = ('EXTREME','MAX_ABS','QHULL','NONE')

# Initialising results links
r_link = ResultLink(__Result_Labels_Links)


        
sets_file = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\BDF_tools\read_sets\From_SetFile\set_file.txt'
test_path = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\test_plate_hole_rspline_all.op2'
test_path2 = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\DFEM_ECS_stresses.op2'
test_path3 = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\PDLL_20240731_AC_PDLL-LAP_FUS_UL_GFEM_01_fluxes.op2'
test_path4=r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\FEMs\Isolated_ECS_SW_DFEM\DFEM_ECS_EI-GJ_w_RBE2_asses_issue2.op2'
out_path = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\__test\BDF_tools\read_sets\From_SetFile\test_group_script.xlsx'
  
# result = 'RealDisplacement'
result = r_link.RealPlateStress
# result = 'RealPlateStrain'
# result = 'RealPlateForce'

path = test_path4

# sets = parse_sets_from_bdf(sets_file)
sets = gen_all_group(path, result.entity_type)
# raw_data = raw_table(path,result)

a = group_envelope(dataframe = raw_table(path,result),
                groups = sets,
                result_link = result,
                envelope_type = 'QHULL',
                envelope_columns = ['oxx','oyy','txy'],
                output_path = None,
                debug = False,
                groups_summary = False
                )