# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 09:42:54 2026

@author: U69432
"""
__version__ = '0.0.1'

from enum import Enum
import numpy as np
import math


class CSYS_TYPE(Enum):
    REC = 1
    CYL = 2
    SPH = 3


class ANGLE_UNITS(Enum):
    DEG = 'degrees'
    RAD = 'radians'


class Csys:
    pass


class Point:
    def __init__(self,
                 coord1: float,
                 coord2: float,
                 coord3: float,
                 csys_type: CSYS_TYPE = CSYS_TYPE.REC):

        self.__coords = (coord1, coord2, coord3)
        if csys_type is CSYS_TYPE.REC:
            self.x = self.__coords[0]
            self.y = self.__coords[1]
            self.z = self.__coords[2]

        elif csys_type is CSYS_TYPE.CYL:
            self.rho = self.__coords[0]
            self.phi = self.__coords[1]
            self.z = self.__coords[2]

        elif csys_type is CSYS_TYPE.SPH:
            self.rho = self.__coords[0]
            self.phi = self.__coords[1]
            self.theta = self.__coords[2]

        else:
            raise ValueError(
                'Incorrect value of csys_type argument.'
            )
        self.csys_type = csys_type

    def __repr__(self):
        if self.csys_type is CSYS_TYPE.REC:
            msg = f'[x: {self.x}, y: {self.y}, z: {self.z}]'
        elif self.csys_type is CSYS_TYPE.CYL:
            msg = f'[rho: {self.rho}, phi : {self.phi}, z: {self.z}]'
        elif self.csys_type is CSYS_TYPE.SPH:
            msg = f'[rho: {self.rho}, phi : {self.phi}, theta: {self.theta}]'
        return msg

    def to_list(self):
        return list(self.__coords)

    def to_array(self):
        return np.array(self.__coords)

    def __add__(self, other):
        if isinstance(other, (list, tuple, np.ndarray, Point)):
            if len(other) == 3:
                out = Point(
                    self.__coords[0] + other[0],
                    self.__coords[1] + other[1],
                    self.__coords[2] + other[2],
                    self.csys_type
                )
                return out
            else:
                raise ValueError(
                    f'Unable to add {other} becaues the length is not equal to 3'
                )

    def __sub__(self, other):
        if isinstance(other, (list, tuple, np.ndarray, Point)):
            if len(other) == 3:
                out = Point(
                    self.__coords[0] - other[0],
                    self.__coords[1] - other[1],
                    self.__coords[2] - other[2],
                    self.csys_type
                )
                return out
            else:
                raise ValueError(
                    f'Unable to add {other} becaues the length is not equal to 3'
                )
        else:
            raise ValueError(
                f'It nos possible to multiply the point with a type {type(other)}'
            )

    def __len__(self):
        return 3

    def __getitem__(self, index):
        return self.__coords[index]

    # def __truediv__(self, number):
    #     if n

    def __matmul__(self, other):
        if isinstance(other, (list, tuple, np.ndarray, Point)):
            if len(other) == 3:
                out = self.__coords[0] * other[0] + self.__coords[1] * \
                    other[1] + self.__coords[2] * other[2]
                return out
            else:
                raise ValueError(
                    f'Unable to add {other} becaues the length is not equal to 3'
                )
        else:
            raise ValueError(
                f'It nos possible to multiply the point with a type {type(other)}'
            )

    def __mul__(self, scalar):
        if isinstance(scalar, (int, float)):
            return Point(
                self.__coords[0] * scalar,
                self.__coords[1] * scalar,
                self.__coords[2] * scalar,
            )
        return NotImplemented

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def __matmul__(self, other):
        if isinstance(other, (list, tuple, np.ndarray, Point)):
            if len(other) == 3:
                out = self.__coords[0] * other[0] + self.__coords[1] * \
                    other[1] + self.__coords[2] * other[2]
                return out
            else:
                raise ValueError(
                    f'Unable to add {other} becaues the length is not equal to 3'
                )
        else:
            raise ValueError(
                f'It nos possible to multiply the point with a type {type(other)}'
            )

    def __truediv__(self, scalar):
        if isinstance(scalar, (int, float)):
            return self.__mul__(1/scalar)
        return NotImplemented

    @property
    def norm(self):
        return self.__matmul__(self.__coords)**0.5

    @property
    def unitary(self):
        mod = self.norm
        return Point(
            self.__coords[0]/mod,
            self.__coords[1]/mod,
            self.__coords[2]/mod,
        )


class Vector(Point):
    def __init__(self, A: Point, B: Point):
        # checking
        if A.csys_type == B.csys_type:
            # self.__coords = B - A
            # self.csys_type = A.csys_type
            super().__init__(
                (B - A)[0],
                (B - A)[1],
                (B - A)[2],
                A.csys_type
            )
        else:
            raise ValueError(
                f'Csys of point A does not math with point B.'
            )


class Plane:
    def __init__(self):
        pass


class Plane_by3points(Plane):
    def __init__(self, point1: Point, point2: Point, point3: Point):
        self.point1 = point1
        self.point2 = point2
        self.point3 = point3
        self.vecdir1 = Vector(p1, p2)
        self.vecdir2 = Vector(p1, p3)

    @property
    def normal(self):
        arr1 = self.vecdir1.to_array()
        arr2 = self.vecdir2.to_array()
        n = np.cross(arr1, arr2)
        v = Vector(Point(0, 0, 0), Point(n[0], n[1], n[2]))
        v_norm = v.unitary
        return v_norm

    @property
    def implict_eq_coeff(self):
        n = self.normal
        a = n[0]
        b = n[1]
        c = n[2]
        x1 = self.point1[0]
        x2 = self.point1[1]
        x3 = self.point1[2]
        d = - a * x1 - b * x2 - c * x3
        return (a, b, c, d)

    def point_inplane(self, point: Point):
        v1 = Vector(self.point1, point)
        v2 = Vector(self.point1, self.point2)
        v3 = Vector(self.point2, self.point3)
        print(v1)
        print(v2)
        print(v3)

        matrix = [
            v1.to_list(),
            v2.to_list(),
            v3.to_list()
        ]

        det = np.linalg.det(np.array(matrix))
        print(det)
        if det == 0.0:
            return True
        else:
            return False

    def proyect_point(self, point, direction: Vector = None) -> Point:
        if direction is None:
            n = self.normal
            d = self.implict_eq_coeff[3]
            nu = ((n @ point + d) / (n @ n)) * n
            p_prime = point - nu
        else:
            n = self.normal
            v = direction
            nom = (point - self.point1) @ n
            den = n @ v
            if den == 0:
                print('Unable to compute the proyection. The direction is '
                      'perpendicular to the normal of the plane.')
                return None
            else:
                nu = (nom / den) * v
                p_prime = point - nu
                return p_prime

    def intriangle(self, point):
        '''
        Checks if the point complies with the following requirements:
            1. Belongs to the plane
            2. It is contained within the triangle defined by the points
               P1, P2 and P3
        '''

        v0 = Vector(self.p3, self.p1)
        v1 = Vector(self.p2, self.p1)
        v2 = Vector(point, self.p1)
        d00 = v0 @ v0
        d01 = v0 @ v1
        d11 = v1 @ v1
        d20 = v2 @ v0
        d21 = v2 @ v1
        den = d00 * d11 - d01**2


def angle_between_vectors(vector1: Vector, vector2: Vector, opt=ANGLE_UNITS.RAD) -> float:
    '''
    Returns the angle between two vectors.

    opt = ANGLE_UNITS.RAD. Returns the angle in radiands. Default value
    opt = ANGLE_UNITS.DEG. Returns the angle in degrees.
    '''
    cos = (vector1 @ vector2) / (vector1.norm * vector2.norm)
    theta_rad = math.acos(cos)
    if opt == ANGLE_UNITS.DEG:
        theta_deg = math.degrees(theta_rad)
        return theta_deg
    else:
        return theta_rad


if __name__ == '__main__':
    p1 = Point(1.5, 0, 0)
    p2 = Point(2, 0, 0)
    p3 = Point(0, 1.333, 0)
    p4 = Point(0, 2, 0)
    p5 = Point(1, 1, 0)
    p6 = Point(2.1, 3.15, 0)
    v1 = Vector(p1, p6)
    v2 = Vector(p1, p2)
    v3 = Vector(p2, p3)
    s1 = Plane_by3points(p1, p2, p5)
    s1.point_inplane(p6)
    p7 = Point(0, 0, 7)
    dir1 = Vector(Point(0, 0, 0), Point(1, 0, 1))
