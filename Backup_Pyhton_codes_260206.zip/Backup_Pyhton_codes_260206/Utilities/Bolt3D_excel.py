# -*- coding: utf-8 -*-
"""
Created on Tue Mar  4 12:02:59 2025

@author: U69432
"""

import os
import sys
import xlwings as xw
import numpy as np


f_path = r'c:\Users\U69432\Desktop\WORK\01_FWD_FUS\01_Jacking\02_Work\02_F01-F02_WholeFus\99_ANALYSIS\Bolt3D\Analysis_Handling_Fiiting_FWD_FUS_F01-F02.xlsx'



class point:
    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z


class fast_point:
    def __init__(self,position,vector,effectiveness=(1.0,0.0)):
        self.position = position
        self.vector = vector
        self.effectiveness = effectiveness

class lcs:
    def __init__(self,id,fx,fy,fz,mx,my,mz,label=None,csys=None):
        self.fx = fx
        self.fy = fy
        self.fz = fz
        self.mx = mx
        self.my = my
        self.mz = mz
        if label is None:
            self.label = ''
        else:
            self.label = label
        if sys is None:
            self.csys = np.identity(3)
            
# Opening xlwings
wb = xw.Book(f_path)


# Accessing applicaiton point table
ws = wb.sheets['JOINT-ANALSYS_BOLT3D']
app_point_cell = wb['App.Point']
app_point_table = app_point_cell.expand('right')
app_point = point(
    x = app_point_table[1].value,
    y = app_point_table[2].value,
    z = app_point_table[3].value
    )

lc_cell = ws['LCs']
lc_table = lc_cell .expand('table')
app_point = point(
    x = app_point_table[1].value,
    y = app_point_table[2].value,
    z = app_point_table[3].value
    )
            
        
        