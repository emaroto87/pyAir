# -*- coding: utf-8 -*-
"""
Created on Mon May 26 11:26:23 2025

@author: U69432
"""


import os 

input_file_path = r'C:\Users\U69432\Desktop\WORK\01_FWD_FUS\02_ECS_ShearWall_DFEM\02_DFEM\02_SUBCASES\FUS_DLL_SUBCASE_ALL_UL_b.incl'
dirname = os.path.dirname(input_file_path)
input_filename = os.path.basename(input_file_path)


with open(input_file_path,'r') as input_file:
    input_lines = input_file.readlines()

output_file = open(os.path.join(dirname,'sol105_subcases.bdf'),'w')
output_lines = [] 

method_sid=2
for line in input_lines:
    if line.startswith('$') :  
        output_lines += [line]
    else:
        if line.upper().startswith('SUBCASE'):
            static_sid = line.upper().split('SUBCASE')[1].strip()
            buckling_sid = '1' + static_sid
            output_lines += ['SUBCASE{0}{1}\n'.format(5*' ',buckling_sid)]
        if 'TITLE' in line.upper():
            output_lines += [4*' '+line]
            output_lines += [
                '    STATSUB{0}={1}{2}\n'.format(' ',' ',static_sid),
                '    METHOD{0}={1}{2}\n'.format(' ',' ',method_sid),
                '    VECTOR(PLOT){0}={1}ALL\n'.format(' ',' ')
                ]
                
output_file.writelines(output_lines)
output_file.close()            
            
            
            

