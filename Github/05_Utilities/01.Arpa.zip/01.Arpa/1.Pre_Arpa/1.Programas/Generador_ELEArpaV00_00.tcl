# -------------------------------------------------------------------
# Author:	Marina Cantador Tamurejo
# Mail:		marina.cantador.external@airbus.com
# Version:  V00_00
# -------------------------------------------------------------------
# TCL CODE WHICH MODIFIES THE .dat INPUT FILE FOR ARPA WITH THE 
# ELEMENTS IDs THAT COMPOUNDS STRINGERS AND PANELS.
# -------------------------------------------------------------------
#
# The code reads the ID of the elements selected in Hypermesh screen  
# and modifies .dat file whith this elements IDs.
#
# Select the file which is modified
hm_usermessage "Select dat file to be modified with the elements, the output file from Python Pre-ARPA tool"
set nombre_dat [tk_getSaveFile -title "Select a File"]
puts $nombre_dat
set dat [open $nombre_dat "r+"]
set data [read $dat]
# Writes in the beginning of the file
seek $dat 0
# Transform the file in a Tcl list where each line is an element
set file_splitted [join [split $data "\n"]]
# -------------------------------
foreach file_line $file_splitted {
	# Locates the first line which defines the beginning of the block definition (superstringer)
	if {[string match {*,RS,*} $file_line] || [string match {*,RI,*} $file_line]} {
	set flag 1
	puts $dat $file_line
	# Restart the check of the config
	set panel1_ele 0
	set panel2_ele 0
	puts "The elements you are selecting is for stringer [lindex [split $file_line ","] 0] (IDSTR)"
	continue
	} else {
	set flag [expr $flag+1]
	}
	# -----------------STRINGER DATA--------------------------------
	if {$flag == 4} { #Read and write the element ID of the stringer
	*createmarkpanel elements 1 "Select the elements which define the stringer"
	set strg_ele [join [hm_getmark elements 1] ","]
	hm_markclearall 1
	puts $dat $strg_ele
	continue
	}
	# -----------------PANEL1 DATA---------------------------------
	if {$flag == 5 && ![string is integer [lindex [split $file_line ","] 0]]} {
		#Read the element ID of the panel1
		puts "The elements you are selecting is for panel1 [lindex [split $file_line ","] 0] (IDPAN1)"
		*createmarkpanel elements 1 "Select the elements of panel_1"
		set panel1_ele [join [hm_getmark elements 1] ","]
		hm_markclearall 1 
	}
	# -----------------PANEL2 DATA----------------------------------
	if {$flag == 7 && ![string is integer [lindex [split $file_line ","] 0]]} {
		#Read the element ID of the panel1
		puts "The elements you are selecting is for panel2 [lindex [split $file_line ","] 0] (IDPAN2)"
		*createmarkpanel elements 1 "Select the elements of panel_2"
		set panel2_ele [join [hm_getmark elements 1] ","]
		hm_markclearall 1 
	}
	# ---WRITE THE DATA IN THE FILE DEPENDING ON THE CONFIG PANEL+STRG+PANEL OR STRG+PANEL--
	
	# -----------------PANEL1 DATA---------------------------------
	if {$flag == 6 && $panel1_ele != 0} {
		puts $dat $panel1_ele
		continue
	}
	# -----------------PANEL2 DATA---------------------------------
	if {$flag == 8 && $panel2_ele != 0} {
		puts $dat $panel2_ele
		continue
	}
	#Write the rest of the lines
	puts $dat $file_line 
}
close $dat