# -*- coding: utf-8 -*-
# =============================================================================
import os
# Importing
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename

__version__ = '0.0.1'
__author__ = 'E.Maroto'

# Basic PEP 8 rules:
# ------------------
#
# 1. Code lines with no more than 79 characters
# 2. Docstrings/comment lines with no more than 72 characters


def askOpenBDF(verbose=False, multiple=False) -> str:
    '''
    Opens a UI dialog window to open a NASTRAN bulk data file (bdf). If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string


    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)

    if verbose:
        print('Opening NASTRAN BDF file...', end='')

    path = askopenfilename(
        title='Open Sets File',
        filetypes=(("BDF file", '*.bdf'), ("DAT file", '*.dat'),
                   ("INCLUDE file", '*.incl')),
        multiple=multiple,
        defaultextension=['.bdf'],
        initialdir=os.getcwd(),
        parent=root
    )
    if path == '':
        print('No file has been selected.')
        path = None
    else:
        print('Done')
    return path


def askOpenGroupFile(verbose=False, multiple=False) -> str:
    '''
    Opens a UI dialog window to open a Sets file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string


    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)

    if verbose:
        print('Opening Sets file...', end='')

    path = askopenfilename(
        title='Open Sets File',
        filetypes=(("Sets file", '*.set'),),
        multiple=multiple,
        defaultextension=['.op2'],
        initialdir=os.getcwd(),
        parent=root
    )
    if path == '':
        print('No file has been selected.')
        path = None
    else:
        print('Done')
    return path


def askOpenOP2(verbose=False, multiple=False) -> str:
    '''
    Opens a UI dialog window to open a OP2 file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string


    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)

    if verbose:
        print('Opening OP2 file...', end='')

    path = askopenfilename(
        title='Open OP2',
        filetypes=(("Nastran OP2 file", '*.op2'),),
        multiple=multiple,
        defaultextension=['.op2'],
        initialdir=os.getcwd(),
        parent=root
    )
    if path == '':
        print('No file has been selected.')
        path = None
    else:
        print('Done')
    return path


def askSaveAsExcel(verbose=False, multiple=False) -> str:
    '''
    Opens a UI dialog window to save a Excel file. If the user press the Cancel
    button, returns a None type object.

    Returns
    -------
    path : path-like string


    '''
    # Code to force the dialog window to be the foremost
    root = tk.Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)

    if verbose:
        print('Saving Excel file...', end='')

    path = asksaveasfilename(
        title='Save EXCEL file...',
        filetypes=(("EXCEL file", '*.xlsx'),),
        defaultextension=['*.xlsx'],
        initialdir=os.getcwd(),
        parent=root
    ),

    if path == '':
        print('No file has been selected.')
        path = None
    else:
        print('Done')
    return path
