"""
Macro para exportar los archivos de geometría y elementos a excel con el formato
de la plantilla

Autor: Jorge Pérez Lozano (u70148)
"""

# import pandas as pd
import os
from tkinter.filedialog import askopenfilename
# from tkinter.filedialog import asksaveasfilename
import ARALObjects

    
files_to_read = input('Which files do you want to read?\n\t1:\tGeometry\n\t2:\tElements\n\t3:\tBoth\n\n\t0:\tExit\n')
    
if files_to_read == '1':
    geom_file = askopenfilename(
        title ='Select the geometry .dat or .txt file', 
        filetypes=(("dat or txt", ('*.txt','*.dat')),),
        multiple = False,
        defaultextension = ['.dat','.txt'],
        initialdir = os.getcwd())
    geom = ARALObjects.Geometry(geom_file)
    geom_sheet = geom.geometry_sheet()

elif files_to_read == '2':
    elms_file = askopenfilename(
        title ='Select the elements .dat or ,txt file', 
        filetypes=(("dat or txt", ('*.txt','*.dat')),),
        multiple = False,
        defaultextension = ['.dat','.txt'],
        initialdir = os.getcwd())
    elms = ARALObjects.Element(elms_file)
    elms_sheet = elms.element_sheet()      
    
elif files_to_read == '3':
    geom_file = askopenfilename(
        title ='Select the geometry .dat or .txt file', 
        filetypes=(("dat or txt", ('*.txt','*.dat')),),
        multiple = False,
        defaultextension = ['.dat','.txt'],
        initialdir = os.getcwd())
    geom = ARALObjects.Geometry(geom_file)
    geom_sheet = geom.geometry_sheet()
    
    elms_file = askopenfilename(
        title ='Select the elements .dat or ,txt file', 
        filetypes=(("dat or txt", ('*.txt','*.dat')),),
        multiple = False,
        defaultextension = ['.dat','.txt'],
        initialdir = os.getcwd())
    elms = ARALObjects.Element(elms_file)
    elms_sheet = elms.element_sheet()      
        
else: 
    print('Not a valid option. Launch the program again')

export = input('Export to an Excel sheet?\n\t0:\tYes\n\t1:\tNo\n')
if export == '0':
    if files_to_read == '1':
        geom.export_to_excel()
    elif files_to_read == '2':
        elms.export_to_excel()
    elif files_to_read == '3':
        geom.export_to_excel()
        elms.export_to_excel()





