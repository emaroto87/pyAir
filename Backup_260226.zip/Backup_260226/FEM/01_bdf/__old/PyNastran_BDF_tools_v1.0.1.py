# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 14:48:19 2025

@author: U69432
"""

__version = '1.0.1'
__author  = 'E.Maroto'

# ========================
#
# PARTE DE LECTURA DE BDF
#
# ========================
#### Ejemplos para leer BDF y conseguir datos de él

from pyNastran.bdf.bdf import BDF as bdf

# # Load the model
# model = bdf()
# model.read_bdf( 
#     bdf_filename = incfp,
#     read_includes = True,
#     validate = False,
#     xref = True,
#     )

# # Imprimir datos del modelo 
# print(model.get_bdf_stats)

# # Acceder a nodos
# nodes = model.nodes # Se trata de un diccionario k=nid v=obj nodo
# nids = list(model.nodes.keys())
# n1=nodes[nids[0]]

# # Acceder a elementos
# elems = model.elements
# eids = list(elems.keys())
# e1 = elems[eids[0]]
            
# print(e1.get_stats()) # Proporciona información del elementoe1

# # cosas utiles
# e1.type # me proporciona el tipo de elemento que es
# e1.object_attributes() # proporciona los atributos
# e1.object_method()
# e1.pid_ref # accedes a la propiedad vinculada al elemento

# # Mapear
# model.get_property_id_to_element_ids_map()
# #
# #
# #
# #
# #
# #
# # Lista de funciones que podrian ser utiles.
# # 1. Dado un modelo con remaches CBUSH + RBE3, generar los PBUSH
# # 2. Dada una lista de remaches 


from collections import defaultdict
from collections import namedtuple
import os
import sys

"""
Nota el siguiente codigo asume que el elemento 'eid' es una lista que contiene
los nodos que lo definen.


"""
def get_edges_from_element(pyNastran_elem)->list:
    elem = pyNastran_elem
    edges=[]
    nodes = elem.node_ids 
    n = len(nodes)
    for i in range(n):
        print
        edge = tuple(sorted((nodes[i],nodes[(i+1) % n])))
        edges.append(edge)
    return edges

def get_edges(pyNastran_elems,sort=False,verbose=False):
    elems = pyNastran_elems
    edge_counter = defaultdict(int)
    # Step 1 : count how many times an edge appears
    
    for eid,elem in elems.items():
        edges = get_edges_from_element(elem)
        for edge in edges:
            edge_counter[edge] +=1
    if verbose :
        for edge,count in edge_counter.items():
            print ('Edge defined by nodes : ',edge, 'counted ',count,' times')
   
    # Step 2 : edges that appears only one time
    frontier_edges = [edge for edge,count in edge_counter.items() if count==1]
    
    # Step 3 : get the unique nodes of the frontier edges
    frontier_nodes = set()    
    for edge in frontier_edges:
        frontier_nodes.update(edge)
    if sort is True:
        frontier_nodes = sorted(frontier_nodes)
    
    return frontier_nodes

def testing_get_edges():
    # # Load the model
    path = r'C:\Users\U69432\Desktop\WORK\00_Resources\02_Python_codes\PyNastran\examples_and_tests\BDF_tools\edges'
    fname = 'test.bdf'
    os.chdir(path)
    model = bdf()
    model.read_bdf( 
        bdf_filename = os.path.join(path,fname),
        read_includes = True,
        validate = False,
        xref = True,
        )
    edges = get_edges(model.elements)
    return edges

